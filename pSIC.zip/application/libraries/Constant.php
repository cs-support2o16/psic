<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Constant {

    //ADMIN LEVEL 
    
    const AL_SUPER_ADMIN = 'SUPERADMIN';
    const AL_ADMIN = 'ADMIN';
    const AL_WEBMASTER = 'WEBMASTER';
    const AL_CALL_CENTER = 'CALLCENTER';
    
    // ADMIN ACTIONS
    const AL_ADD = "Added";
    const AL_EDIT = "Updated";
    const AL_DELETE = "Deleted";
    const AL_DELETE_ALL = "Deleted All";
    const AL_HIDE = "Hid";
    const AL_SHOW = "Showed";
    const AL_SEARCH = "Searched";
    const AL_VIEW = "Viewed";
    const AL_EXPORT = "Exported";
    const AL_IMPORT = "Imported";
    const AL_DOWNLOAD = "Downloaded";
    const AL_REMOVE_FILE = "Removed File";
    const AL_APPROVE = "Approved";
    const AL_PUBLISH = "Published";
    const AL_UNPUBLISH = "Unpublished";
    const AL_SEND = "Sent";
    const AL_UNSUBSCRIBE = "Unsubscribed";
    const AL_SUBSCRIBE = "Subscribed";
    const AL_RESET_PASSWORD = "Reset Password";
    const AL_ADD_CATEGORY = "Added Category";
    const AL_EDIT_CATEGORY = "Updated Category";
    const AL_DELETE_CATEGORY = "Deleted Category";
    const AL_DELETE_ALL_CATEGORY = "Deleted All Categories";
    const AL_EDIT_EMAIL_SETTINGS = "Updated Email Settings";
    const AL_EDIT_PODCAST_SETTINGS = "Updated Podcast Subscribe Text";
    const AL_VIEW_ATTENDEE = "Viewed Attendee";
    const AL_UPGRADE = "Upgraded Account";
    const AL_DEACTIVATE = "Deactivated Account";
    const AL_APPROVED = "Approved Account";
    const AL_EXPORT_ATTENDEE = "Exported Attendee";
    const AL_DELETE_ATTENDEE = "Deleted Attendee";
    const AL_DELETE_ALL_ATTENDEE = "Deleted All Attendee";
    const AL_UPDATE_ALL_CAT = "Updated All Category";
    const AL_APPROVE_ALL = "Approved All";
    const AL_PUBLISH_ALL = "Published All";
    const AL_UNPUBLISH_ALL = "Unpublished All";
    const AL_SUBSCRIBE_ALL = "Subscribed All";
    const AL_UNSUBSCRIBE_ALL = "Unsubscribed All";
    const AL_ADD_QUESTION = "Added Question";
    const AL_EDIT_QUESTION = "Updated Question";
    const AL_DELETE_QUESTION = "Deleted Question";
    const AL_DELETE_QUESTION_ALL = "Deleted All Question";
    const AL_VIEW_RESULTS = "Viewed Results";
    const AL_VIEW_RESPONSE = "Viewed Response";
    const AL_DELETE_RESPONSE = "Deleted Response";
    const AL_DELETE_RESPONSE_ALL = "Deleted All Response";
    const AL_ADD_FORM_TYPE = "Added Form Type";
    const AL_EDIT_FORM_TYPE = "Updated Form Type";
    const AL_DELETE_FORM_TYPE = "Deleted Form Type";
    const AL_DELETE_ALL_FORM_TYPE = "Deleted All Form Types";
    const AL_ENABLE = "Enable";
    const AL_DISABLE = "Disable";
    const AL_REMOVE_LOGO = "Remove Logo";
    const AL_CHANGE_PASSWORD = "Change Password";
    const AL_EXPORT_ACTION = "Exported Login Action";
    const AL_EXPORT_HISTORY = "Exported Login History";
    const AL_DRAFT = "Saved as Draft";
    const AL_CONTACTED = "Contacted";
    const ALT_UPLOAD = "Uploaded";
    
    // ADMIN ACTIONS TITLE
    const ALT_EMAIL_SETTINGS = "Email Settings Recipient & RTE";
    const ALT_EMAIL_SETTINGS_RECIPIENT = "Email Settings Recipient";
    const ALT_EMAIL_SETTINGS_RTE = "Email Settings RTE";
    const ALT_PODCAST_SETTINGS = "Podcast Subscribe Text";
    const ALT_EXPORT = "Export CSV";
    const ALT_IMPORT = "Import CSV";
    const ALT_SEO = "Metadata";
    const ALT_GENERAL = "General Settings";
    const ALT_MODULES = "Modules Settings";
    const ALT_PASSWORD = "Password Settings";
    const ALT_LOGIN_HISTORY = "Login History Settings";
    const ALT_SEO_GA = "Google Analytics";
    const ALT_SEO_UPLOADS = "SEO Uploads";
    const ALT_SEO_ROBOTS = "Robots";
    
    //ADMIN MODULES
    const AM_PAGE = "Page Manager";
    const AM_CONTACT_US = "Contact Us Manager";
    const AM_SEO = "SEO Manager";
    const AM_ACCOUNT = "Accounts Manager";
    const AM_NEWSLETTER = "Newsletter Manager";
    const AM_MAILING_LIST = "Mailing List Manager";
    const AM_SETTINGS = "Settings";
    const AM_DEFAULT = "Defaults Manager";
    const AM_MRI = "MRI Manager";
    const AM_NOTIFICATIONS = "Notifications Manager";
    const AM_TESTIMONIALS = "Testimonials Manager";
}

?>