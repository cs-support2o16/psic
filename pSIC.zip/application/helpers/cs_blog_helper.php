<?php

if (!function_exists('create_blog_url'))
{
	function create_blog_url($blog_title){
		
		$url_key = strtolower($blog_title);
		
		$url_key = trim(preg_replace('/-/', '', $url_key));
		
		$url_key = preg_replace('/[\s]+/', '-', $url_key);
		
		return $url_key;
	
	}

}

if (!function_exists('return_blog_title_from_url'))
{
	function return_blog_title_from_url($blog_url_key){
		
		$blog_title = trim(preg_replace('/-/', ' ', $blog_url_key));
		
		$blog_title = ucwords($blog_title);
		
		return $blog_title;
	
	}

}

if (!function_exists('get_forbidden_characters'))
{
	function get_forbidden_characters(){
		
		 //Reference links: http://tools.oratory.com/altcodes.html
        $forbid = array('�', 'Ç', 'ü', 'é', 'â', 'ä', 'à', 'å', 'ç', 'ê', 'ë', 'è', 'ï', 'î', 'ì', 'æ', 'Æ', 'ô', 'ö', 'ò', 'û', 'ù', 'ÿ', '¢', '£', '¥', 'ƒ', 'á', 'í', 'ó', 'ú', 'ñ', 'Ñ', 'Š', 'š', 'œ', '™', 'À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'Þ', 'ã', 'ð', 'õ', 'ø', 'ü', 'ý', 'þ', "'", '--', '&quot;', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '+', '{', '}', '|', ':', '"', '<', '>', '?', '[', ']', '\\', ';', ',', '/', '*', '+', '~', '`', '=', "amp;");

        return $forbid;
	
	}

}

if (!function_exists('create_url_slug'))
{
function create_url_slug($string){
   $string = strtolower($string);
   $slug=preg_replace('/[^A-Za-z0-9-]+/', '-', $string);
   return $slug;
}

}
?>