<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

if (!function_exists('template_dropdown')) {

    /**
     * Return an associative array containing months of the year.
     *
     * @return array.
     */
    function template_dropdown() {
        $data = array();
        $ci = & get_instance();
        $ci->load->helper('file');
        $templates = get_filenames(APPPATH . 'views/default/templates');
        foreach ($templates as $_template) {

            $data[$_template] = $_template;
        }
        return $data;
    }

}

if (!function_exists('month_dropdown')) {

    /**
     * Return an associative array containing months of the year.
     *
     * @return array.
     */
    function month_dropdown() {
        return array(
            '' => '-Month-',
            1 => 'January',
            2 => 'February',
            3 => 'March',
            4 => 'April',
            5 => 'May',
            6 => 'June',
            7 => 'July',
            8 => 'August',
            9 => 'September',
            10 => 'October',
            11 => 'November',
            12 => 'December'
        );
    }

}

// --------------------------------------------------------------------

if (!function_exists('day_dropdown')) {

    /**
     * Return an associative array containing days of the week.
     *
     * @return array.
     */
    function day_dropdown() {
        return array(
            1 => 'Monday',
            2 => 'Tuesday',
            3 => 'Wednesday',
            4 => 'Thursday',
            5 => 'Friday',
            6 => 'Saturday',
            7 => 'Sunday'
        );
    }

}

// --------------------------------------------------------------------

if (!function_exists('date_dropdown')) {

    /**
     * Return an associative array containing dates of the month.
     */
    function date_dropdown() {
        $dates[''] = '-Date-';
        for ($i = 1; $i <= 31; $i++) {
            $dates[$i] = $i;
        }

        return $dates;
    }

}

// --------------------------------------------------------------------

if (!function_exists('p_month_dropdown')) {

    /**
     * Return an associative array containing dates of the month.
     */
    function p_month_dropdown() {
        $dates[''] = 'MM';
        for ($i = 1; $i <= 12; $i++) {
        if($i < 9) { 
            $i = "0" + $i;
        }    
            $dates[$i] = $i;
         
    
        }

        return $dates;
    }

}


// --------------------------------------------------------------------

if (!function_exists('p_month_dropdown')) {

    /**
     * Return an associative array containing dates of the month.
     */
    function p_month_dropdown() {
        $dates[''] = '-MM-';
        for ($i = 1; $i <= 12; $i++) {
            $dates[$i] = $i;
        }

        return $dates;
    }

}

// --------------------------------------------------------------------

if (!function_exists('year_dropdown')) {

    function year_dropdown($start = 1930, $end = null) {
        $years[''] = '-Year-';
        if ($end == null) {
            $end = date('Y');
        }

        while ($start <= $end) {
            $years[$start] = $start;
            $start++;
        }

        return $years;
    }

}

// --------------------------------------------------------------------

if (!function_exists('state_dropdown')) {

    function state_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_states');

        $states = $ci->m_states->fetch_all();

        $a_states[''] = '--select a state--';

        foreach ($states->result() as $state) {
            $a_states[$state->state_id] = $state->state_name;
        }

        return $a_states;
    }

}

// --------------------------------------------------------------------

if (!function_exists('state_name_dropdown')) {

    function state_name_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_states');

        $states = $ci->m_states->fetch_all();

        $a_states[''] = '--select a state--';

        foreach ($states->result() as $state) {
            $state_name = ucwords($state->state_name);
            $a_states[$state_name] = ucwords($state->state_name);
        }

        return $a_states;
    }

}

// --------------------------------------------------------------------

if (!function_exists('country_dropdown')) {

    function country_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_country');

        $countries = $ci->m_country->fetch_all();

        $a_country[''] = '--select a country--';

        foreach ($countries->result() as $country) {
            $a_country[$country->country_id] = $country->name;
        }

        return $a_country;
    }

}

// --------------------------------------------------------------------

if (!function_exists('country_name_dropdown')) {

    function country_name_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_country');

        $countries = $ci->m_country->get_all();

        $a_country[''] = '--select a country--';

        foreach ($countries->result() as $country) {
            $a_country[$country->name] = $country->name;
        }

        return $a_country;
    }

}

// --------------------------------------------------------------------

if (!function_exists('gender_dropdown')) {

    function gender_dropdown() {
        $gender[''] = '--select a gender--';
        $gender['Male'] = 'Male';
        $gender['Female'] = 'Female';

        return $gender;
    }

}

// --------------------------------------------------------------------

if (!function_exists('seminar_category_dropdown')) {

    function seminar_category_dropdown() {

        return array(
            '' => '-Select-',
            'bariatric_surgery' => 'Bariatric Surgery',
            'diabetes_surgery' => 'Diabetes Surgery',
            'rose_procedure' => 'Rose Procedure',
        );
    }

}

// --------------------------------------------------------------------

if (!function_exists('how_heard_dropdown')) {

    /**
     * Return an associative array containing how you've heard about us.
     *
     * @return array.
     */
    function how_heard_dropdown() {

        return array(
            '' => '-Select-',
            'doctor' => 'Doctor',
            'friend_or_family' => 'Friend/Family',
            'online_search' => 'Online Search',
            'other' => 'Other'
        );
    }

}


// --------------------------------------------------------------------

if (!function_exists('number_dropdown')) {

    /**
     * Return an array of numbers from $start to $limit.
     *
     * @param int $limit
     * @return array
     */
    function number_dropdown($start = 0, $limit) {
        while ($start <= $limit) {
            $numbers[$start] = $start;
            $start++;
        }

        return $numbers;
    }

}

// --------------------------------------------------------------------

if (!function_exists('time_dropdown')) {

    /**
     * Returns an array of times of the day.
     *
     * @return array
     */
    function time_dropdown() {
        $times = array();
        $time = strtotime("00:00:00");
        $times[""] = "--select--";
        for ($i = 1; $i < 48; $i++) {
            $time = strtotime("+ 30 minutes", $time);
            $key = date("g:i A", $time); //date("H:i:s",$time);
            $times[$key] = $key; //date("g:i a",$time);
        }

        return $times;
    }

}

// --------------------------------------------------------------------

if (!function_exists('question_type_dropdown')) {

    /**
     * Returns an array of survey question types.
     *
     * @return array
     */
    function question_type_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_survey_question_types');

        $question_types = $ci->m_survey_question_types->fetch_all();

        $a_question_types[''] = '--select type--';

        foreach ($question_types->result() as $question_type) {
            $a_question_types[$question_type->type_of_question_id] = $question_type->question_description;
        }

        return $a_question_types;
    }

}

// --------------------------------------------------------------------

if (!function_exists('survey_dropdown')) {

    /**
     * Returns an array of surveys.
     *
     * @return array
     */
    function survey_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_survey');

        $surveys = $ci->m_survey->fetch_all();

        $a_surveys[''] = '----';

        foreach ($surveys->result() as $survey) {
            $a_surveys[$survey->survey_id] = $survey->survey_description;
        }

        return $a_surveys;
    }

}

// --------------------------------------------------------------------

if (!function_exists('questions_dropdown')) {

    /**
     * Returns an array of available questions.
     *
     * @return array
     */
    function questions_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_survey_questions', 'survey_questions');

        $questions = $ci->survey_questions->fetch_all();

        $a[''] = '--select question--';

        foreach ($questions->result() as $question) {
            $a[$question->question_id] = $question->question_details;
        }

        return $a;
    }

}

// --------------------------------------------------------------------

if (!function_exists('yes_no_dropdown')) {

    /**
     * Returns an array of yes and no.
     *
     * @return array
     */
    function yes_no_dropdown() {
        return array(1 => 'Yes', 0 => 'No');
    }

}

// --------------------------------------------------------------------

if (!function_exists('page_url_dropdown')) {

    /**
     * Returns an array of all pages and their URL as the key.
     *
     * @return array
     */
    function page_url_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_page', 'pages');
        $ci->load->library('CS_Url_Tree', null, 'tree');

        $pages = $ci->pages->fetch_all();

        $a_pages = array();

        if ($pages->num_rows() > 0) {
            foreach ($pages->result() as $page) {
                $ci->tree->id_page = $page->id_page;
                $a_pages[$ci->tree->get_link()] = $page->url_key;
                $ci->tree->clear();
            }
        }

        return $a_pages;
    }

}

// --------------------------------------------------------------------

if (!function_exists('target')) {

    /**
     * Returns an array of "target" for anchors.
     *
     * @return array
     */
    function target_dropdown() {
        return array('' => 'Current window', '_blank' => 'New Window');
    }

}

// --------------------------------------------------------------------

if (!function_exists('question2_type_dropdown')) {

    /**
     * Returns an array of self_assessment question types.
     *
     * @return array
     */
    function question2_type_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_self_assessment_question_types');

        $question_types = $ci->m_self_assessment_question_types->fetch_all();

        $a_question_types[''] = '--select type--';

        foreach ($question_types->result() as $question_type) {
            $a_question_types[$question_type->type_of_question_id] = $question_type->question_description;
        }

        return $a_question_types;
    }

}

// --------------------------------------------------------------------

if (!function_exists('self_assessment_dropdown')) {

    /**
     * Returns an array of self_assessments.
     *
     * @return array
     */
    function self_assessment_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_self_assessment');

        $self_assessments = $ci->m_self_assessment->fetch_all();

        $a_self_assessments[''] = '----';

        foreach ($self_assessments->result() as $self_assessment) {
            $a_self_assessments[$self_assessment->self_assessment_id] = $self_assessment->self_assessment_description;
        }

        return $a_self_assessments;
    }

}

// --------------------------------------------------------------------

if (!function_exists('questions2_dropdown')) {

    /**
     * Returns an array of available questions.
     *
     * @return array
     */
    function questions2_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_self_assessment_questions', 'self_assessment_questions');

        $questions = $ci->self_assessment_questions->fetch_all();

        $a[''] = '--select question--';

        foreach ($questions->result() as $question) {
            $a[$question->question_id] = $question->question_details;
        }

        return $a;
    }

}

// --------------------------------------------------------------------

if (!function_exists('user_category_dropdown')) {

    function user_category_dropdown() {
        $category[''] = '--select role--';
        $category['administrator'] = 'GSO Admin';
        $category['GSO staff'] = 'GSO Staff';

        return $category;
    }

}

// --------------------------------------------------------------------

if (!function_exists('employee_department_dropdown')) {

    function employee_department_dropdown() {
        $department[""] = "--select department--";
        $department["Association of the Baranggay Captains"] = "Association of the Baranggay Captains";
        $department["Business, Permits & Licensing Office"] = "Business, Permits & Licensing Office";
        $department["City Accounting and  Internal Audit Services Office"] = "City Accounting and  Internal Audit Services Office";
        $department["City Assessor's Office"] = "City Assessor's Office";
        $department["City Budget Office"] = "City Budget Office";
        $department["City Civil Registrar"] = "City Civil Registrar";
        $department["City Disaster Risk Reduction Management Office"] = "City Disaster Risk Reduction Management Office";
        $department["City Engineering Office"] = "City Engineering Office";
        $department["City Environment and Natural Resource Office"] = "City Environment and Natural Resource Office";
        $department["City General Services Office"] = "City General Services Office";
        $department["City Health Office"] = "City Health Office";
        $department["City Information Office"] = "City Information Office";
        $department["City Information Technology & Records Management Unit"] = "City Information Technology & Records Management Unit";
        $department["City of Imus Cooperative Development Office"] = "City of Imus Cooperative Development Office";
        $department["City Planning and Development Office"] = "City Planning and Development Office";
        $department["City Social Welfare and Development Office"] = "City Social Welfare and Development Office";
        $department["City Tourism Development Office"] = "City Tourism Development Office";
        $department["City Treasurer's Office"] = "City Treasurer's Office";
        $department["Civil Security Unit"] = "Civil Security Unit";
        $department["Cluster Offices"] = "Cluster Offices";
        $department["Economic Enterprise and Management Office"] = "Economic Enterprise and Management Office";
        $department["Extension Office (Bahayang Pag-asa)"] = "Human Resource and Mangement Unit";
        $department["Imus Vocational and Technical School"] = "Imus Vocational and Technical School";
        $department["Library Office"] = "Library Office";
        $department["Office of the Building Official"] = "Office of the Building Official";
        $department["Office of the City Administrator"] = "Office of the City Administrator";
        $department["Office of the City Agriculturist"] = "Office of the City Agriculturist";
        $department["Office of the City Legal"] = "Office of the City Legal";
        $department["Office of the City Mayor"] = "Office of the City Mayor";
        $department["Office of the City Veterinarian"] = "Office of the City Veterinarian";
        $department["Office of the City Vice-Mayor"] = "Office of the City Vice-Mayor";
        $department["Office of the Sangguniang Panlungsod"] = "Office on Architectural Planning and Design";
        $department["Office on Population Development"] = "Office on Population Development";
        $department["Parks and Historical Sites Administration"] = "Parks and Historical Sites Administration";
        $department["Persons with Disability Affairs Office"] = "Persons with Disability Affairs Office";
        $department["Public Employment Service Office"] = "Public Employment Service Office";
        $department["Satellite Office (Robinsons Imus)"] = "Satellite Office (Robinsons Imus)";
        $department["Senior Citizen's Office"] = "Senior Citizen's Office";
        $department["Sports Development Unit"] = "Sports Development Unit";
        $department["Traffic Management Unit"] = "Traffic Management Unit";
        $department["Tricycle Regulatory Unit"] = "Tricycle Regulatory Unit";

        return $department;
    }

}


// --------------------------------------------------------------------

if (!function_exists('specialty_dropdown')) {

    /**
     * Return an associative array containing months of the year.
     *
     * @return array.
     */
    function specialty_dropdown() {
        return array(
            '' => '-select specialty-',
            "I don't know" => "I don't know",
            "Primary Care" => "Primary Care",
            "Pediatrician" => "Pediatrician",
            "Cardiologist" => "Cardiologist",
            "Endocrinologist" => "Endocrinologist",
            "Nephrologist" => "Nephrologist",
            "Family Practitioner" => "Family Practitioner",
            "Plastic Surgeon" => "Plastic Surgeon",
            "Gastroenterologist" => "Gastroenterologist",
            "Podiatrist" => "Podiatrist",
            "Dermatologist" => "Dermatologist",
            "Oncologist" => "Oncologist",
            "Internist" => "Internist",
            "Orthopedic Surgeon" => "Orthopedic Surgeon",
            "Hematologist" => "Hematologist",
            "Registered Dietitian/Nutritionist" => "Registered Dietitian/Nutritionist",
            "Personal Trainer" => "Personal Trainer",
            "Exercise Physiologist" => "Exercise Physiologist",
            "Chiropractor" => "Chiropractor",
            "Oral Surgeon/Dentist" => "Oral Surgeon/Dentist",
            "Nurse" => "Nurse",
            "Psychologist" => "Psychologist",
            "Counselor" => "Counselor",
            "Psychiatrist" => "Psychiatrist",
            "Other" => "Other"
        );
    }

    function insurance_dropdown() {
        return array(
            '' => 'Select Insurance',
            'Medicaid' => 'Medicaid',
            'Medicare' => 'Medicare',
            'Tricare' => 'Tricare',
            'Champva' => 'Champva',
            'Coventry' => 'Coventry',
            'UMR' => 'UMR',
            'Peachstate' => 'Peachstate',
            'Highmark' => 'Highmark',
            'AETNA' => 'AETNA',
            'BCBS' => 'BCBS',
            'CIGNA' => 'CIGNA',
            'United Healthcare' => 'United Healthcare',
            'Wellcare' => 'Wellcare'
        );
    }

}
// --------------------------------------------------------------------

if (!function_exists('crm_field_dropdown')) {

    /**
     * Return an array containing crm fields.
     *
     * @return array.
     */
    function crm_field_dropdown() {
        return array(
            '' => 'Select',
            'fname' => 'First Name',
            'lname' => 'Last Name',
            'number' => 'Phone',
            'zip' => 'Zip',
            'email' => 'Email',
            'code' => 'Status'
        );
    }

}
// --------------------------------------------------------------------

if (!function_exists('show_perpage_dropdown')) {

    /**
     * Return an array containing show limits.
     *
     * @return array.
     */
    function show_perpage_dropdown() {
        return array(
            '10' => '10',
            '50' => '50',
            '100' => '100',
            '200' => '200'
        );
    }

}

// --------------------------------------------------------------------

if (!function_exists('zip_from_dropdown')) {

    /**
     * Return an array containing show limits.
     *
     * @return array.
     */
    function zip_from_dropdown() {
        return array(
            '' => 'Zip Code - From',
            '10000' => '10000',
            '20000' => '20000',
            '30000' => '30000',
            '40000' => '40000',
            '50000' => '50000',
            '60000' => '60000',
            '70000' => '70000',
            '80000' => '80000',
            '90000' => '90000'
        );
    }

}

// --------------------------------------------------------------------

if (!function_exists('zip_to_dropdown')) {

    /**
     * Return an array containing show limits.
     *
     * @return array.
     */
    function zip_to_dropdown() {
        return array(
            '' => 'Zip Code - To',
            '19999' => '19999',
            '29999' => '29999',
            '39999' => '39999',
            '49999' => '49999',
            '59999' => '59999',
            '69999' => '69999',
            '79999' => '79999',
            '89999' => '89999',
            '99999' => '99999',
        );
    }

}
// --------------------------------------------------------------------

if (!function_exists('crm_status_dropdown')) {

    /**
     * Return an array containing crm status data.
     *
     * @return array.
     */
    function crm_status_dropdown($status_id = null) {
        $ci = & get_instance();

        $ci->load->model('default/m_crm_status');

        $crm_status = $ci->m_crm_status->fetch_all();

        $crm_status_array[''] = 'Status';

        foreach ($crm_status->result() as $cs) {
            if ($cs->status_id != $status_id) {
                $crm_status_array[$cs->status_id] = 'Status ' . $cs->code . ' - ' . $cs->description;
            }
        }

        return $crm_status_array;
    }

}

// --------------------------------------------------------------------

if (!function_exists('crm_status_code_dropdown')) {

    /**
     * Return an array containing crm status data.
     *
     * @return array.
     */
    function crm_status_code_dropdown($status_id = null) {
        $ci = & get_instance();

        $ci->load->model('default/m_crm_status');

        $crm_status = $ci->m_crm_status->fetch_all();

        $crm_status_array[''] = 'Status';

        foreach ($crm_status->result() as $cs) {
            if ($cs->status_id != $status_id) {
                $crm_status_array[$cs->code] = 'Status ' . $cs->code;
            }
        }

        return $crm_status_array;
    }

}

// --------------------------------------------------------------------

if (!function_exists('module_dropdown')) {

    /**
     * Return an associative array containing months of the year.
     *
     * @return array.
     */
    function module_dropdown() {
        return array(
            '' => '-Select Module-',
            Constant::AM_ACCOUNT => Constant::AM_ACCOUNT,
            Constant::AM_CONTACT_US => Constant::AM_CONTACT_US,
            Constant::AM_DEFAULT => Constant::AM_DEFAULT,
            Constant::AM_MAILING_LIST => Constant::AM_MAILING_LIST,
            Constant::AM_MRI => Constant::AM_MRI,
            Constant::AM_NEWSLETTER => Constant::AM_NEWSLETTER,
            Constant::AM_NOTIFICATIONS => Constant::AM_NOTIFICATIONS,
            Constant::AM_PAGE => Constant::AM_PAGE,
            Constant::AM_SEO => Constant::AM_SEO,
            Constant::AM_TESTIMONIALS => Constant::AM_TESTIMONIALS,
            Constant::AM_SETTINGS => Constant::AM_SETTINGS
        );
    }

}

// --------------------------------------------------------------------

if (!function_exists('blog_category_dropdown')) {

    function blog_category_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_blog_category');

        $blog_category = $ci->m_blog_category->fetch_all();

        $blog_category_array[''] = 'Select Category';

if($ci->uri->segment(2)=='category' || $ci->uri->segment(2)=='categories'){
        foreach ($blog_category->result() as $cs) {
            $blog_category_array[$cs->title] = $cs->title;
      }
}else{
        foreach ($blog_category->result() as $cs) {
            $blog_category_array[$cs->blog_category_id] = $cs->title;
      }
            
    }


        return $blog_category_array;
    }

}

// --------------------------------------------------------------------

if (!function_exists('inventory_category_dropdown')) {

    function inventory_category_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_inventory_category');

        $inventory_category = $ci->m_inventory_category->fetch_all();

        $inventory_category_array[''] = 'Select Category';

if($ci->uri->segment(2)=='category' || $ci->uri->segment(2)=='categories'){
        foreach ($inventory_category->result() as $cs) {
            $inventory_category_array[$cs->title] = $cs->title;
      }
}else{
        foreach ($inventory_category->result() as $cs) {
            $inventory_category_array[$cs->inventory_category_id] = $cs->title;
      }
            
    }


        return $inventory_category_array;
    }

}
// --------------------------------------------------------------------

if (!function_exists('blog_archive_dropdown')) {

    function blog_archive_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_blog');

        $blog_archive = $ci->m_blog->fetch_archive();

        $blog_archive_array[''] = 'Select Month';

        foreach ($blog_archive->result() as $cs) {
            $blog_archive_array[$cs->archive_url] = $cs->archive_date;
            
        }

        return $blog_archive_array;
    }

}
// --------------------------------------------------------------------

 if (!function_exists('ga_position_dropdown')) {

                /**
                 * Returns an array of "target" for anchors.
                 *
                 * @return array
                 */
                function ga_position_dropdown() {
                    return array('' => 'Select', 'head' => "Before end of head tag", 'body' => 'Before end of body tag');
                }

            }


// --------------------------------------------------------------------

if (!function_exists('p_year_dropdown')) {

    function p_year_dropdown($start = 1980, $end = null) {
        $years[''] = 'YY';
        if ($end == null) {
            $end = date('Y');
        }

        while ($start <= $end) {
            $years[$start] = $start;
            $start++;
        }

        return $years;
    }

}

// --------------------------------------------------------------------

if (!function_exists('prefix_dropdown')) {

    function prefix_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_inventory_category');

        $prefix = $ci->m_inventory_category->fetch_all();

        $prefix_arr[''] = 'PPPP';

        foreach ($prefix->result() as $pref) {
            $prefix_arr[$pref->inventory_category_id] = $pref->title;
        }

        return $prefix_arr;
    }

}
// --------------------------------------------------------------------

if (!function_exists('gso_employee_dropdown')) {

    function gso_employee_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_employee');

        $emp = $ci->m_employee->fetch_all_gso();

        $emp_arr[''] = '- Select -';

        foreach ($emp->result() as $empl) {
            $d = $empl->firstname.' '.$empl->middlename.' '.$empl->lastname.' - '.$empl->position;
            $emp_arr[$d] = $d;
        }

        return $emp_arr;
    }

// --------------------------------------------------------------------

if (!function_exists('employee_dropdown')) {

    function employee_dropdown() {
        $ci = & get_instance();

        $ci->load->model('default/m_employee');

        $emp1 = $ci->m_employee->fetch_all_emp();

        $emp1_arr[''] = '- Select -';

        foreach ($emp1->result() as $emp2) {
            $a = $emp2->firstname.' '.$emp2->middlename.' '.$emp2->lastname.' - '.$emp2->department.' - '.$emp2->position;
            $emp1_arr[$a] = $a;
        }

        return $emp1_arr;
    }
}

}
/* End of file cs_dropdown_helper.php */
/* Location: ./application/application/helpers/cs_dropdown_helper.php */