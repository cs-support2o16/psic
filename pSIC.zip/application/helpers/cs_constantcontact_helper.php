<?php
if (!function_exists('add_constantcontact')) {

    /**
     * Save admin login action
     */
    function add_constantcontact($params = null) {
        $ci = & get_instance();
        if ($params != null) {

           // require the autoloaders
            
            require_once 'constant_contact/autoload.php';
            
         
            $_list = '1876366985'; //LISTNAME = General Interest
            $_APIKEY = '9c9ph7a4kbv8dve8u5ek8qh5'; //API KEY
            $_ACCESS_TOKEN = '7cabdbf5-5902-4e8c-812b-e8e19833a61e'; //ACCESS_TOKEN

            $cc = new cc();
	    $cc->add_update_contact($params, $_list, $_APIKEY, $_ACCESS_TOKEN);
          
            
        }
    }

}
?>