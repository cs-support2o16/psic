<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if (!function_exists('set_template'))

{

    /**

     * Set the page template

     */

    function set_template($url_key)

    {

		$data = array();

		$ci =& get_instance();



		$default_tpl = $ci->get_setting('inner_template');

		

		switch($url_key){


			default:

				$template = $default_tpl;

		}

		

		return 'default/templates/' . $template;

	

    }

}



/* End of file cs_dropdown_helper.php */

/* Location: ./application/application/helpers/cs_template_helper.php */