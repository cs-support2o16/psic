<?php

if (!function_exists('get_age')) {

    function get_age($p_strDate, $separator = "-") {
        list($m, $d, $Y) = explode($separator, $p_strDate);

        return( date("md") < $m . $d ? date("Y") - $Y - 1 : date("Y") - $Y );
    }

}

if (!function_exists('get_url_key')) {

    /**
     * Get the url key of current page
     * @param string $method - the method of the current class
     * @return string
     */
    function get_url_key($method = NULL) {
        $ci = & get_instance();
        if ($method) {
            $url_key = '';
            $methodFound = FALSE;
            $uri_segment = $ci->uri->segment_array();
            $view_key = '';
            foreach ($uri_segment as $key => $value) {
                if ($value == $method) {
                    $view_key = $key;
                    $methodFound = TRUE;
                }
            }
            $url_key = ($methodFound) ? $uri_segment[$view_key - 1] : end($uri_segment);
        } else {
            $url_key = $ci->get_current_module();
        }
        return $url_key;
    }

}

if (!function_exists('merge_data')) {

    /**
     * Merge two data arrays with distinction
     * @param array $base_data - the base data array
     * @param array $data_to_filter - the array to filter
     * @return null
     */
    function merge_data($base_data, $data_to_filter) {

        $filtered_view_data = array();
        $page_data = array_keys($base_data);
        foreach ($data_to_filter as $key => $val) {
            if (!in_array($key, $page_data)) {
                $filtered_view_data[$key] = $val;
            }
        }
        return $filtered_view_data;
    }

}

if (!function_exists('get_absolute_url_key')) {

    // Get absolute link
    function get_absolute_url_key($id_page) {
        $ci = & get_instance();
        $ci->load->library('CS_Url_Tree', null, 'tree');
        $ci->tree->clear();
        $ci->tree->id_page = $id_page;
        return $ci->tree->get_link();
    }

}

if (!function_exists('enable_recaptcha')) {

    /**
     * Adds the captcha validation config to the validation rules specified in $config.
     *
     * @param string $config Name of the config index.
     *
     * @return null
     */
    function enable_recaptcha($config) {

        $ci = & get_instance();

        $ci->load->config('recaptcha');
        $ci->load->config('validations');

        $recaptcha_config = $ci->config->item('validate_recaptcha');
        $form_config = $ci->config->item($config);
        $ci->config->set_item($config, array_merge($form_config, array($recaptcha_config)));
    }

}

if (!function_exists('enable_ayacaptcha')) {

    /**
     * Adds the Ayacaptcha validation config to the validation rules specified in $config.
     *
     * @param string $config Name of the config index.
     *
     * @return null
     */
    function enable_ayacaptcha($config) {

        $ci = & get_instance();

        $ci->load->config('ayacaptcha');
        $ci->load->config('validations');

        $recaptcha_config = $ci->config->item('validation_ayacaptcha');
        $form_config = $ci->config->item($config);
        $ci->config->set_item($config, array_merge($form_config, array($recaptcha_config)));
    }

}

if (!function_exists('enable_extra_field')) {

    /**
     * Adds the how_heard_other validation config to the validation rules specified in $config.
     *
     * @param string $config Name of the config index.
     *
     * @return null
     */
    function enable_extra_field($config) {

        $ci = & get_instance();

        $ci->load->config('extra_field');
        $ci->load->config('validations');

        $extra_field_config = $ci->config->item('validate_extra_field');
        $form_config = $ci->config->item($config);
        $ci->config->set_item($config, array_merge($form_config, array($extra_field_config)));
    }

}

/**
 * Get domain
 *
 * Return the domain name only based on the "base_url" item from your config file.
 *
 * @access    public
 * @return    string
 */
if (!function_exists('getDomain')) {

    function getDomain() {
        $CI = & get_instance();
        return preg_replace("/^[\w]{2,6}:\/\/([\w\d\.\-]+).*$/", "$1", $CI->config->slash_item('base_url'));
    }

}


if (!function_exists('html2text')) {

    function html2text($html) {
        $search = ARRAY("'<script[^>]*?>.*?</script>'si", // Strip out javascript
            "'<[/!]*?[^<>]*?>'si", // Strip out HTML tags
            "'([rn])[s]+'", // Strip out white space
            "'&(quot|#34);'i", // Replace HTML entities
            "'&(amp|#38);'i",
            "'&(lt|#60);'i",
            "'&(gt|#62);'i",
            "'&(nbsp|#160);'i",
            "'&(iexcl|#161);'i",
            "'&(cent|#162);'i",
            "'&(pound|#163);'i",
            "'&(copy|#169);'i",
            "'&#(d+);'e");                    // evaluate as php

        $replace = ARRAY("",
            "",
            "\1",
            "\"",
            "&",
            "<",
            ">",
            " ",
            CHR(161),
            CHR(162),
            CHR(163),
            CHR(169),
            "chr(\1)");

        return PREG_REPLACE($search, $replace, $html);
    }

}


if (!function_exists('upload_crm_attachment')) {

    function upload_crm_attachment($type, $name) {
        $ci = & get_instance();
        $config['upload_path'] = str_replace('system/', '', BASEPATH) . 'uploads/crm/' . $type;

        $config['overwrite'] = FALSE;
        $config['encrypt_name'] = TRUE;
        $config['allowed_types'] = 'gif|jpg|png|doc|docx|xlsx|word|xl|txt|pdf';
        $config['max_size'] = '2000';

        $ci->load->library('upload');
        $ci->upload->initialize($config);

        if (!$ci->upload->do_upload($name)) {
            $upload_file = array('error' => $ci->upload->display_errors('<div class="red">', '</div>'));
        } else {
            $upload_file = array('data' => $ci->upload->data());
        }
        return $upload_file;

    }

}

if (!function_exists('save_crm_admin_action')) {

    /**
     * Save admin login action
     */
    function save_crm_admin_action($params = NULL) {
        $ci = & get_instance();
        if ($params != null) {
            $title = $params['title'];
            if (isset($params['object_ids'])) {

                $title = str_replace(',', ', ', $params['title']);
            }
            $data = array(
                'id_admin' => $ci->session->userdata('id_admin'),
                'action' => $params['action'],
                'title' => $title,
                'object_id' => isset($params['object_id']) ? $params['object_id'] : '0',
                'object_ids' => isset($params['object_ids']) ? $params['object_ids'] : '0',
            );
            $ci->M_crm_transaction->do_save($data);
        }
        return;
    }

}


if (!function_exists('save_admin_login')) {

    /**
     * Save admin login history
     */
    function save_admin_login($type = NULL) {
        $ci = & get_instance();
        if ($type != null) {
            $ci->load->model('default/M_admin_login');
            $ci->load->model('default/M_admin_action');
            if ($type == 'login') {
                $data = array(
                    'id_admin' => $ci->session->userdata('id_admin'),
                    'login_date' => date('Y-m-d H:i:s'),
                );
                $ci->M_admin_login->do_save($data);
                $admin_login_id = $ci->db->insert_id();
                $ci->session->set_userdata('admin_login_id', $admin_login_id);

                //save missing logout date
                $missing_logout = $ci->M_admin_login->find_missing_logout_date($ci->session->userdata('id_admin'));
                foreach ($missing_logout as $ml) {
                    $logout_date = $ci->M_admin_action->get_last_activity_date($ml['admin_login_id']);

                    $end_time = date("Y-m-d H:i:s", strtotime("+15 minutes", strtotime($logout_date)));
                    if ($logout_date == '') {
                        $end_time = date("Y-m-d H:i:s", strtotime("+15 minutes", strtotime($ml['login_date'])));
                    }

                    $ci->M_admin_login->save_missing_logout_date($ml['admin_login_id'], $end_time);
                }
            } else if ($type == 'logout') {
                $admin_login = $ci->M_admin_login->get($ci->session->userdata('admin_login_id'));
                if ($admin_login) {
                    if ($admin_login->login_date == '' || $admin_login->login_date == '0000-00-00 00:00:00') {
                        $ci->M_admin_login->delete($ci->session->userdata('admin_login_id'));
                    } else {
                        $data = array(
                            'admin_login_id' => $ci->session->userdata('admin_login_id'),
                            'logout_date' => date('Y-m-d H:i:s'),
                        );
                        $ci->M_admin_login->do_save($data);
                        $ci->session->unset_userdata('admin_login_id');
                    }
                }
            }
        }
        return;
    }

}


if (!function_exists('save_admin_action')) {

    /**
     * Save admin login action
     */
    function save_admin_action($params = NULL) {
        $ci = & get_instance();
        if ($params != null) {
            $ci->load->model('default/M_admin_action');
            $title = $params['title'];
            if (isset($params['object_ids'])) {

                $title = str_replace(',', ', ', $params['title']);
            }
            $data = array(
                'id_admin' => $ci->session->userdata('id_admin'),
                'admin_login_id' => $ci->session->userdata('admin_login_id'),
                'module' => $params['module'],
                'action' => $params['action'],
                'title' => $title,
                'object_id' => isset($params['object_id']) ? $params['object_id'] : '0',
                'object_ids' => isset($params['object_ids']) ? $params['object_ids'] : '0',
                'date_created' => date('Y-m-d H:i:s'),
            );
            $ci->M_admin_action->do_save($data);
        }
        return;
    }

}

if (!function_exists('compare_large_string_values')) {

    /**
     * Save admin login action
     */
    function compare_large_string_values($old, $new, $decode = FALSE) {
        $result = TRUE;
        $old = html_entity_decode($old);
        if (!$decode) {
            $new = html_entity_decode($new);
        }
                
        $string1 = preg_replace('/\s+/', '', trim($old));
        $string2 = preg_replace('/\s+/', '', trim($new));
        //ECHO $string1;
       // ECHO $new;
        if (strcmp($string1, $string2) !== 0) {
            $result = FALSE;
        }
        return $result;
    }

}

  if (!function_exists('generate_sitemap')) {
            
                function generate_sitemap($pages) {
                        $xml = new DomDocument('1.0', 'utf-8');
                        $xml->formatOutput = true;

                        // creating base node
                        $urlset = $xml->createElement('urlset');
                        $urlset->appendChild(
                                new DomAttr('xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9')
                        );

                        // appending it to document
                        $xml->appendChild($urlset);

                        // building the xml document with your website content
                        if ($pages->num_rows() > 0) {
                            foreach ($pages->result() as $page) {
                                if($page->status == '1'){
                                    //Creating single url node
                                    $url = $xml->createElement('url');

                                    //paratemers
                                    if($page->url_key == 'home'){
                                        $page_link = base_url();
                                    }else{
                                         $page_link = base_url() . $page->url_key;
                                    }
                                    $page_date = gmdate('Y-m-d/TH:i:s+00:00', strtotime($page->date_upd));

                                    //Filling node with entry info
                                    $url->appendChild($xml->createElement('loc', $page_link));
                                    $url->appendChild($lastmod = $xml->createElement('lastmod', $page_date));
                                    $url->appendChild($changefreq = $xml->createElement('changefreq', 'monthly'));
                                    $url->appendChild($priority = $xml->createElement('priority', '0.5'));

                                    // append url to urlset node
                                    $urlset->appendChild($url);
                                }
                            }
                        }
                        
                        
                        $xml->save(str_replace('system/', '', BASEPATH) . '/sitemap.xml');
                    }

 }

if (!function_exists('upload_blog_image')) {

    /**
     * Save admin login action
     */
    function upload_blog_image($type = null) {
        $ci = & get_instance();
        if ($type != null) {

            
            $config['upload_path'] = str_replace('system/', '', BASEPATH) . 'uploads/blog/';
            $config['overwrite'] = FALSE;
            $config['encrypt_name'] = TRUE; 
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $config['max_size'] = '2048';
         

            $ci->load->library('upload');
            $ci->upload->initialize($config);

            if (!$ci->upload->do_upload($type)) {
                $upload_image = array('error' => $ci->upload->display_errors('<div class="red">', '</div>'));
            } else {
                $upload_image = array('data' => $ci->upload->data());
            }
            return $upload_image;
        }
    }

}

