<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Subscribers extends CI_Controller {

    function __construct() {
        parent::__construct();
        if (!$this->session->userdata('logged_in'))
            redirect('admin/login');
        $this->load->library('form_validation');
        $this->load->library('pagination');
        $this->load->helper('security');
        $this->load->helper('csv');
        $this->load->helper('cs_functions');
        $this->load->model('admin/M_subscribers');
        $this->load->model('admin/M_website');
        $this->load->model('admin/M_transactional_emails');
    }

    function index($offset = 0) {
        //set pagination
        $perpage = 10;
        $this->pagination($perpage);
        //set page data
        $data['subscribers'] = $this->M_subscribers->get_all($perpage, $offset);
        $data['title'] = 'Mailing List';
        $data['content'] = 'admin/subscribers/subscribers';
        $data['sitename'] = $this->M_website->getName();
        //parse temlate
        $this->parser->parse('admin/template', $data);
    }

    function post_to_uri($value = null) {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('search', 'Search', 'trim|xss_clean|urlencode');

        if ($this->form_validation->run()) {
            $query_string = set_value('search');
            redirect(site_url('admin/subscribers/search/' . $query_string));
        } else {
            show_error('Nice try! Your IP has been logged and we are notifying proper authorities');
        }
    }

    function search($value = '', $offset = 0) {
        // Decode uri encoded string.
        $value = urldecode($value);


        //set page data
        $subscribers = $this->M_subscribers->search(array('fname', 'lname', 'email'), $value);

        //set pagination
        $perpage = 10;
        $this->pagination($perpage, $subscribers->num_rows(), site_url('admin/subscribers/search/' . $value . '/'), 5);

        $subscribers = $this->M_subscribers->search(array('fname', 'lname', 'email'), $value, $perpage, $offset)->result();

        $data = array();
        foreach ($subscribers as $subscriber) {
            $data[] = (array) $subscriber;
        }

        $data['subscribers'] = $data;
        $data['title'] = 'Mailing List';
        $data['content'] = 'admin/subscribers/subscribers';
        $data['sitename'] = $this->M_website->getName();
        //parse temlate
        $this->parser->parse('admin/template', $data);
    }

    function add() {
        //set page data
        $data['title'] = 'Add Subscriber';
        $data['content'] = 'admin/subscribers/subscribers_add';
        $data['sitename'] = $this->M_website->getName();
        //parse temlate
        $this->parser->parse('admin/template', $data);
    }

    function save() {
        $this->form_validation->set_rules('email', 'Email Address', 'required|valid_email');

        if ($this->form_validation->run() == FALSE) {
            //set page data
            $data['title'] = 'Add Subscriber';
            $data['content'] = 'admin/subscribers/subscribers_add';
            $data['sitename'] = $this->M_website->getName();
            //parse temlate
            $this->parser->parse('admin/template', $data);
        } else {
            $email = $_POST['email'];
            $subscriberExists = $this->M_subscribers->getByEmail($email);

            if (count($subscriberExists)) {
                if ($subscriberExists['active'] == 1) {

                    $_SESSION['subscriberExists'] = TRUE;
                    redirect('admin/subscribers/add');
                } else {
                    $_POST['subscription_key'] = do_hash($_POST['email']);
                    $this->M_subscribers->do_subscribe($_POST['subscription_key']);
                    //SAVE ADMIN ACTION LOG
                    save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_ADD, 'title' => $_POST['email'], 'object_id' => $subscriberExists['id_subscriber']));

                    $_SESSION['saved'] = TRUE;
                }
            } else {

                $_POST['subscription_key'] = do_hash($_POST['email']);
                if ($this->M_subscribers->insert($_POST)) {
                    //SAVE ADMIN ACTION LOG
                    $id = $this->db->insert_id();
                    save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_ADD, 'title' => $_POST['email'], 'object_id' => $id));

                    $_SESSION['saved'] = TRUE;
                }
            }
            redirect('admin/subscribers');
        }
    }

    function view($id) {
        //set page data
        $data['subscriber'] = $this->M_subscribers->get($id);
        $data['title'] = 'View Subscriber';
        $data['content'] = 'admin/subscribers/subscribers_view';
        $data['sitename'] = $this->M_website->getName();
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function edit($id) {
        //set page data
        $data['subscriber'] = $this->M_subscribers->get($id);
        $data['title'] = 'Edit Subscriber';
        $data['content'] = 'admin/subscribers/subscribers_edit';
        $data['sitename'] = $this->M_website->getName();
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function update() {

        $this->form_validation->set_rules('email', 'Email Address', 'required|valid_email');
        if ($this->form_validation->run() == FALSE) {
            //set page data
            $data['subscriber'] = $this->M_subscribers->get($this->input->post('id_subscriber'));
            $data['title'] = 'Edit Subscriber';
            $data['content'] = 'admin/subscribers/subscribers_edit';
            $data['sitename'] = $this->M_website->getName();
            //parse template
            $this->parser->parse('admin/template', $data);
        } else {
            $_POST['subscription_key'] = do_hash($_POST['email']);
            $email = $_POST['email'];
            $subscriberExists = $this->M_subscribers->getByEmail($email);

            if (count($subscriberExists)) {

                if ($subscriberExists['id_subscriber'] != $_POST['id_subscriber']) {
                    if ($subscriberExists['active'] == 1) {

                        $_SESSION['subscriberExists'] = TRUE;
                        redirect('admin/subscribers/update');
                    } else {
                        $this->M_subscribers->do_subscribe($_POST['subscription_key']);
                        //SAVE ADMIN ACTION LOG
                        save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_EDIT, 'title' => $_POST['email'], 'object_id' => $subscriberExists['id_subscriber']));

                        $_SESSION['saved'] = TRUE;
                    }
                } else {
                    if ($this->M_subscribers->update($_POST)) {
                        //SAVE ADMIN ACTION LOG
                        save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_EDIT, 'title' => $_POST['email'], 'object_id' => $subscriberExists['id_subscriber']));

                        $_SESSION['saved'] = TRUE;
                    }
                }
            } else {
                if ($this->M_subscribers->update($_POST)) {
                    //SAVE ADMIN ACTION LOG
                    save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_EDIT, 'title' => $_POST['email'], 'object_id' => (isset($_POST['id_subscriber'])) ? $_POST['id_subscriber'] : ''));

                    $_SESSION['saved'] = TRUE;
                }
            }

            redirect('admin/subscribers');
        }
    }

    function delete($id) {
        $subscriber = $this->M_subscribers->get($id);
        if(count($subscriber) > 0){
        if ($this->M_subscribers->delete($id)) {
            //SAVE ADMIN ACTION LOG
            save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_DELETE, 'title' => $subscriber['email'], 'object_id' => $id));

            $_SESSION['deleted'] = TRUE;
            redirect('admin/subscribers');
        } else {
            $_SESSION['deleted'] = FALSE;
        }
        }
    }

    function unsubscribe($id) {
$subscriber = $this->M_subscribers->get($id);
        if(count($subscriber) > 0){
        if ($this->M_subscribers->unsubscribe($id)) {
            //SAVE ADMIN ACTION LOG
            save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_UNSUBSCRIBE, 'title' => $subscriber['email'], 'object_id' => $id));

            $_SESSION['saved'] = TRUE;
            redirect('newsletter/unsubscribe');
        } else {
            $_SESSION['saved'] = FALSE;
        }
        }
    }

    function subscribe($id) {
        $subscriber = $this->M_subscribers->get($id);
        if(count($subscriber) > 0){
        if ($this->M_subscribers->subscribe($id)) {
             //SAVE ADMIN ACTION LOG
            save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_SUBSCRIBE, 'title' => $subscriber['email'], 'object_id' => $id));

            $_SESSION['saved'] = TRUE;
            redirect('admin/subscribers');
        } else {
            $_SESSION['saved'] = FALSE;
        }
        }
    }

    function import() {
        //set page data
        $data['title'] = 'Import Subscribers';
        $data['content'] = 'admin/subscribers/subscribers_import';
        $data['sitename'] = $this->M_website->getName();
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function do_import() {
        //CSV IMPORT
        $importError = FALSE;
        $file_name = '';
        if ($_FILES) {
            $csvImport = $this->import_file('csvFile');
            if (isset($csvImport['error'])) {
                $_SESSION['importFailed'] = $csvImport['error'];
                $importError = TRUE;
            } elseif (isset($csvImport['data'])) {
                $file_name = $csvImport['data']['file_name'];
            }
        }

        if (!$importError) {
            //TRANSFER DATA INTO DATABASE
            $import_fail = 0;
            $filePath = str_replace('system/', '', BASEPATH) . 'tmp/' . $file_name;
            if (($handle = fopen($filePath, "r")) !== FALSE) {
                while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                    if (!$this->M_subscribers->import($data)) {
                        $import_fail++;
                        $_SESSION['importFailed'] = $import_fail;
                    } else {
                        $_SESSION['importFailed'] = FALSE;
                    }
                }
                fclose($handle);
            }
            if($import_fail < 1){
                //SAVE ADMIN ACTION LOG
                save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_IMPORT, 'title' => Constant::ALT_IMPORT));
            }
            //REMOVE CSV FILE FROM tmp/ FOLDER
            if (file_exists($filePath))
                unlink($filePath);
            redirect('admin/subscribers');
        }else {
            //set page data
            $data['title'] = 'Import Subscribers';
            $data['content'] = 'admin/subscribers/subscribers_import';
            $data['sitename'] = $this->M_website->getName();
            //parse template
            $this->parser->parse('admin/template', $data);
        }
    }

    function import_file($field_name) {
        $config['upload_path'] = str_replace('system/', '', BASEPATH) . 'tmp/';
        $config['allowed_types'] = 'csv';
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload($field_name)) {
            $upload = array('error' => $this->upload->display_errors('<p class="red">', '</p>'));
            return $upload;
        } else {
            $upload = array('data' => $this->upload->data());
            return $upload;
        }
    }

    function action() {
        $uri_4 = $this->input->post('uri_4');
        $failCtr = 0;
        $successCtr = 0;
        if (!$this->input->post('subscribers')) {
            $_SESSION['noSelected'] = TRUE;
        } else {
            switch ($this->input->post('selectAction')) {
                case 'subscribe':
                    //SUBSCRIBE
                    $_SESSION['action'] = 1;
                    $action = array();
                    $action_array = $this->M_subscribers->find_deleted_items($this->input->post('subscribers'));
                    
                    foreach ($this->input->post('subscribers') as $row) {
                        if (!$this->M_subscribers->subscribe($row)) {
                            $failCtr++;
                            $_SESSION['actionsFailed'] = $failCtr;
                        } else {
                            $action[] = $row;
                            if (!array_key_exists($row, $action_array)) {
                                unset($action_array[$row]);
                            }
                            $successCtr++;
                            $_SESSION['actionsSuccess'] = $successCtr;
                        }
                    }
                     $action_list = '';
                    $action_ids_list = '';
                    if (count($action_array) > 0) {
                        $action_list = implode(",", $action_array);
                        $action_list = rtrim($action_list, ',');
                        $action_ids_list = implode(",", $action);
                        $action_ids_list = rtrim($action_ids_list, ',');
                    }
                    //SAVE ADMIN ACTION LOG
                    save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_SUBSCRIBE_ALL, 'title' => $action_list, 'object_ids' => $action_ids_list));
                    
                    break;
                case 'unsubscribe':
                    //UNSUBSCRIBE
                    $_SESSION['action'] = 2;
                    $action = array();
                    $action_array = $this->M_subscribers->find_deleted_items($this->input->post('subscribers'));
                    
                    foreach ($this->input->post('subscribers') as $row) {
                        if (!$this->M_subscribers->unsubscribe($row)) {
                            $failCtr++;
                            $_SESSION['actionsFailed'] = $failCtr;
                        } else {
                            $action[] = $row;
                            if (!array_key_exists($row, $action_array)) {
                                unset($action_array[$row]);
                            }
                            $successCtr++;
                            $_SESSION['actionsSuccess'] = $successCtr;
                        }
                    }
                    $action_list = '';
                    $action_ids_list = '';
                    if (count($action_array) > 0) {
                        $action_list = implode(",", $action_array);
                        $action_list = rtrim($action_list, ',');
                        $action_ids_list = implode(",", $action);
                        $action_ids_list = rtrim($action_ids_list, ',');
                    }
                    //SAVE ADMIN ACTION LOG
                    save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_UNSUBSCRIBE_ALL, 'title' => $action_list, 'object_ids' => $action_ids_list));
                    
                    break;
                case 'delete':
                    //DELETE
                    $_SESSION['action'] = 3;
                    $action = array();
                    $action_array = $this->M_subscribers->find_deleted_items($this->input->post('subscribers'));
                    foreach ($this->input->post('subscribers') as $row) {
                        if (!$this->M_subscribers->delete($row)) {
                            $failCtr++;
                            $_SESSION['actionsFailed'] = $failCtr;
                        } else {
                            $action[] = $row;
                            if (!array_key_exists($row, $action_array)) {
                                unset($action_array[$row]);
                            }
                            $successCtr++;
                            $_SESSION['actionsSuccess'] = $successCtr;
                        }
                    }
                    $action_list = '';
                    $action_ids_list = '';
                    if (count($action_array) > 0) {
                        $action_list = implode(",", $action_array);
                        $action_list = rtrim($action_list, ',');
                        $action_ids_list = implode(",", $action);
                        $action_ids_list = rtrim($action_ids_list, ',');
                    }
                    //SAVE ADMIN ACTION LOG
                    save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_DELETE_ALL, 'title' => $action_list, 'object_ids' => $action_ids_list));
                    
                    break;
            }
        }
        redirect('admin/subscribers/index/' . $uri_4);
    }

    function batch($offset = 0) {
        $this->load->model('admin/M_newsletter');

        // are there any newsletters queued?
        $newsletter = $this->M_newsletter->getQueuedNewsletterStatus('pending');
        if ($newsletter->num_rows > 0) {
            $newsletterData = $this->M_newsletter->getFirstQueuedMailing('pending');

            //set pagination
            $perpage = 10;
            $this->pagination($perpage, $this->M_subscribers->get_count(), base_url() . index_page() . 'admin/subscribers/batch/index/', 6);

            //set page data
            $data['subscribers'] = $this->M_subscribers->getAllSubscribers($perpage, $offset);

            $data['newsletters_title'] = $newsletterData->title;
        }

        $data['title'] = 'Mailing List';
        $data['content'] = 'admin/subscribers/subscribers_batch';
        $data['sitename'] = $this->M_website->getName();
        //parse temlate
        $this->parser->parse('admin/template', $data);
    }

    function email() {
        //get transactional emails
        $subscription = $this->M_transactional_emails->get('subscription');
        $unsubscription = $this->M_transactional_emails->get('unsubscription');
        //set page data
        $data['sitename'] = $this->M_website->getName();
        $data['title'] = 'Confirmation Email';
        $data['content'] = 'admin/subscribers/subscribers_email';
        if (isset($_SESSION['saved'])) {
            $data['saved'] = $_SESSION['saved'];
            unset($_SESSION['saved']);
        }

        $data['subscription_msg'] = $subscription['message'];
        $data['unsubscription_msg'] = $unsubscription['message'];
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function saveEmail() {
        $this->form_validation->set_rules('subscription_msg', 'Subscrition Message', 'required');
        $this->form_validation->set_rules('unsubscription_msg', 'Unsubscrition Message', 'required');
        if ($this->form_validation->run() == FALSE) {
            //get transactional emails
            $subscription = $this->M_transactional_emails->get('subscription');
            $unsubscription = $this->M_transactional_emails->get('unsubscription');
            //set page data
            $data['sitename'] = $this->M_website->getName();
            $data['title'] = 'Confirmation Email';
            $data['content'] = 'admin/subscribers/subscribers_email';

            $data['subscription_msg'] = $subscription['message'];
            $data['unsubscription_msg'] = $unsubscription['message'];
            //parse template
            $this->parser->parse('admin/template', $data);
        } else {

            if ($this->M_transactional_emails->update('subscription', $this->input->post('subscription_msg')) && $this->M_transactional_emails->update('unsubscription', $this->input->post('unsubscription_msg'))) {
                $_SESSION['saved'] = TRUE;
                redirect('admin/subscribers/email');
            }
        }
    }

    function export() {
        $website = $this->M_website->getName();
         //SAVE ADMIN ACTION LOG
        save_admin_action(array('module' => Constant::AM_MAILING_LIST, 'action' => Constant::AL_EXPORT, 'title' => Constant::ALT_EXPORT));

        $this->db->select('id_subscriber,fname,lname,email');
        $query = $this->db->get('subscribers');
        query_to_csv($query, TRUE, $website . '-Mailing-List.csv');
    }

    function pagination($perpage) {
        /* PAGINATION SETTING */
        $config['base_url'] = base_url() . index_page() . 'admin/subscribers/index/';
        $config['total_rows'] = $this->M_subscribers->get_count();
        $config['per_page'] = $perpage;
        $config['uri_segment'] = 4;
        $config['num_links'] = 4;
        //first and last links
        $config['first_link'] = '&laquo; First';
        $config['last_link'] = 'Last &raquo;';
        //first link tags
        $config['first_tag_open'] = '<li style="margin-right:20px;">';
        $config['first_tag_close'] = '</li>';
        //last link tags
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '<li>';
        //next link tags
        $config['next_link'] = 'Next &raquo;';
        $config['next_tag_open'] = '<li style="margin-right:20px;margin-left:10px;"">';
        $config['next_tag_close'] = '</li>';
        //previous link tags
        $config['prev_link'] = '&laquo; Previous';
        $config['prev_tag_open'] = '<li style="margin-right:10px;">';
        $config['prev_tag_close'] = '</li>';
        //current link tags
        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '</a></li>';
        //links tags
        $config['num_tag_open'] = '<li class="pages">';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
    }

}

/* End of file subscribers.php */
/* Location: ./application/controllers/admin/subscribers.php */