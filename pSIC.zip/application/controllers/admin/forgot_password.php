<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forgot_password extends CI_Controller {

	function __construct(){
		parent::__construct();
		if($this->session->userdata('logged_in')) redirect('admin/dashboard');
		$this->load->library('form_validation');
		$this->load->library('email');
		$this->load->helper('security');
		$this->load->helper('string');
		$this->load->model('admin/M_website');
		$this->load->model('admin/M_administrator');
        $this->load->model('default/m_settings');
	}
	
	function index(){
		//set page data
		$data['title'] = 'Administrator Forgot Password';
		$data['sitename'] = $this->M_website->getName();
		$data['project_mode'] = $this->M_administrator->project_info("MDnetSolutions","project_mode");
		$data['website'] = $this->M_website->getWebsite();
		//parse template
		$this->parser->parse('admin/forgot_password/forgot_password', $data);
	}	
	
	function retrieve(){ 
		//set page data
		$data['title'] = 'Administrator Forgot Password';
		$data['sitename'] = $this->M_website->getName();
		$data['project_mode'] = $this->M_administrator->project_info("MDnetSolutions","project_mode");
		$data['website'] = $this->M_website->getWebsite();
		//process
		$this->form_validation->set_rules('email', 'Email Address', 'required|valid_email');
		if($this->form_validation->run() == FALSE){
			$data['error'] = form_error('email', '<p style="color: #f93d3d; text-align:center; border: 1px solid #f93d3d; padding: 10px 0"><i>','</i><p>');
		}else{
			$email = $this->input->post('email', TRUE);
			$super_admin = $this->M_administrator->getSuperAdmin();
			$admin = $this->M_administrator->getAdminByEmail($email);
			$user = $this->M_administrator->getUserByEmail($email);

			if(count($admin)){
				//set new password
				$new_password = $this->set_new_password();
				$this->M_administrator->saveResetPass($admin['id_admin'], $new_password);

				//set reset key
				$reset_key = do_hash($this->set_reset_key($admin['id_admin']));
				
				//create email message
				$message = "<h4>Dear ".$admin['username'].",</h4>
				<p>You received this email because the Forgot Password Form has been submitted.</p>
				
				<p>
					Your access details are:
					<div style='background: #f9f9f9; border: 1px solid silver; padding: 20px; margin: 0'>
					<strong>Username:</strong> ".$admin['username']." <br />
					<strong>New password:</strong> ".$new_password."
					</div>
				</p>
				<p>
					Please note that this new password won't be activated unless 
					you click this <a href='".base_url().index_page()."admin/login/index/".$admin['id_admin']."/".$reset_key."'>login</a> link
					or you may copy-paste the link below to your browser:<br />
					".base_url().index_page()."admin/login/index/".$admin['id_admin']."/".$reset_key."
				</p>
				<p>
					Thank you.
				</p>
				<p>
					".$data['sitename']."<br />
					".base_url()."
				</p>";
				//send email
					$config['mailtype'] = 'html';
					$this->email->initialize($config);
					$this->email->from('noreply@'.$_SERVER['HTTP_HOST'], $data['sitename']);
					$this->email->to($admin['email']);
					$this->email->subject('['.$data["sitename"].'] New password for '.$admin['username']);
					$this->email->message($message);
					$this->email->send();
				$data['msg'] = 'A new password was sent to your email address. 
Please check your email.';
			}elseif(count($user)){
				//set new password
				$new_password = $this->set_new_password();
				$this->M_administrator->saveResetUserPass($user['user_id'], $new_password);

				//set reset key
				$reset_key = do_hash($this->set_reset_user_key($user['user_id']));
				
				//create email message
                                $closing = $this->m_settings->get('global_email_footer')->setting_value;
                                $email_confirmation = $this->m_settings->get('notif_reset_password_email_confirmation');
                                $email_sender_msg = $email_confirmation->setting_value;
                                $email_sender_msg = str_replace('%%FIRSTNAME%%', $user['firstname'], $email_sender_msg);
                                $email_sender_msg = str_replace('%%LASTNAME%%', $user['lastname'], $email_sender_msg);
                                $email_sender_msg = str_replace('%%USERNAME%%', $user['username'], $email_sender_msg);
                                $email_sender_msg = str_replace('%%CLOSING%%', $closing, $email_sender_msg);

				
				//send email
					$config['mailtype'] = 'html';
					$this->email->initialize($config);
					$this->email->from('noreply@'.$_SERVER['HTTP_HOST'], $data['sitename']);
					$this->email->to($user['email']);
					$this->email->subject('['.$data["sitename"].'] New password for '.$user['username']);
					$this->email->message($email_sender_msg);
					$this->email->send();
				$data['msg'] = 'A new password was sent to your email address. 
Please check your email.';
			}else{
			$email = $this->input->post('email', TRUE);
                        $this->load->model('default/M_user');
                        $this->load->helper('cs_emails');
			$user = $this->M_user->getAdminByEmail($email);
			if(count($user)){             
                        $x = $email_data = array(
                            'firstname' => $user['firstname'],
                            'lastname' => $user['lastname'],
                            'username' => $user['username'],
                        );
                       // Send an email to the user.
	               send_email_template(
	                       'notif_reset_password_email_confirmation',
	                        $user['email'],
	                        null,
	                        $email_data
	                  );
                         $data['msg'] = 'Please check your email to reset your password.';
                           
                        }else{ 
				$data['error'] = '<p style="color: #f93d3d; text-align:center; border: 1px solid #f93d3d; padding: 10px 0"><i>Cannot find the email address.</i></p>';
                      }
				
			}	
		}

		//parse template
		$this->parser->parse('admin/forgot_password/forgot_password', $data);
	}

	function set_reset_key($id){
		$reset_key = random_string('alnum', 7);
		$this->M_administrator->setResetKey($id, do_hash($reset_key));
		return $reset_key;
	}

	function set_reset_user_key($id){
		$reset_key = random_string('alnum', 7);
		$this->M_administrator->setResetUserKey($id, do_hash($reset_key));
		return $reset_key;
	}
	
	function set_new_password(){
		$new_password = random_string('alnum', 7);
		return $new_password;
	}

	function verify($username = null){
	$this->load->model('default/M_user');
        $this->load->helper('cs_emails');
       if($username != null){
            $user = $this->M_user->get_username($username);
              if(count($user)){
                        $x = $email_data = array(
                            'name' => $user['firstname'].' '. $user['lastname']
                        );
                       // Send an email to the user.
	               send_email_template(
	                       'notif_new_account_verification',
	                        $user['email'],
	                        null,
	                        $email_data
	                  );
      if($x){
           redirect(base_url());
      }
}
       }
		//set page data
		$data['title'] = 'Account Verification';
		$data['sitename'] = $this->M_website->getName();
		$data['project_mode'] = $this->M_administrator->project_info("MDnetSolutions","project_mode");
		$data['website'] = $this->M_website->getWebsite();

		//parse template
		//$this->parser->parse('admin/user/verification', $data);
	}

function resetpass($username = null){
	$this->load->model('default/M_user');
        $this->load->helper('cs_emails');
		//set page data
		$data['title'] = 'Account Verification';
		$data['sitename'] = $this->M_website->getName();
		$data['project_mode'] = $this->M_administrator->project_info("MDnetSolutions","project_mode");
		$data['website'] = $this->M_website->getWebsite();
                $data['username'] = $username;

		//parse template
		$this->parser->parse('admin/notifications/reset_pass', $data);
	}

function reset_password($username = null) {
$username = $this->input->post('username');
		$data['title'] = 'Reset Password';
		$data['sitename'] = $this->M_website->getName();
		$data['project_mode'] = $this->M_administrator->project_info("MDnetSolutions","project_mode");
		$data['website'] = $this->M_website->getWebsite();
                $data['username'] = $username;
        $this->load->model('default/M_user');
        $this->load->helper('cs_emails');

        $this->form_validation->set_rules('new_password', 'New password', 'required|min_length[7]|xss_clean|matches[confirm_password]');
        $this->form_validation->set_rules('confirm_password', 'Confirm password', 'required|min_length[7]|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            //set page data
            $data['title'] = 'Reset Password';
            $user = $this->M_user->get_username($username);			
            $data['sitename'] = $this->M_website->getName();

            //parse template
            $this->parser->parse('admin/notifications/reset_pass', $data);
        } else {
          $user = $this->M_user->get_username($username);			
              if(count($user)){	  
		  if ($this->M_user->changePassword($user['user_id'], base64_encode($_POST['new_password']))) {
                        $x = $email_data = array(
                            'name' => $user['firstname'].' '. $user['lastname'],
                            'username' => $user['username'],
                            'password' => base64_decode($user['password'])
                        );
                       // Send an email to the user.
	               send_email_template(
	                       'notif_password_update_verification',
	                        $user['email'],
	                        null,
	                        $email_data
	                  );
				if($x){
					redirect('admin/login');
				}
	          }
		}else{			
                //redirect page
                redirect(base_url());
            }
        }
    }
	
}
/* End of file forgot_password.php */
/* Location: ./application/controllers/admin/forgot_password.php */