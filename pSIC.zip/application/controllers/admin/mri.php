<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Mri extends CI_Controller {

    function __construct() {
        parent::__construct();
        if (!$this->session->userdata('logged_in'))
            redirect('admin/login');
        $this->load->library('pagination');
        $this->load->library('form_validation');
        $this->load->helper('text');
        $this->load->helper('csv');
        $this->load->helper('cs_functions');
        $this->load->model('admin/M_administrator');
        $this->load->model('admin/M_website');
        $this->load->model('admin/M_mri');
        $this->load->model('admin/M_transactional_emails');
    }

    function index($offset = 0) {
        //set pagination
        $perpage = 10;
        $this->pagination($perpage);
        //set page data
        $data['mri_logs'] = $this->M_mri->get_all($perpage, $offset, 'capture_date', TRUE);
        $data['title'] = 'Contact Us';
        $data['content'] = 'admin/mri/mri';
        $data['sitename'] = $this->M_website->getName();
        //actions settled
        if (isset($_SESSION['deleted'])) {
            $data['deleted'] = $_SESSION['deleted'];
            unset($_SESSION['deleted']);
        } elseif (isset($_SESSION['noSelected'])) {
            $data['noSelected'] = $_SESSION['noSelected'];
            unset($_SESSION['noSelected']);
        }
        if (isset($_SESSION['action'])) {
            $data['action'] = $_SESSION['action'];
            unset($_SESSION['action']);
            if (isset($_SESSION['actionsSuccess'])) {
                $data['actionsSuccess'] = $_SESSION['actionsSuccess'];
                unset($_SESSION['actionsSuccess']);
            }
            if (isset($_SESSION['actionsFailed'])) {
                $data['actionsFailed'] = $_SESSION['actionsFailed'];
                unset($_SESSION['actionsFailed']);
            }
        }
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function settings() {
        $this->load->model('default/m_settings');
        //get transactional email
        $email_recipient = $this->m_settings->get('mri_email_recipient');
        $email_confirmation = $this->m_settings->get('mri_email_confirmation');
        $email_confirmation_subj = $this->m_settings->get('mri_email_confirmation_subject');
        $email_admin_notification = $this->m_settings->get('mri_admin_notificaion');
        $email_admin_notification_subj = $this->m_settings->get('mri_admin_notificaion_subject');
        //$email_contacted_confirm = $this->m_settings->get('mri_patient_contacted');
        //$email_contacted_confirm_subj = $this->m_settings->get('mri_contacted_patient_subject');
        //set page data
        $data['title'] = 'Contact Us Settings';
        $data['content'] = 'admin/mri/mri_settings';
        $data['sitename'] = $this->M_website->getName();
        $data['mri_email_recipient'] = $email_recipient->setting_value;
        $data['mri_email_confirmation'] = $email_confirmation->setting_value;
        $data['mri_email_confirmation_subject'] = $email_confirmation_subj->setting_value;
        $data['mri_admin_notificaion'] = $email_admin_notification->setting_value;
        $data['mri_admin_notificaion_subject'] = $email_admin_notification_subj->setting_value;
        //$data['mri_contacted_confirmation'] = $email_contacted_confirm->setting_value;
        //$data['mri_contacted_confirmation_subject'] = $email_contacted_confirm_subj->setting_value;
        if (isset($_SESSION['saved'])) {
            $data['saved'] = $_SESSION['saved'];
            unset($_SESSION['saved']);
        }
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function settings_save() {
        $this->load->model('default/m_settings');

        //set page data
        $data['title'] = 'Contact Us Settings';
        $data['content'] = 'admin/mri/mri_settings';
        $data['sitename'] = $this->M_website->getName();

        //get transactional email
        $email_recipient = $this->m_settings->get('mri_email_recipient')->setting_value;
        $email_confirmation = $this->m_settings->get('mri_email_confirmation')->setting_value;
        $email_confirmation_subj = $this->m_settings->get('mri_email_confirmation_subject')->setting_value;
        $email_admin_notification = $this->m_settings->get('mri_admin_notificaion')->setting_value;
        $email_admin_notification_subj = $this->m_settings->get('mri_admin_notificaion_subject')->setting_value;

        $data['mri_email_recipient'] = $this->input->post('mri_email_recipient');
        $data['mri_email_confirmation'] = $this->input->post('mri_email_confirmation');
        $data['mri_email_confirmation_subject'] = $this->input->post('mri_email_confirmation_subject');
        $data['mri_admin_notificaion'] = $this->input->post('mri_admin_notificaion');
        $data['mri_admin_notificaion_subject'] = $this->input->post('mri_admin_notificaion_subject');

        //validate form
        $this->form_validation->set_rules('mri_email_recipient', 'Email Recipient', 'required|valid_emails');
        $this->form_validation->set_rules('mri_email_confirmation', 'Contact Us message [Confirmation]', 'required');
        $this->form_validation->set_rules('mri_email_confirmation_subject', 'Subject', 'required');
        $this->form_validation->set_rules('mri_admin_notificaion', 'Contact Us message [Admin Noification]', 'required');
        $this->form_validation->set_rules('mri_admin_notificaion_subject', 'Subject', 'required');
        if ($this->form_validation->run()) {
            $_SESSION['saved'] = TRUE;
            if ($this->m_settings->save_settings($data)) {
                //SAVE ADMIN ACTION LOG
                if ($email_recipient != $this->input->post('mri_email_recipient')) {
                    save_admin_action(array('module' => Constant::AM_MRI, 'action' => Constant::AL_EDIT_EMAIL_SETTINGS, 'title' => Constant::ALT_EMAIL_SETTINGS_RECIPIENT));
                }

                if (compare_large_string_values($email_confirmation, $this->input->post('mri_email_confirmation')) === FALSE ||
                        compare_large_string_values($email_admin_notification, $this->input->post('mri_admin_notificaion')) === FALSE) {

                    save_admin_action(array('module' => Constant::AM_MRI, 'action' => Constant::AL_EDIT_EMAIL_SETTINGS, 'title' => Constant::ALT_EMAIL_SETTINGS_RTE));
                } else {
                    if ($email_confirmation_subj != $this->input->post('mri_email_confirmation_subject')) {

                        save_admin_action(array('module' => Constant::AM_MRI, 'action' => Constant::AL_EDIT_EMAIL_SETTINGS, 'title' => Constant::ALT_EMAIL_SETTINGS_RTE));
                    }
                    if ($email_admin_notification_subj != $this->input->post('mri_admin_notificaion_subject')) {

                        save_admin_action(array('module' => Constant::AM_MRI, 'action' => Constant::AL_EDIT_EMAIL_SETTINGS, 'title' => Constant::ALT_EMAIL_SETTINGS_RTE));
                    }
                }

                $this->session->set_flashdata('message', 'Settings Saved.');
                redirect('admin/mri/settings');
            }
        }
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function view($id) {
        //set page data
        $data['title'] = 'View Contact Us Sender';
        $data['content'] = 'admin/mri/mri_view';
        $data['sitename'] = $this->M_website->getName();
        $data_contact = $this->M_mri->get($id);
        $data['contact'] = $data_contact;

        //SAVE ADMIN ACTION LOG
        save_admin_action(array('module' => Constant::AM_MRI, 'action' => Constant::AL_VIEW, 'title' => $data_contact['fname'] . ' ' . $data_contact['lname'], 'object_id' => $id));

        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function delete($id) {
        $data_contact = $this->M_mri->get($id);
        if (count($data_contact) > 0) {
            if ($this->M_mri->delete($id)) {
                //SAVE ADMIN ACTION LOG
                save_admin_action(array('module' => Constant::AM_MRI, 'action' => Constant::AL_DELETE, 'title' => $data_contact['fname'] . ' ' . $data_contact['lname'], 'object_id' => $id));

                $_SESSION['deleted'] = TRUE;
                redirect('admin/mri');
            }
        }
    }

    function action() {
        $uri_4 = $this->input->post('uri_4');
        $failCtr = 0;
        $successCtr = 0;
        if (!$this->input->post('contacts')) {
            $_SESSION['noSelected'] = TRUE;
        } else {
            switch ($this->input->post('selectAction')) {
                case 'delete':
                    //DELETE
                    $_SESSION['action'] = 1;
                    $deleted = array();
                    $deleted_array = $this->M_mri->find_deleted_items($this->input->post('contacts'));
                    foreach ($this->input->post('contacts') as $row) {
                        if (!$this->M_mri->delete($row)) {
                            $failCtr++;
                            $_SESSION['actionsFailed'] = $failCtr;
                        } else {
                            $deleted[] = $row;
                            if (!array_key_exists($row, $deleted_array)) {
                                unset($deleted_array[$row]);
                            }
                            $successCtr++;
                            $_SESSION['actionsSuccess'] = $successCtr;
                        }
                    }
                    $deleted_list = '';
                    $deleted_ids_list = '';
                    if (count($deleted_array) > 0) {
                        $deleted_list = implode(",", $deleted_array);
                        $deleted_list = rtrim($deleted_list, ',');
                        $deleted_ids_list = implode(",", $deleted);
                        $deleted_ids_list = rtrim($deleted_ids_list, ',');
                    }
                    //SAVE ADMIN ACTION LOG
                    save_admin_action(array('module' => Constant::AM_MRI, 'action' => Constant::AL_DELETE_ALL, 'title' => $deleted_list, 'object_ids' => $deleted_ids_list));
                    
                    break;
            }
        }
        redirect('admin/mri/index/' . $uri_4);
    }

    function export() {
        $website = $this->M_website->getName();
        //SAVE ADMIN ACTION LOG
        save_admin_action(array('module' => Constant::AM_MRI, 'action' => Constant::AL_EXPORT, 'title' => Constant::ALT_EXPORT));
        $this->db->where("ci_mri.id_mri NOT IN (SELECT a.id_mri as id_mri FROM ci_mri a where a.source IN ('Contact Us', 'Blog Contact Us'))");
       
        $query = $this->db->get('mri');
        query_to_csv($query, TRUE, $website . '-Contacts.csv');
    }

    function export_contacted() {
        $website = $this->M_website->getName();
        //SAVE ADMIN ACTION LOG
        save_admin_action(array('module' => Constant::AM_MRI, 'action' => Constant::AL_EXPORT. ' Contacted', 'title' => Constant::ALT_EXPORT));
       
        $query = $this->db->where('contacted', 1);
        $query = $this->db->get('mri');
        query_to_csv($query, TRUE, $website . '-Contacts.csv');
    }

    function pagination($perpage) {
        /* PAGINATION SETTING */
        $config['base_url'] = base_url() . index_page() . 'admin/mri/index/';
        $config['total_rows'] = count($this->M_mri->get_all(NULL, NULL, 'capture_date', TRUE));
        $config['per_page'] = $perpage;
        $config['uri_segment'] = 4;
        $config['num_links'] = 4;
        //first and last links
        $config['first_link'] = '&laquo; First';
        $config['last_link'] = 'Last &raquo;';
        //first link tags
        $config['first_tag_open'] = '<li style="margin-right:20px;">';
        $config['first_tag_close'] = '</li>';
        //last link tags
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '<li>';
        //next link tags
        $config['next_link'] = 'Next &raquo;';
        $config['next_tag_open'] = '<li style="margin-right:20px;margin-left:10px;"">';
        $config['next_tag_close'] = '</li>';
        //previous link tags
        $config['prev_link'] = '&laquo; Previous';
        $config['prev_tag_open'] = '<li style="margin-right:10px;">';
        $config['prev_tag_close'] = '</li>';
        //current link tags
        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '</a></li>';
        //links tags
        $config['num_tag_open'] = '<li class="pages">';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
    }

    function contact($id = null) {
        if (!is_array($id)) {
            $id = $id;
        }

        $this->M_mri->contacted($id);
        // Send email to person/s.
        //$this->load->helper('cs_emails');

        $contacted = $this->M_mri->get($id);
        
        //SAVE ADMIN ACTION LOG
        save_admin_action(array('module' => Constant::AM_MRI, 'action' => Constant::AL_CONTACTED, 'title' => $contacted['fname'] . ' '.  $contacted['lname'], 'object_id' => $id));


        /* if (!send_email_template('mri_patient_contacted', $contacted['email'] , null, $contacted))
          {
          show_error('mailer error:' . $this->email->print_debugger());
          }

          $this->session->set_flashdata('message', 'Patient/s contacted.');
         */

        //set page data
        $data['title'] = 'View Contacted Logs';
        $data['content'] = 'admin/mri/mri_contacted';
        $data['sitename'] = $this->M_website->getName();
        $data['contact'] = $contacted;
        //parse template

        redirect('admin/mri/contacted');
    }

    function contacted($offset = 0) {
        //set pagination
        $perpage = 10;
        $this->paginate($perpage);

        //set page data
        $data['contacted'] = $this->M_mri->get_all_contacted($perpage, $offset);


        $data['title'] = 'Contacted';
        $data['content'] = 'admin/mri/mri_contacted';
        $data['sitename'] = $this->M_website->getName();

        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function paginate($perpage) {
        /* PAGINATION SETTING */
        $config['base_url'] = base_url() . index_page() . 'admin/mri/contacted/index/';
        $config['total_rows'] = $this->M_mri->get_count();
        $config['per_page'] = $perpage;
        $config['uri_segment'] = 5;
        $config['num_links'] = 4;
        //first and last links
        $config['first_link'] = '&laquo; First';
        $config['last_link'] = 'Last &raquo;';
        //first link tags
        $config['first_tag_open'] = '<li style="margin-right:20px;">';
        $config['first_tag_close'] = '</li>';
        //last link tags
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '<li>';
        //next link tags
        $config['next_link'] = 'Next &raquo;';
        $config['next_tag_open'] = '<li style="margin-right:20px;margin-left:10px;"">';
        $config['next_tag_close'] = '</li>';
        //previous link tags
        $config['prev_link'] = '&laquo; Previous';
        $config['prev_tag_open'] = '<li style="margin-right:10px;">';
        $config['prev_tag_close'] = '</li>';
        //current link tags
        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '</a></li>';
        //links tags
        $config['num_tag_open'] = '<li class="pages">';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
    }

}

/* End of file mri.php */
/* Location: ./application/controllers/admin/mri.php */