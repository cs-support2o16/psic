<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Defaults extends MY_Controller {

    function __construct() {
        parent::__construct();
        if (!$this->session->userdata('logged_in'))
            redirect('admin/login');
        $this->load->library('pagination');
        $this->load->library('form_validation');
        $this->load->helper('text');
        $this->load->helper('csv');
        $this->load->helper('download');
        $this->load->helper('cs_dropdown');
        $this->load->helper('cs_functions');
        $this->load->model('admin/M_administrator');
        $this->load->model('admin/M_website');
        $this->load->model('admin/M_mri');
        $this->load->model('default/M_crm_status');
        $this->load->model('default/M_crm_status_history');
        $this->load->model('admin/M_transactional_emails');
    }

    function index($offset = 0) {

        if ($this->input->post('axn') == 'multi_delete') {

            $this->multi_delete($this->input->post('status'));
        } else {
            //search fields
            $perpage = 10;
            $this->pagination($perpage);
            //set page data
            $data['lead_status'] = $this->M_crm_status->fetch_all($perpage, $offset)->result();

            $data['title'] = 'Defaults';
            $data['content'] = 'admin/defaults/list';
            $data['sitename'] = $this->M_website->getName();
            $data['lead_axn'] = $this->input->post('axn');

            //parse template
            $this->parser->parse('admin/crm_template', $data);
        }
    }

    function add_status() {
        //set page data
        $data['title'] = 'CRM';
        $data['content'] = 'admin/defaults/add_status';
        $data['sitename'] = $this->M_website->getName();

        $this->_prep_form_values('add_status_form');
        if ($this->input->post('submit')) {

            $this->load->config('validations');
            $config = $this->config->item('add_status_form');

            $this->require_validation($config);

            if ($this->form_validation->run()) {
                $this->_form_data['created_by'] = $this->session->userdata('id_admin');
                if ($this->M_crm_status->do_save($this->_form_data)) {

                    //SAVE ADMIN ACTION LOG
                    $status_id = $this->db->insert_id();
                    save_admin_action(array('module' => Constant::AM_DEFAULT, 'action' => Constant::AL_ADD, 'title' => $_POST['code'], 'object_id' => $status_id));

                    $this->session->set_flashdata('message', 'Status successfully added.');
                    redirect('admin/defaults');
                }
            }
        }

        //parse template
        $this->parser->parse('admin/crm_template', $data);
    }

    function edit_status($id = null) {

        if ($id != null) {
            $status_data = $this->M_crm_status->get($id);
            if (count($status_data) > 0) {

                //set page data
                $data['title'] = 'CRM';
                $data['content'] = 'admin/defaults/edit_status';
                $data['sitename'] = $this->M_website->getName();
                $data['status_data'] = $status_data;

                $this->_prep_form_values('add_status_form');
                if ($this->input->post('submit')) {

                    $this->load->config('validations');
                    $config = $this->config->item('add_status_form');
                    $this->require_validation($config);

                    if ($this->form_validation->run()) {
                        $this->_form_data['status_id'] = $this->input->post('status_id');
                        $this->_form_data['updated_by'] = $this->session->userdata('id_admin');
                        if ($this->M_crm_status->do_save($this->_form_data)) {

                            //SAVE ADMIN ACTION LOG
                            save_admin_action(array('module' => Constant::AM_DEFAULT, 'action' => Constant::AL_EDIT, 'title' => $_POST['code'], 'object_id' => $id));


                            $this->session->set_flashdata('message', 'Status successfully updated.');
                            redirect('admin/defaults');
                        }
                    }
                }

                //parse template
                $this->parser->parse('admin/crm_template', $data);
            } else {
                show_error('Invalid or no ID specified');
            }
        } else {
            show_error('Invalid or no ID specified');
        }
    }

    function delete($id) {
        $status_data = $this->M_crm_status->get($id);
        if (count($status_data) > 0) {
            if ($this->M_crm_status->delete($status_data['status_id'])) {
                //SAVE ADMIN ACTION LOG
                save_admin_action(array('module' => Constant::AM_DEFAULT, 'action' => Constant::AL_DELETE, 'title' => $status_data['code'], 'object_id' => $id));

                $this->session->set_flashdata('message', 'Status successfully deleted.');
                redirect('admin/defaults');
            }
        }
    }

    function multi_delete($ids) {

        if (is_array($ids)) {
            $failCtr = 0;
            $successCtr = 0;
            $deleted_pages = array();
            $deleted_pages_array = $this->M_crm_status->find_deleted_items($ids);
            foreach ($ids as $row) {
                if (!$this->M_crm_status->delete($row)) {
                    $failCtr++;
                } else {
                    $deleted_pages[] = $row;
                    if (!array_key_exists($row, $deleted_pages_array)) {
                        unset($deleted_pages_array[$row]);
                    }
                    $successCtr++;
                }
            }
            if ($failCtr > 0) {
                $this->session->set_flashdata('error_message', $failCtr . ' lead(s) failed to delete.');
            }
            if ($successCtr > 0) {
                $this->session->set_flashdata('message', $successCtr . ' lead(s) successfully deleted.');
                $deleted_pages_list = '';
                $deleted_ids_list = '';
                if (count($deleted_pages_array) > 0) {
                    $deleted_pages_list = implode(",", $deleted_pages_array);
                    $deleted_pages_list = rtrim($deleted_pages_list, ',');
                    $deleted_ids_list = implode(",", $deleted_pages);
                    $deleted_ids_list = rtrim($deleted_ids_list, ',');
                }
                //SAVE ADMIN ACTION LOG
                save_admin_action(array('module' => Constant::AM_DEFAULT, 'action' => Constant::AL_DELETE_ALL, 'title' => $deleted_pages_list, 'object_ids' => $deleted_ids_list));
            }

            redirect('admin/defaults');
        } else {
            $this->session->set_flashdata('error_message', 'Please select lead(s).');
            redirect('admin/defaults');
        }
    }

    function pagination($perpage, $count = null, $base_url = null, $uri_segment = 4) {

        if ($count == null) {
            $count = $this->M_mri->get_count();
        }
        if ($base_url == null) {
            $base_url = base_url() . index_page() . 'admin/defaults/index/';
        }

        /* PAGINATION SETTING */
        $config['base_url'] = $base_url;
        $config['total_rows'] = $count;
        $config['per_page'] = $perpage;
        $config['uri_segment'] = $uri_segment;
        $config['num_links'] = 4;
        //first and last links
        $config['first_link'] = '&laquo; First';
        $config['last_link'] = 'Last &raquo;';
        //first link tags
        $config['first_tag_open'] = '<li style="margin-right:20px;">';
        $config['first_tag_close'] = '</li>';
        //last link tags
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '<li>';
        //next link tags
        $config['next_link'] = 'Next &raquo;';
        $config['next_tag_open'] = '<li style="margin-right:20px;margin-left:10px;"">';
        $config['next_tag_close'] = '</li>';
        //previous link tags
        $config['prev_link'] = '&laquo; Previous';
        $config['prev_tag_open'] = '<li style="margin-right:10px;">';
        $config['prev_tag_close'] = '</li>';
        //current link tags
        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '</a></li>';
        //links tags
        $config['num_tag_open'] = '<li class="pages">';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
    }

}

/* End of file mri.php */
    /* Location: ./application/controllers/admin/defaults.php */    