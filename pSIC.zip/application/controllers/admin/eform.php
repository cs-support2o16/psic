<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Eform extends CI_Controller {

	function __construct(){
		parent::__construct();
		if(!$this->session->userdata('logged_in')) redirect('admin/login');
		$this->load->library('form_validation');
		$this->load->library('pagination');
		$this->load->helper('download');
		$this->load->helper('cs_dropdown');
		$this->load->model('admin/M_website');
		$this->load->model('admin/M_page');
		$this->load->model('default/M_eform');
		$this->load->model('default/M_eform_user_response');
	}
	
	function index($offset = 0){ 
		//set pagination
		$pagination_config = array(
			'perpage' => 10,
			'base_url' => base_url().index_page().'admin/eform/index/',
			'count' => $this->M_eform_user_response->get_count()
		);
		$this->pagination($pagination_config);
		//set page data
		$data['form'] = $this->M_eform_user_response->get_all($pagination_config['perpage'], $offset);
		$data['title'] = 'Form';
		$data['content'] = 'admin/eform/list';
		$data['sitename'] = $this->M_website->getName();
		
		//set form type
		$data['form_type'] = '';
		
		//set filter value
		$data['filter_action'] = '0';
		
		//for actions messages
		$data['action'] = $this->session->flashdata('action');
		$data['saved'] = $this->session->flashdata('saved');
		$data['deleted'] = $this->session->flashdata('deleted');
		$data['no_selected'] = $this->session->flashdata('noSelected');
		$data['actions_failed'] = $this->session->flashdata('actionsFailed'); 
		$data['actions_success'] = $this->session->flashdata('actionsSuccess');
		
		//parse template
		$this->parser->parse('admin/template', $data);
	}
	
	function show($perpage = 0){ 
	
		$offset = 0;
		if($perpage == 0){
			$perpage = 10;
		}
		//set pagination
		$pagination_config = array(
			'perpage' => $perpage,
			'base_url' => base_url().index_page().'admin/eform/index/',
			'count' => $this->M_eform_user_response->get_count()
		);
		$this->pagination($pagination_config);
		//set page data
		$data['form'] = $this->M_eform_user_response->get_all($pagination_config['perpage'], $offset);
		$data['title'] = 'Form';
		$data['content'] = 'admin/eform/list';
		$data['sitename'] = $this->M_website->getName();
		
		//set form type
		$data['form_type'] = '';
		
		//set filter value
		$data['filter_action'] = $perpage;
		
		//for actions messages
		$data['action'] = $this->session->flashdata('action');
		$data['saved'] = $this->session->flashdata('saved');
		$data['deleted'] = $this->session->flashdata('deleted');
		$data['no_selected'] = $this->session->flashdata('noSelected');
		$data['actions_failed'] = $this->session->flashdata('actionsFailed'); 
		$data['actions_success'] = $this->session->flashdata('actionsSuccess');
		
		//parse template
		$this->parser->parse('admin/template', $data);
	}
	
	function post_to_uri($value = null)
	    {
	        $this->load->library('form_validation');
	
	        $this->form_validation->set_rules('search', 'Search', 'trim|xss_clean|urlencode');
	
	        if ($this->form_validation->run())
	        {
	            $query_string = set_value('search');
	            redirect (site_url('admin/eform/search/' . $query_string));
	        }
	        else
	        {
	            show_error('Nice try! Your IP has been logged and we are notifying proper authorities');
	        }
	    }
	    
	function search($value = '', $offset = 0)
	    {
	        // Decode uri encoded string.
	        $value = urldecode($value);
	
			//set page data
			$forms = $this->M_eform_user_response->findByTpe($value);
			//set pagination
			$perpage = 10;
			$this->pagination($perpage, count($forms), site_url('admin/eform/search/' . $value . '/'), 5);
	
	        $forms = $this->M_eform_user_response->searchByType($value, $perpage, $offset);
	
	        $data = array();
	        foreach ($forms as $form)
	        {
	            $data[] = (array) $form;
	        }
	
	        $data['form'] = $data;
		$data['title'] = 'Form';
		$data['content'] = 'admin/eform/list';
		$data['sitename'] = $this->M_website->getName();
		
		//set form type
		$data['form_type'] = $value;
		
		//set filter value
		$data['filter_action'] = '0';
		
		//for actions messages
		$data['action'] = $this->session->flashdata('action');
		$data['saved'] = $this->session->flashdata('saved');
		$data['deleted'] = $this->session->flashdata('deleted');
		$data['no_selected'] = $this->session->flashdata('noSelected');
		$data['actions_failed'] = $this->session->flashdata('actionsFailed'); 
		$data['actions_success'] = $this->session->flashdata('actionsSuccess');
		//parse temlate
		$this->parser->parse('admin/template', $data);
	    }
	
	function types($offset = 0){ 
		//set pagination
		$pagination_config = array(
			'perpage' => 10,
			'base_url' => base_url().index_page().'admin/eform/index/',
			'count' => $this->M_eform->get_count()
		);
		$this->pagination($pagination_config);
		//set page data
		$data['form'] = $this->M_eform->get_all($pagination_config['perpage'], $offset);
		$data['title'] = 'Form';
		$data['content'] = 'admin/eform/list_types';
		$data['sitename'] = $this->M_website->getName();
		
		//for actions messages
		$data['action'] = $this->session->flashdata('action');
		$data['saved'] = $this->session->flashdata('saved');
		$data['deleted'] = $this->session->flashdata('deleted');
		$data['no_selected'] = $this->session->flashdata('noSelected');
		$data['actions_failed'] = $this->session->flashdata('actionsFailed'); 
		$data['actions_success'] = $this->session->flashdata('actionsSuccess');
		
		//parse template
		$this->parser->parse('admin/template', $data);
	}
	
	function add(){
		//set page data
		$data['title'] = 'Add Form';
		$data['content'] = 'admin/eform/add';
		$data['sitename'] = $this->M_website->getName();
		$data['pages'] = $this->M_page->get_all();
		//parse template
		$this->parser->parse('admin/template', $data);
	}
	
	function edit($id){
		//set page data
		$data['form'] = $this->M_eform->get($id);
		$data['title'] = 'Edit Form';
		$data['content'] = 'admin/eform/edit';
		$data['sitename'] = $this->M_website->getName();
		$data['pages'] = $this->M_page->get_all();
		//parse template
		$this->parser->parse('admin/template', $data);
	}
	
	function update($id){
		$this->form_validation->set_rules('title', 'Title', 'required');
		
		if ($this->form_validation->run() == FALSE){
			//set page data
			$page = array(
				'form' => $this->M_eform->get($id), 
				'content' => 'admin/eform/edit', 
				'title' => 'Edit Form'
			);
			//parse template
			$this->parser->parse('admin/template', $this->set_page_data($page));
		}else{
			
			if($this->M_eform->update($_POST)){
				$this->session->set_flashdata('saved', TRUE);
				redirect('admin/eform/types');
			}
			
		}
	}
	
	function save(){ 
		$this->form_validation->set_rules('title', 'Title', 'required');
		
		if ($this->form_validation->run() == FALSE){
			//set page data
			$page = array('content' => 'admin/eform/add', 'title' => 'Add Form');
			//parse template
			$this->parser->parse('admin/template', $this->set_page_data($page));
		}else{
			
			if($this->M_eform->insert($_POST)){
				$this->session->set_flashdata('saved', TRUE);
				redirect('admin/eform/types');
			}	
		}
	}
	
	function set_page_data($page = NULL){
		$data['title'] = $page['title'];
		$data['content'] = $page['content'];
		$data['sitename'] = $this->M_website->getName();
		$data['pages'] = $this->M_page->get_all();
		$data['file_error'] = (isset($page['file_error']))?$page['file_error']:'';
		$data['form'] = (isset($page['form']))?$page['form']:'';
		return $data;
	}
	
	function upload_file(){
		$config['upload_path'] = str_replace('system/','',BASEPATH).'uploads/form/';
		$config['allowed_types'] = 'gif|jpg|png|pdf|doc|docx|xls|xlsx|ppt|pptx|txt|zip|rar';
		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload('form_file')){
			$file = array('error' => $this->upload->display_errors('<div class="red">','</div>'));
		}
		else{
			$file = array('data' => $this->upload->data());
		}
		return $file;
	}
	
	function action(){
		$uri_4 = $this->input->post('uri_4');
		$failCtr = 0;
		$successCtr = 0;
		if(!$this->input->post('form')){
			$this->session->set_flashdata('noSelected', TRUE);
			if($this->input->post('selectAction') == 'delete_type'){
				$redirect_url = 'admin/eform/types/';
			}else{
				$redirect_url = 'admin/eform/';
			}
		}else{
			switch($this->input->post('selectAction')){
				case 'delete':
					//DELETE
					$redirect_url = 'admin/eform/index/';
					$this->session->set_flashdata('action', 'deleted'); 
					foreach($this->input->post('form') as $id_eform){ 
						//delete files from uploads directory
						$form = $this->M_eform_user_response->get($id_eform);
						if(count($form))$this->delete_file($form['file_name']);
						
						//delete form 
						if(!$this->M_eform_user_response->delete($id_eform)){ 
							$failCtr++;
							$this->session->set_flashdata('actionsFailed', $failCtr);
						}else{
							$successCtr++;
							$this->session->set_flashdata('actionsSuccess', $successCtr);
						}	
					}
					break;
				case 'delete_type':
					//DELETE
					$redirect_url = 'admin/eform/types/index/';
					$this->session->set_flashdata('action', 'delete_type');
					foreach($this->input->post('form') as $id_eform){ 
						
						//delete form 
						if(!$this->M_eform->delete($id_eform)){ 
							$failCtr++;
							$this->session->set_flashdata('actionsFailed', $failCtr);
						}else{
							$successCtr++;
							$this->session->set_flashdata('actionsSuccess', $successCtr);
						}	
					}
					break;	
					
			}
		}
		redirect($redirect_url.$uri_4);
	}
	
	function delete($id){
						
		//delete files from uploads directory
		$form = $this->M_eform_user_response->get($id);
		if(count($form))$this->delete_file($form['file_name']);
		
		//delete form
		if($this->M_eform_user_response->delete($id)){
			$this->session->set_flashdata('deleted', TRUE);	
			redirect('admin/eform/');
		}
	}
	
	function delete_type($id){
						
		//delete form
		if($this->M_eform->delete($id)){
			$this->session->set_flashdata('deleted', TRUE);	
			redirect('admin/eform/types/');
		}
	}
	
	function delete_file($file){
		$filePath = str_replace('system/','',BASEPATH).'uploads/form/'.$file;
		if(file_exists($filePath)){
			if(is_file($filePath))unlink($filePath);
			return TRUE;
		}
		return FALSE;
	}
	
	function download_file($id){ 
		$form = $this->M_eform_user_response->get($id); 
		if(count($form)){
			$filePath = str_replace('system/','',BASEPATH).'uploads/eform/'.$form['id_eform'].'_'.$form['user_id'].'_'.$form['file_name'];
			$name = $form['file_name'];
			force_download($name, file_get_contents($filePath));
			return TRUE;
		}
		return FALSE;
	}
	
	function view_file($id){ 
		$form = $this->M_eform_user_response->get($id); 
		if(count($form)){
			$filePath = base_url().'uploads/eform/'.$form['id_eform'].'_'.$form['user_id'].'_'.$form['file_name'];
			
			//set page data
			$data['title'] = 'Form';
			$data['sitename'] = $this->M_website->getName();
			
			//set form type
			$data['file_path'] = $filePath;
			
			//parse template
			$this->parser->parse('admin/eform/view', $data);
		}
	}
	
	function settings(){
		$this->load->model('default/m_settings');
		//get transactional email
		$email_recipient= $this->m_settings->get('eform_email_recipient');
		$email_admin_notification = $this->m_settings->get('eform_admin_notification');
		$email_admin_notification_subj = $this->m_settings->get('eform_admin_notification_subject');
		
		//set page data
		$data['title'] = 'Form Settings';
		$data['content'] = 'admin/eform/settings';
		$data['sitename'] = $this->M_website->getName();
		$data['eform_email_recipient'] =  $email_recipient->setting_value;
		$data['eform_admin_notification'] = $email_admin_notification->setting_value;
		$data['eform_admin_notification_subject'] = $email_admin_notification_subj->setting_value;
		if(isset($_SESSION['saved'])){
			$data['saved'] = $_SESSION['saved']; unset($_SESSION['saved']);
		}
		//parse template
		$this->parser->parse('admin/template', $data);
	}
	
	function settings_save(){
		$this->load->model('default/m_settings');
		
		//set page data
		$data['title'] = 'Form Settings';
		$data['content'] = 'admin/eform/settings';
		$data['sitename'] = $this->M_website->getName();
		$data['eform_email_recipient'] = $this->input->post('eform_email_recipient');
		$data['eform_admin_notification'] = $this->input->post('eform_admin_notification');
		$data['eform_admin_notification_subject'] = $this->input->post('eform_admin_notification_subject');
		
		//validate form
		$this->form_validation->set_rules('eform_email_recipient','Email Recipient', 'required|valid_emails');
		$this->form_validation->set_rules('eform_admin_notification', 'Printable Forms message [Admin Noification]', 'required');
		$this->form_validation->set_rules('eform_admin_notification_subject', 'Subject' ,'required');
		if($this->form_validation->run()){
			$_SESSION['saved'] = TRUE;
			if ($this->m_settings->save_settings($data)){

				$this->session->set_flashdata('message', 'Settings Saved.');
				redirect('admin/eform/settings');
			}
		}
		//parse template
		$this->parser->parse('admin/template', $data);
	}
	
	function pagination($pagination_config){
		/*PAGINATION SETTING*/
		$config['base_url'] = $pagination_config['base_url'];
		$config['total_rows'] = $pagination_config['count']; 
		$config['per_page'] = $pagination_config['perpage']; 
		$config['uri_segment'] = 4;
		$config['num_links'] = 4;
		//first and last links
		$config['first_link'] = '&laquo; First';
		$config['last_link'] = 'Last &raquo;';
		//first link tags
		$config['first_tag_open'] = '<li style="margin-right:20px;">';
		$config['first_tag_close'] = '</li>';
		//last link tags
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '<li>';
		//next link tags
		$config['next_link'] = 'Next &raquo;';
		$config['next_tag_open'] = '<li style="margin-right:20px;margin-left:10px;"">';
		$config['next_tag_close'] = '</li>';
		//previous link tags
		$config['prev_link'] = '&laquo; Previous';
		$config['prev_tag_open'] = '<li style="margin-right:10px;">';
		$config['prev_tag_close'] = '</li>';
		//current link tags
		$config['cur_tag_open'] = '<li class="active"><a>';
		$config['cur_tag_close'] = '</a></li>';
		//links tags
		$config['num_tag_open'] = '<li class="pages">';
		$config['num_tag_close'] = '</li>';
		$this->pagination->initialize($config);
	}
	
}

/* End of file form.php */
/* Location: ./application/controllers/admin/eform.php */