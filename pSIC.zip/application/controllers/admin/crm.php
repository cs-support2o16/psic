<?php

error_reporting(0);
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Crm extends MY_Controller {

    function __construct() {
        parent::__construct();
        if (!$this->session->userdata('logged_in'))
            redirect('admin/login');
        $this->load->library('pagination');
        $this->load->library('form_validation');
        $this->load->helper('text');
        $this->load->helper('csv');
        $this->load->helper('download');
        $this->load->helper('cs_dropdown');
        $this->load->helper('cs_functions');
        $this->load->model('admin/M_administrator');
        $this->load->model('admin/M_website');
        $this->load->model('admin/M_mri');
        $this->load->model('default/M_crm_status');
        $this->load->model('default/M_crm_status_history');
        $this->load->model('default/M_crm_note');
        $this->load->model('default/M_crm_note_history');
        $this->load->model('default/M_crm_form_one');
        $this->load->model('default/M_crm_transaction');
        $this->load->model('default/M_crm_form_two');
        $this->load->model('default/M_crm_form_three');
        $this->load->model('default/M_crm_reminder');
        $this->load->model('admin/M_transactional_emails');
    }

    function index($offset = 0) {

        $search_fields = array();
        $export_options = array();

        //search fields
        $ms_one = '';
        $ms_two = '';
        $ms_three = '';
        $ms_one_value = '';
        $ms_two_value = '';
        $ms_three_value = '';
        $perpage = 10;
        $order_by = 'capture_date';

        //export options
        $lead_captured_date_from = '';
        $lead_captured_date_to = '';
        $lastname = '';
        $zip = '';
        $zip_from = '';
        $zip_to = '';
        $modified_date_from = '';
        $modified_date_to = '';
        $status = '';

        if ($this->input->post('axn') != '') {
            if ($this->input->post('axn') == 'multi_delete') {

                $this->multi_delete($this->input->post('leads'));
            } else {
                //show and sort by feature
                if ($this->input->post('axn') == 'multi_search') {
                    $perpage = 10;
                    $order_by = 'date_sent';
                    $this->session->unset_userdata('crm_order_by');
                    $this->session->unset_userdata('crm_perpage');
                } else {
                    $perpage = ($this->input->post('show_perpage') != '') ? $this->input->post('show_perpage') : $this->session->userdata('crm_perpage');
                    $perpage = ($perpage != '') ? $perpage : 10;
                    $this->session->set_userdata('crm_perpage', $perpage);
                    $order_by = ($this->input->post('lead_sort_val') != '') ? $this->input->post('lead_sort_val') : $this->session->userdata('crm_order_by');
                }
                if ($this->input->post('axn') == 'sort') {
                    if ($this->session->userdata('crm_ob_type') == '') {
                        $this->session->set_userdata('crm_ob_type', 'ASC');
                    } else {
                        if ($this->session->userdata('crm_ob_type') == 'ASC') {
                            $this->session->set_userdata('crm_ob_type', 'DESC');
                        } else {
                            $this->session->set_userdata('crm_ob_type', 'ASC');
                        }
                    }
                    $this->session->set_userdata('crm_order_by', $order_by);
                } else {
                    $this->session->unset_userdata('crm_ob_type');
                }

                //multi search feature
                $ms_one = $this->input->post('ms_one');
                $ms_two = $this->input->post('ms_two');
                $ms_three = $this->input->post('ms_three');

                $ms_one_value = $this->input->post('ms_one_value');
                $ms_two_value = $this->input->post('ms_two_value');
                $ms_three_value = $this->input->post('ms_three_value');


                if ($ms_one != '' && $ms_one_value != '') {
                    $search_fields[$ms_one] = $ms_one_value;
                    $this->session->set_userdata('ms_one', $ms_one);
                    $this->session->set_userdata('ms_one_value', $ms_one_value);
                } else {
                    if ($this->session->userdata('ms_one_value') != '' && $this->input->post('axn') != 'multi_search') {
                        $search_fields[$this->session->userdata('ms_one')] = $this->session->userdata('ms_one_value');
                        $ms_one = $this->session->userdata('ms_one');
                        $ms_one_value = $this->session->userdata('ms_one_value');
                    } else {
                        $this->session->unset_userdata('ms_one');
                        $this->session->unset_userdata('ms_one_value');
                    }
                }
                if ($ms_two != '' && $ms_two_value != '') {
                    $search_fields[$ms_two] = $ms_two_value;
                    $this->session->set_userdata('ms_two', $ms_two);
                    $this->session->set_userdata('ms_two_value', $ms_two_value);
                } else {
                    if ($this->session->userdata('ms_two_value') != '' && $this->input->post('axn') != 'multi_search') {
                        $search_fields[$this->session->userdata('ms_two')] = $this->session->userdata('ms_two_value');
                        $ms_two = $this->session->userdata('ms_two');
                        $ms_two_value = $this->session->userdata('ms_two_value');
                    } else {
                        $this->session->unset_userdata('ms_two');
                        $this->session->unset_userdata('ms_two_value');
                    }
                }
                if ($ms_three != '' && $ms_three_value != '') {
                    $search_fields[$ms_three] = $ms_three_value;
                    $this->session->set_userdata('ms_three', $ms_three);
                    $this->session->set_userdata('ms_three_value', $ms_three_value);
                } else {
                    if ($this->session->userdata('ms_three_value') != '' && $this->input->post('axn') != 'multi_search') {
                        $search_fields[$this->session->userdata('ms_three')] = $this->session->userdata('ms_three_value');
                        $ms_three = $this->session->userdata('ms_three');
                        $ms_three_value = $this->session->userdata('ms_three_value');
                    } else {
                        $this->session->unset_userdata('ms_three');
                        $this->session->unset_userdata('ms_three_value');
                    }
                }

                //export options
                $lead_captured_date_from = $this->input->post('capture_date_from');
                $lead_captured_date_to = $this->input->post('capture_date_to');
                $lastname = $this->input->post('lname');
                $zip = $this->input->post('zip');
                $zip_from = $this->input->post('zip_from');
                $zip_to = $this->input->post('zip_to');
                $modified_date_from = $this->input->post('modified_date_from');
                $modified_date_to = $this->input->post('modified_date_to');
                $status = $this->input->post('status_id');

                if ($this->input->post('axn') == 'export') {

                    if ($lead_captured_date_from == '' && $lead_captured_date_to == '' && $lastname == '' && $zip == '' && $zip_from == '' && $zip_to == '' && $modified_date_from == '' && $modified_date_to == '' && $status == '') {
                        $this->export_mri();
                    }
                    $perpage = 10;
                    $order_by = 'date_sent';
                    $this->session->unset_userdata('crm_order_by');
                    $this->session->unset_userdata('crm_perpage');
                } else {
                    $perpage = ($this->input->post('show_perpage') != '') ? $this->input->post('show_perpage') : $this->session->userdata('crm_perpage');
                    $perpage = ($perpage != '') ? $perpage : 10;
                    $this->session->set_userdata('crm_perpage', $perpage);
                    $order_by = ($this->input->post('lead_sort_val') != '') ? $this->input->post('lead_sort_val') : $this->session->userdata('crm_order_by');
                }
                //end of export options				
            }
        }


        //search fields
        $data['ms_one'] = $ms_one;
        $data['ms_two'] = $ms_two;
        $data['ms_three'] = $ms_three;
        $data['ms_one_value'] = $ms_one_value;
        $data['ms_two_value'] = $ms_two_value;
        $data['ms_three_value'] = $ms_three_value;
        if (count($search_fields) > 0) {
            //set page data
            $data_array = $this->M_mri->multi_search($search_fields);

            $this->pagination($perpage, count($data_array));
            //set page data
            $data['mri_logs'] = $this->M_mri->multi_search($search_fields, $perpage, $offset, $order_by);
        } else {
            $this->pagination($perpage);
            $data['mri_logs'] = $this->M_mri->get_all($perpage, $offset, $order_by);
        }

        //set page data
        $data['recent_transactions'] = $this->M_crm_transaction->find_recent();
        $data['lead_report'] = $this->M_mri->lead_report();
        $data['lead_status'] = $this->M_crm_status->fetch_all()->result();

        $data['title'] = 'CRM';
        $data['content'] = 'admin/crm/crm';
        $data['sitename'] = $this->M_website->getName();
        $data['show_perpage'] = $perpage;
        $data['crm_order_by'] = $order_by;
        $data['lead_axn'] = $this->input->post('axn');


        $data = array_merge($data, $this->_date(time()));

        //parse template
        $this->parser->parse('admin/crm_template', $data);
    }

    function calendar($timeid = 0) {


        //search fields
        $perpage = 10;
        $order_by = 'capture_date';

        //search fields
        $data['ms_one'] = '';
        $data['ms_two'] = '';
        $data['ms_three'] = '';
        $data['ms_one_value'] = '';
        $data['ms_two_value'] = '';
        $data['ms_three_value'] = '';

        $this->pagination($perpage, null, null, 5);
        $data['mri_logs'] = $this->M_mri->get_all($perpage, 0, 'capture_date');

        //set page data
        $data['recent_transactions'] = $this->M_crm_transaction->find_recent();
        $data['lead_report'] = $this->M_mri->lead_report();
        $data['lead_status'] = $this->M_crm_status->fetch_all()->result();

        $data['title'] = 'CRM';
        $data['content'] = 'admin/crm/crm';
        $data['sitename'] = $this->M_website->getName();
        $data['show_perpage'] = $perpage;
        $data['crm_order_by'] = $order_by;
        $data['lead_axn'] = $this->input->post('axn');

        if ($timeid == 0) {
            $time = time();
        } else {
            $time = $timeid;
        }
        $data = array_merge($data, $this->_date($time));

        //parse template
        $this->parser->parse('admin/crm_template', $data);
    }

    function view_all_transactions($offset = 0) {

        $perpage = 10;
        $order_by = 'date_created';
        if ($this->input->post('axn') == 'sort') {
            $order_by = ($this->input->post('lead_sort_val') != '') ? $this->input->post('lead_sort_val') : $this->session->userdata('crm_order_by');
            if ($this->session->userdata('crm_ob_type') == '') {
                $this->session->set_userdata('crm_ob_type', 'ASC');
            } else {
                if ($this->session->userdata('crm_ob_type') == 'ASC') {
                    $this->session->set_userdata('crm_ob_type', 'DESC');
                } else {
                    $this->session->set_userdata('crm_ob_type', 'ASC');
                }
            }
            $this->session->set_userdata('crm_order_by', $order_by);
        } else {
            $this->session->unset_userdata('crm_ob_type');
        }

        $data_array = $this->M_crm_transaction->find_all($order_by);
        $base_url = base_url() . index_page() . 'admin/crm/view_all_transactions';
        $this->pagination($perpage, count($data_array), $base_url);

        $data['transactions'] = $this->M_crm_transaction->find_all($order_by, $perpage, $offset);
        //set page data
        $data['title'] = 'CRM';
        $data['content'] = 'admin/crm/transaction/view_all';
        $data['sitename'] = $this->M_website->getName();

        //parse template
        $this->parser->parse('admin/crm_template', $data);
    }

    function status_history($id = null, $offset = 0) {
        if ($id != null) {
            $perpage = 10;
            $data_array = $this->M_crm_status_history->find_by_lead($id);
            $base_url = base_url() . index_page() . 'admin/crm/history/status/' . $id;
            $this->pagination($perpage, count($data_array), $base_url, 5);
            $lead_data = $this->M_mri->get($id);

            if (count($lead_data) > 0) {
                $data['lead_data'] = $lead_data;
                $data['status_logs'] = $this->M_crm_status_history->find_by_lead($id, $perpage, $offset);
                //set page data
                $data['title'] = 'CRM';
                $data['content'] = 'admin/crm/history/status';
                $data['sitename'] = $this->M_website->getName();

                //parse template
                $this->parser->parse('admin/crm_template', $data);
            } else {
                show_error('Invalid or no ID specified');
            }
        } else {
            show_error('Invalid or no ID specified');
        }
    }

    function status_history_all($offset = 0) {

        $perpage = 10;
        $data_array = $this->M_crm_status_history->find_all();
        $base_url = base_url() . index_page() . 'admin/crm/status_history_all';
        $this->pagination($perpage, count($data_array), $base_url);

        $data['status_logs'] = $this->M_crm_status_history->find_all($perpage, $offset);
        //set page data
        $data['title'] = 'CRM';
        $data['content'] = 'admin/crm/history/status_all';
        $data['sitename'] = $this->M_website->getName();

        //parse template
        $this->parser->parse('admin/crm_template', $data);
    }

    function note_history($id = null, $offset = 0) {
        if ($id != null) {
            $note_data = $this->M_crm_note->get($id);
            if (count($note_data) > 0) {

                $perpage = 10;
                $data_array = $this->M_crm_note_history->find_by_note($id);
                $base_url = base_url() . index_page() . 'admin/crm/history/note/' . $id;
                $this->pagination($perpage, count($data_array), $base_url, 5);

//                $data['current_note'] = $note_data->note;
//                $data['current_attachment'] = $note_data->attachment;
                $data['note_logs'] = $this->M_crm_note_history->find_by_note($id, $perpage, $offset);
                //set page data
                $data['title'] = 'CRM';
                $data['content'] = 'admin/crm/history/note';
                $data['sitename'] = $this->M_website->getName();


                //parse template
                $this->parser->parse('admin/crm_template', $data);
            } else {
                show_error('Invalid or no ID specified');
            }
        } else {
            show_error('Invalid or no ID specified');
        }
    }

    function qualifications_checklist($id) {
        if ($id != null) {
            $crm_data = $this->M_mri->get($id);
            if (count($crm_data) > 0) {

                $crm_form_one = $this->M_crm_form_one->find_by_mri($id);
                $data['crm_form'] = $crm_form_one;
                //set page data
                $data['title'] = 'CRM';
                $data['content'] = 'admin/crm/status_form/qualifications_checklist';
                $data['sitename'] = $this->M_website->getName();
                $data['crm_data'] = $crm_data;


                $this->_prep_form_values('crm_form_one');
                if ($this->input->post('submit')) {
                    $this->load->config('validations');
                    $config = $this->config->item('crm_form_one');
                    $this->require_validation($config);
                    $this->form_validation->set_message('required', 'This is required.');
                    if ($this->form_validation->run()) {
                        $done_procedure_date = array();
                        if (isset($_POST['done_procedure_date'])) {
                            foreach ($_POST['done_procedure_date'] as $dt) {
                                if ($dt != '') {
                                    $done_procedure_date[] = date('Y-m-d', strtotime($dt));
                                }
                            }
                        }
                        foreach ($_POST as $k => $v) {
                            if ($k != 'submit') {
                                if ($k == 'done_procedure_type') {
                                    $this->_form_data[$k] = json_encode($v);
                                } else if ($k == 'done_procedure_date') {
                                    $this->_form_data[$k] = json_encode($done_procedure_date);
                                } else if ($k == 'mri_date') {
                                    if ($v != '') {
                                        $this->_form_data[$k] = date('Y-m-d', strtotime($v));
                                    } else {
                                        $this->_form_data[$k] = '0000-00-00';
                                    }
                                } else {
                                    $this->_form_data[$k] = $v;
                                }
                            }
                        }
                        if (count($crm_form_one) > 0) {
                            $this->_form_data['updated_by'] = $this->session->userdata('id_admin');
                            $this->_form_data['crm_form_one_id'] = $crm_form_one['crm_form_one_id'];
                        } else {
                            $this->_form_data['posted_by'] = $this->session->userdata('id_admin');
                        }

                        if ($this->M_crm_form_one->do_save($this->_form_data)) {
                            $_mri_data = array(
                                'id_mri' => $this->_form_data['id_mri'],
                                'status_flag' => '1'
                            );
                            $this->M_mri->do_merge($_mri_data);

                            //save transaction
                            $admin_action = array(
                                'action' => 'Qualifications Checklist',
                                'title' => $crm_data['fname'] . ' ' . $crm_data['lname'],
                                'object_id' => $crm_data['id_mri']
                            );
                            save_crm_admin_action($admin_action);

                            $this->session->set_flashdata('message', 'Qualifications checklist successfully submitted.');
                            redirect('admin/crm');
                        }
                    }
                }


                //parse template
                $this->parser->parse('admin/crm_template', $data);
            } else {
                show_error('Invalid or no ID specified');
            }
        } else {
            show_error('Invalid or no ID specified');
        }
    }

    function message($id) {
        if ($id != null) {
            $crm_data = $this->M_mri->get($id);
            if (count($crm_data) > 0) {
                //set page data
                $data['title'] = 'CRM';
                $data['content'] = 'admin/crm/status_form/message';
                $data['sitename'] = $this->M_website->getName();
                $data['crm_data'] = $crm_data;

                $crm_form_two = $this->M_crm_form_two->find_by_mri($id);
                $data['crm_form'] = $crm_form_two;

                $this->_prep_form_values('crm_form_two');
                if ($this->input->post('submit')) {
                    $this->load->config('validations');
                    $config = $this->config->item('crm_form_two');
                    $this->require_validation($config);
                    if ($this->form_validation->run()) {

                        $this->_form_data['date'] = date('Y-m-d', strtotime($this->_form_data['date']));
                        $this->_form_data['id_mri'] = $this->input->post('id_mri');

                        if (count($crm_form_two) > 0) {
                            $this->_form_data['updated_by'] = $this->session->userdata('id_admin');
                            $this->_form_data['crm_form_two_id'] = $crm_form_two['crm_form_two_id'];
                        } else {
                            $this->_form_data['posted_by'] = $this->session->userdata('id_admin');
                        }

                        if ($this->M_crm_form_two->do_save($this->_form_data)) {
                            $_mri_data = array(
                                'id_mri' => $this->_form_data['id_mri'],
                                'status_flag' => '1'
                            );
                            $this->M_mri->do_merge($_mri_data);


                            //save transaction
                            $admin_action = array(
                                'action' => 'Message Form',
                                'title' => $crm_data['fname'] . ' ' . $crm_data['lname'],
                                'object_id' => $crm_data['id_mri']
                            );
                            save_crm_admin_action($admin_action);

                            $this->session->set_flashdata('message', 'Message form successfully sent.');
                            redirect('admin/crm');
                        }
                    }
                }


                //parse template
                $this->parser->parse('admin/crm_template', $data);
            } else {
                show_error('Invalid or no ID specified');
            }
        } else {
            show_error('Invalid or no ID specified');
        }
    }

    function email_patient($id) {
        if ($id != null) {
            $crm_data = $this->M_mri->get($id);
            if (count($crm_data) > 0) {
                //set page data
                $data['title'] = 'CRM';
                $data['content'] = 'admin/crm/status_form/email_patient';
                $data['sitename'] = $this->M_website->getName();
                $data['crm_data'] = $crm_data;

                $this->_prep_form_values('crm_form_three');
                if ($this->input->post('submit')) {
                    $this->load->config('validations');
                    $config = $this->config->item('crm_form_three');
                    $this->require_validation($config);
                    if ($this->form_validation->run()) {
                        $this->_form_data['posted_by'] = $this->session->userdata('id_admin');
                        $this->_form_data['id_mri'] = $this->input->post('id_mri');
                        if ($this->M_crm_form_three->do_save($this->_form_data)) {

                            $_mri_data = array(
                                'id_mri' => $this->_form_data['id_mri'],
                                'status_flag' => '1'
                            );
                            $this->M_mri->do_merge($_mri_data);

                            $this->load->library('email');
                            $this->email->clear();
                            $config['mailtype'] = 'html';
                            $this->email->initialize($config);
                            $this->email->from($this->_form_data['from']);
                            $this->email->to($crm_data['email']);
                            $this->email->bcc('kirby@creatingskies.com,jamaica@creatingskies.com');
                            $this->email->subject($this->_form_data['subject']);
                            $this->email->message($this->_form_data['content']);
                            $this->email->send();

                            //save transaction
                            $admin_action = array(
                                'action' => 'Email Patient Form',
                                'title' => $crm_data['fname'] . ' ' . $crm_data['lname'],
                                'object_id' => $crm_data['id_mri']
                            );
                            save_crm_admin_action($admin_action);

                            $this->session->set_flashdata('message', 'Email successfully sent.');
                            redirect('admin/crm');
                        }
                    }
                }


                //parse template
                $this->parser->parse('admin/crm_template', $data);
            } else {
                show_error('Invalid or no ID specified');
            }
        } else {
            show_error('Invalid or no ID specified');
        }
    }

    function add_lead() {
        //set page data
        $data['title'] = 'CRM';
        $data['content'] = 'admin/crm/add_lead';
        $data['sitename'] = $this->M_website->getName();

        $duplicate = array();
        $this->_prep_form_values('add_lead_with_qc_form');
        $status_comment = '';
        $status_attachment = '';
        if ($this->input->post('submit')) {

            if ($this->_form_data['status_id'] != '') {
                $status_data = $this->M_crm_status->get($this->_form_data['status_id']);
                if (count($status_data) > 0) {
                    $data['description'] = $status_data->description;
                }
            }
            $this->load->config('validations');
            $config = $this->config->item('add_lead_with_qc_form');

            $uploadError = FALSE;
            $file = array();
            //IMAGE UPLOAD
            if (isset($_FILES['attachment']) && $_FILES['attachment']['name'] != '') {
                $file = upload_crm_attachment('status', 'attachment');
                if (isset($file['error'])) {
                    $uploadError = TRUE;
                }
            }

            $this->require_validation($config);
            if ($uploadError) {
                $file_error = (isset($file['error'])) ? $file['error'] : '';
                $data['file_error'] = $file_error;
                $this->_form_data['status_id'] = $this->input->post('status_id');
            } else {
                $attachment = (isset($file['data'])) ? $file['data']['file_name'] : $this->input->post('attachment_saved');
                $duplicate = $this->M_mri->check_duplicate($this->_form_data);

                if (count($duplicate) > 0) {
                    $duplicate_entry_flag = TRUE;
                } else {
                    if ($this->form_validation->run()) {

                        $attachment = ($attachment == '0') ? '' : $attachment;
                        $data['attachment'] = $attachment;
                        $this->_form_data['attachment'] = $attachment;
                        unset($this->_form_data['description']);
                        $this->_form_data['capture_date'] = date('Y-m-d', strtotime($this->_form_data['capture_date']));

                        //qc fields
                        unset($this->_form_data['qcf_symptoms']);
                        unset($this->_form_data['qcf_joint_replacement']);
                        unset($this->_form_data['qcf_done_procedure']);
                        unset($this->_form_data['qcf_affected_joint']);
                        unset($this->_form_data['qcf_doctors_type']);
                        unset($this->_form_data['qcf_pay_cash']);

                        if ($this->M_mri->do_save($this->_form_data)) {
                            $mri_id = $this->db->insert_id();

                            $_status_history = array(
                                'status_id' => $this->_form_data['status_id'],
                                'id_mri' => $mri_id,
                                'comment' => $this->_form_data['comment'],
                                'attachment' => $this->_form_data['attachment'],
                                'posted_by' => $this->session->userdata('id_admin'),
                                'history_date' => date('Y-m-d H:i:s')
                            );
                            $this->M_crm_status_history->do_save($_status_history);

                            //save transaction
                            $admin_action = array(
                                'action' => 'Add Lead',
                                'title' => $this->_form_data['fname'] . ' ' . $this->_form_data['lname'],
                                'object_id' => $mri_id
                            );
                            save_crm_admin_action($admin_action);

                            //QC FORM
                            $_crm_form = array();
                            if (count($_POST) > 0) {
                                $done_procedure_date = array();
                                if (isset($_POST['qcf_done_procedure_date'])) {
                                    foreach ($_POST['qcf_done_procedure_date'] as $dt) {
                                        if ($dt != '') {
                                        $done_procedure_date[] = date('Y-m-d', strtotime($dt));
                                        }
                                    }
                                }
                                foreach ($_POST as $k => $v) {
                                    if (strpos($k, 'qcf_') !== false) {
                                        $key = str_replace("qcf_", "", $k);
                                        if ($key == 'done_procedure_type') {
                                            $_crm_form[$key] = json_encode($v);
                                        } else if ($key == 'done_procedure_date') {
                                            $_crm_form[$key] = json_encode($done_procedure_date);
                                        } else if ($key == 'mri_date') {
                                            if ($v != '') {
                                                $_crm_form[$key] = date('Y-m-d', strtotime($v));
                                            } else {
                                                $_crm_form[$key] = '';
                                            }
                                        } else {
                                            $_crm_form[$key] = $v;
                                        }
                                    }
                                }

                                if (count($_crm_form) > 0) {
                                    $_crm_form['id_mri'] = $mri_id;
                                    $_crm_form['posted_by'] = $this->session->userdata('id_admin');

                                    if ($this->M_crm_form_one->do_save($_crm_form)) {

                                        //save transaction
                                        $qc_admin_action = array(
                                            'action' => 'Qualifications Checklist',
                                            'title' => $this->_form_data['fname'] . ' ' . $this->_form_data['lname'],
                                            'object_id' => $mri_id
                                        );
                                        save_crm_admin_action($qc_admin_action);
                                    }
                                }
                            }
                            //QC FORM END

                            $this->session->set_flashdata('message', 'Lead successfully added.');
                            redirect('admin/crm');
                        }
                    } else {

                        $file_path = str_replace('system/', '', BASEPATH) . 'uploads/crm/status/' . $attachment;
                        if (file_exists($file_path)) {
                            if (is_file($file_path)) {
                                unlink($file_path);
                            }
                        }
                    }
                }
            }
        }

        $data['duplicate_entry'] = $duplicate;

        //parse template
        $this->parser->parse('admin/crm_template', $data);
    }

    function edit_lead($id = null) {

        if ($id != null) {
            $crm_data = $this->M_mri->get($id);
            if (count($crm_data) > 0) {

                //set page data
                $data['title'] = 'CRM';
                $data['content'] = 'admin/crm/edit_lead';
                $data['sitename'] = $this->M_website->getName();
                $data['crm_data'] = $crm_data;
                $data['description'] = $crm_data['description'];
                $data['comment'] = $crm_data['comment'];
                $data['attachment'] = $crm_data['attachment'];
                $data['status_id'] = $crm_data['status_id'];

                $this->_prep_form_values('add_lead_form');
                if ($this->input->post('submit')) {

                    if ($this->_form_data['status_id'] != '') {
                        $status_data = $this->M_crm_status->get($this->_form_data['status_id']);
                        if (count($status_data) > 0) {
                            $data['description'] = $status_data->description;
                        }
                    }
                    $this->load->config('validations');
                    $config = $this->config->item('add_lead_form');

                    $uploadError = FALSE;
                    $file = array();
                    //IMAGE UPLOAD
                    if (isset($_FILES['attachment']) && $_FILES['attachment']['name'] != '') {
                        $file = upload_crm_attachment('status', 'attachment');
                        if (isset($file['error'])) {
                            $uploadError = TRUE;
                        }
                    }

                    $this->require_validation($config);
                    if ($uploadError) {
                        $file_error = (isset($file['error'])) ? $file['error'] : '';
                        $data['file_error'] = $file_error;
                        $this->_form_data['status_id'] = $this->input->post('status_id');
                    } else {
                        $attachment = (isset($file['data'])) ? $file['data']['file_name'] : $this->input->post('attachment_saved');
                        $data['attachment'] = $attachment;
                        if ($this->form_validation->run()) {
                            $attachment = ($attachment == '0') ? '' : $attachment;
                            $this->_form_data['id_mri'] = $crm_data['id_mri'];
                            $this->_form_data['attachment'] = $attachment;
                            if ($this->_form_data['status_id'] == $crm_data['status_id'] && $this->_form_data['comment'] == $crm_data['comment'] && $attachment == $crm_data['attachment']) {
                                //do nothing
                            } else {
                                if ($this->_form_data['status_id'] != $crm_data['status_id']) {
                                    $this->_form_data['status_flag'] = '0';
                                }
                                $this->_form_data['s_update_by'] = $this->session->userdata('id_admin');
                                $this->_form_data['s_update_date'] = date('Y-m-d H:i:s');
                            }
                            unset($this->_form_data['description']);
                            $this->_form_data['capture_date'] = date('Y-m-d', strtotime($this->_form_data['capture_date']));
                            if ($this->M_mri->do_merge($this->_form_data)) {

                                if ($this->_form_data['status_id'] == $crm_data['status_id'] && $this->_form_data['comment'] == $crm_data['comment'] && $attachment == $crm_data['attachment']) {
                                    //do nothing
                                } else {
                                    $_status_history = array(
                                        'status_id' => $this->_form_data['status_id'],
                                        'id_mri' => $crm_data['id_mri'],
                                        'comment' => $this->_form_data['comment'],
                                        'attachment' => $this->_form_data['attachment'],
                                        'posted_by' => $this->session->userdata('id_admin'),
                                        'history_date' => date('Y-m-d H:i:s')
                                    );
                                    $this->M_crm_status_history->do_save($_status_history);
                                }

                                //save transaction
                                $admin_action = array(
                                    'action' => 'Edit Lead',
                                    'title' => $this->_form_data['fname'] . ' ' . $this->_form_data['lname'],
                                    'object_id' => $crm_data['id_mri']
                                );
                                save_crm_admin_action($admin_action);
                                $this->session->set_flashdata('message', 'Lead successfully updated.');
                                redirect('admin/crm');
                            }
                        }
                    }
                }

                //parse template
                $this->parser->parse('admin/crm_template', $data);
            } else {
                show_error('Invalid or no ID specified');
            }
        } else {
            show_error('Invalid or no ID specified');
        }
    }

    function find_status() {

        $id = $this->input->post('id');
        $type = $this->input->post('type');
        $status_data = $this->M_crm_status->get($id);
        if (count($status_data) > 0) {
            $data = array(
                'status_id' => $status_data->status_id,
                'description' => $status_data->description
            );
            //parse template
            echo $this->parser->parse('admin/crm/inner/status', $data, TRUE);
        }
    }

    function remove_status_attachment() {

        $id = $this->input->post('id');
        $mri_data = $this->M_mri->get($id);
        if (count($mri_data) > 0) {
            $_mri_data = array(
                'id_mri' => $mri_data['id_mri'],
                'attachment' => '',
                's_update_by' => $this->session->userdata('id_admin'),
                's_update_date' => date('Y-m-d H:i:s')
            );
            $this->M_mri->do_merge($_mri_data);
            $_status_history = array(
                'status_id' => $mri_data['status_id'],
                'id_mri' => $mri_data['id_mri'],
                'comment' => $mri_data['comment'],
                'attachment' => '',
                'posted_by' => $this->session->userdata('id_admin'),
                'history_date' => date('Y-m-d H:i:s')
            );
            $this->M_crm_status_history->do_save($_status_history);

            $admin_action = array(
                'action' => 'Remove Attachment',
                'title' => $mri_data['fname'] . ' ' . $mri_data['lname'],
                'object_id' => $mri_data['id_mri']
            );
            save_crm_admin_action($admin_action);
            echo TRUE;
        }
    }

    function remove_note_attachment() {

        $id = $this->input->post('id');
        $note_data = $this->M_crm_note->get($id);
        if (count($note_data) > 0) {
            $_note_data = array(
                'note_id' => $note_data->note_id,
                'attachment' => '',
                'updated_by' => $this->session->userdata('id_admin')
            );
            $this->M_crm_note->do_save($_note_data);
            $_note_history = array(
                'note_id' => $note_data->note_id,
                'note' => $note_data->note,
                'attachment' => $note_data->attachment,
                'created_by' => $note_data->updated_by
            );
            $this->M_crm_note_history->do_save($_note_history);

            $admin_action = array(
                'action' => 'Remove Attachment',
                'title' => $note_data->note,
                'object_id' => $note_data->note_id
            );
            save_crm_admin_action($admin_action);
            echo TRUE;
        }
    }

    function download_note($file) {
        $full_path = str_replace('system/', '', BASEPATH) . 'uploads/crm/note/' . $file;
        if (file_exists($full_path)) {
            if (is_file($full_path)) {
                $admin_action = array(
                    'action' => 'Download Note Attachment',
                    'title' => $file,
                    'object_id' => '0'
                );
                save_crm_admin_action($admin_action);
                force_download($file, file_get_contents($full_path));
                return TRUE;
            }
        }
        return FALSE;
    }

    function download_status($file) {
        $full_path = str_replace('system/', '', BASEPATH) . 'uploads/crm/status/' . $file;
        if (file_exists($full_path)) {
            if (is_file($full_path)) {
                $admin_action = array(
                    'action' => 'Download Status Attachment',
                    'title' => $file,
                    'object_id' => '0'
                );
                save_crm_admin_action($admin_action);
                force_download($file, file_get_contents($full_path));
                return TRUE;
            }
        }
        return FALSE;
    }

    function status_update() {

        $result = "invalid_access";
        $status_id = $this->input->post('status_id');
        $comment = $this->input->post('comment');
        $id_mri = $this->input->post('id_mri');

        if ($status_id != '') {
            $status_data = $this->M_mri->get($id_mri);
            if (count($status_data) > 0) {

                $this->load->config('validations');
                $config = $this->config->item('status_update_form');

                $uploadError = FALSE;
                $file = array();
                //IMAGE UPLOAD
                if (isset($_FILES['attachment']) && $_FILES['attachment']['name'] != '') {
                    $file = upload_crm_attachment('status', 'attachment');
                    if (isset($file['error'])) {
                        $uploadError = TRUE;
                    }
                }

                $this->require_validation($config);
                if ($uploadError) {
                    $file_error = (isset($file['error'])) ? $file['error'] : '';
                    $result = '<div class="red">' . $file_error . '</div>';
                } else {
                    $attachment = (isset($file['data'])) ? $file['data']['file_name'] : $this->input->post('attachment_saved');
                    if ($this->form_validation->run()) {
                        $attachment = ($attachment == '0') ? '' : $attachment;

                        $_status_history = array(
                            'status_id' => $status_id,
                            'id_mri' => $id_mri,
                            'comment' => $comment,
                            'attachment' => $attachment,
                            'posted_by' => $this->session->userdata('id_admin'),
                            'history_date' => date('Y-m-d H:i:s')
                        );
                        $this->M_crm_status_history->do_save($_status_history);
                        $_mri_data = array(
                            'status_id' => $status_id,
                            'status_flag' => '0',
                            'comment' => $comment,
                            'attachment' => $attachment,
                            's_update_by' => $this->session->userdata('id_admin'),
                            's_update_date' => date('Y-m-d H:i:s'),
                            'id_mri' => $id_mri,
                        );
                        $this->M_mri->do_merge($_mri_data);
                        $_status_data = $this->M_crm_status->get($status_id);
                        if (count($_status_data) > 0) {

                            //save transaction
                            $admin_action = array(
                                'action' => 'Status Update',
                                'title' => $status_data['fname'] . ' ' . $status_data['lname'] . ' : Status ' . $status_data['status'] . ' Changed to Status ' . $_status_data->code,
                                'object_id' => $id_mri
                            );
                            save_crm_admin_action($admin_action);
                        }

                        $result = '<div class="green">Status successfully updated.</div>';
                    } else {
                        $result = validation_errors('<div class="red">', '</div>');
                    }
                }
            } else {
                $result = '<div class="red">Status is invalid.</div>';
            }
        } else {
            $result = '<div class="red">Status is required.</div>';
        }
        echo $result;
    }

    function add_reminder() {

        $result = "invalid_access";
        $title = $this->input->post('title');
        $date = $this->input->post('date');
        $note = $this->input->post('note');

        if ($title == '' || $date == '') {
            if ($title == '' && $date == '') {
                $result = 'required_title_date';
            } else {
                if ($title == '') {
                    $result = 'required_title';
                }
                if ($date == '') {
                    $result = 'required_date';
                }
            }
        } else {

            $_reminder_history = array(
                'title' => $title,
                'date' => date('Y-m-d', strtotime($date)),
                'note' => $note,
                'posted_by' => $this->session->userdata('id_admin'),
            );
            $this->M_crm_reminder->do_save($_reminder_history);
            $reminder_id = $this->db->insert_id();

            //save transaction
            $admin_action = array(
                'action' => 'Add Reminder',
                'title' => $title,
                'object_id' => $reminder_id
            );
            save_crm_admin_action($admin_action);

            $result = '<div class="green">Reminder successfully added.</div>';
        }
        echo $result;
    }

    function note_update() {

        $result = "invalid_access";
        $note_id = $this->input->post('note_id');
        $id_mri = $this->input->post('id_mri');
        $note = $this->input->post('note');

        $uploadError = FALSE;
        $file = array();
        //IMAGE UPLOAD
        if (isset($_FILES['attachment']) && $_FILES['attachment']['name'] != '') {
            $file = upload_crm_attachment('note', 'attachment');
            if (isset($file['error'])) {
                $uploadError = TRUE;
            }
        }

        if ($note != '') {
            if ($uploadError) {
                $file_error = (isset($file['error'])) ? $file['error'] : '';
                $result = '<div class="red">' . $file_error . '</div>';
            } else {
                $attachment = (isset($file['data'])) ? $file['data']['file_name'] : $this->input->post('attachment_saved');
                $attachment = ($attachment == '0') ? '' : $attachment;

                if ($note_id != '') {
                    $_note_data = array(
                        'note_id' => $note_id,
                        'note' => $note,
                        'attachment' => $attachment,
                        'updated_by' => $this->session->userdata('id_admin')
                    );
                    $this->M_crm_note->do_save($_note_data);
                    $result = '<div class="green">Note successfully updated.</div>';
                } else {

                    $_note_data = array(
                        'note' => $note,
                        'attachment' => $attachment,
                        'posted_by' => $this->session->userdata('id_admin'),
                    );
                    $this->M_crm_note->do_save($_note_data);
                    $note_id = $this->db->insert_id();

                    $_mri_data = array(
                        'note_id' => $note_id,
                        'id_mri' => $id_mri,
                    );
                    $this->M_mri->do_merge($_mri_data);
                    $result = '<div class="green">Note successfully added.</div>';
                }

                $_note_history = array(
                    'note_id' => $note_id,
                    'note' => $note,
                    'attachment' => $attachment,
                    'posted_by' => $this->session->userdata('id_admin'),
                );
                $this->M_crm_note_history->do_save($_note_history);

                //save transaction
                $admin_action = array(
                    'action' => 'Note Update',
                    'title' => $note,
                    'object_id' => $note_id
                );
                save_crm_admin_action($admin_action);
            }
        } else {
            $result = '<div class="red">Note is required.</div>';
        }
        echo $result;
    }

    function delete($id) {
        $crm_data = $this->M_mri->get($id);
        if (count($crm_data) > 0) {
            if ($this->M_mri->delete($id)) {
                //save transaction
                $admin_action = array(
                    'action' => 'Delete Lead',
                    'title' => $crm_data['fname'] . ' ' . $crm_data['lname'],
                    'object_id' => $crm_data['id_mri']
                );
                save_crm_admin_action($admin_action);
                $_SESSION['deleted'] = TRUE;
                $this->session->set_flashdata('message', 'Lead successfully deleted.');
                redirect('admin/crm');
            }
        }
    }

    function multi_delete($ids) {

        if (is_array($ids)) {
            $failCtr = 0;
            $successCtr = 0;
            $deleted_leads = array();
            $deleted_leads_array = $this->M_mri->find_deleted_items($ids);
            foreach ($ids as $row) {

                if (!$this->M_mri->delete($row)) {
                    $failCtr++;
                } else {
                    $deleted_leads[] = $row;
                    if (!array_key_exists($row, $deleted_leads_array)) {
                        unset($deleted_leads_array[$row]);
                    }
                    $successCtr++;
                }
            }

            if ($failCtr > 0) {
                $this->session->set_flashdata('error_message', $failCtr . ' lead(s) failed to delete.');
            }
            if ($successCtr > 0) {
                $this->session->set_flashdata('message', $successCtr . ' lead(s) successfully deleted.');
            }
            $deleted_leads_list = '';
            $deleted_ids_list = '';
            if (count($deleted_leads_array) > 0) {
                $deleted_leads_list = implode(",", $deleted_leads_array);
                $deleted_leads_list = rtrim($deleted_leads_list, ',');
                $deleted_ids_list = implode(",", $deleted_leads);
                $deleted_ids_list = rtrim($deleted_ids_list, ',');
            }
            //SAVE ADMIN ACTION LOG
            save_crm_admin_action(array('action' => 'Multiple Delete', 'title' => $deleted_leads_list, 'object_ids' => $deleted_ids_list));

            redirect('admin/crm');
        } else {
            $this->session->set_flashdata('error_message', 'Please select lead(s).');
            redirect('admin/crm');
        }
    }

    function set_modal_form() {
        if (!$this->session->userdata('logged_in'))
            redirect('admin/login');
        $axn = $this->input->post('axn');
        $id = $this->input->post('id');
        $data = array();
        if ($axn == 'status_update') {
            $status_data = $this->M_mri->get($id);
            if (count($status_data) > 0) {
                $data = array(
                    'id_mri' => $id,
                    'status_id' => $status_data['status_id'],
                    'description' => $status_data['description'],
                    'comment' => $status_data['comment'],
                    'attachment' => $status_data['attachment'],
                );
            }
        } else if ($axn == 'note_update') {
            $note_data = $this->M_mri->get($id);
            if (count($note_data) > 0) {
                $data = array(
                    'id_mri' => $id,
                    'note_id' => $note_data['note_id'],
                    'note' => $note_data['note'],
                    'attachment' => $note_data['note_attachment'],
                );
            }
        } else if ($axn == 'view_reminder') {
            $data = array(
                'date' => date('F j, Y', $id),
                'day' => date('d', $id),
                'events' => $this->M_crm_reminder->find_events_per_day(date('Y-m-d', $id))
            );
        }
        echo $this->parser->parse('admin/crm/modal/' . $axn, $data, TRUE);
    }

    function pagination($perpage, $count = null, $base_url = null, $uri_segment = 4) {

        if ($count == null) {
            $count = $this->M_mri->get_count();
        }
        if ($base_url == null) {
            $base_url = base_url() . index_page() . 'admin/crm/index/';
        }

        /* PAGINATION SETTING */
        $config['base_url'] = $base_url;
        $config['total_rows'] = $count;
        $config['per_page'] = $perpage;
        $config['uri_segment'] = $uri_segment;
        $config['num_links'] = 4;
        //first and last links
        $config['first_link'] = '&laquo; First';
        $config['last_link'] = 'Last &raquo;';
        //first link tags
        $config['first_tag_open'] = '<li style="margin-right:20px;">';
        $config['first_tag_close'] = '</li>';
        //last link tags
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '<li>';
        //next link tags
        $config['next_link'] = 'Next &raquo;';
        $config['next_tag_open'] = '<li style="margin-right:20px;margin-left:10px;"">';
        $config['next_tag_close'] = '</li>';
        //previous link tags
        $config['prev_link'] = '&laquo; Previous';
        $config['prev_tag_open'] = '<li style="margin-right:10px;">';
        $config['prev_tag_close'] = '</li>';
        //current link tags
        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '</a></li>';
        //links tags
        $config['num_tag_open'] = '<li class="pages">';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
    }

    function export_mri() {
        $data['mri_logs'] = $this->M_mri->export();
        $data['export_data'] = $this->M_mri->export_options($export_options);
    }

    function export() {
        //set page data
        $data['title'] = 'CRM';
        $data['content'] = 'admin/crm/export';
        $data['sitename'] = $this->M_website->getName();


        //parse template
        $this->parser->parse('admin/crm_template', $data);
    }

    function export_logs($params = null) {

        $export_options = array();

        //export options value
        $lead_captured_date_from = '';
        $lead_captured_date_to = '';
        $lastname = '';
        $zip = '';
        $zip_from = '';
        $zip_to = '';
        $modified_date_from = '';
        $modified_date_to = '';
        $status = '';

        if ($this->input->post('export')) {
            $lead_captured_date_from = $this->input->post('capture_date_from');
            $lead_captured_date_to = $this->input->post('capture_date_to');
            $lastname = $this->input->post('lname');
            $zip = $this->input->post('zip');
            $zip_from = $this->input->post('zip_from');
            $zip_to = $this->input->post('zip_to');
            $modified_date_from = $this->input->post('modified_date_from');
            $modified_date_to = $this->input->post('modified_date_to');
            $status = $this->input->post('status_id');
            $data['content'] = '';
            if ($lastname != '') {
                $export_options['lname'] = $lastname;
            }
            if ($zip !== '') {
                $export_options['zip'] = $zip;
            }
            if ($status != '') {
                $export_options['code'] = $status;
            }
            if ($lead_captured_date_from != '' && $lead_captured_date_to == '') {
                $export_options['capture_from'] = date('Y-m-d', strtotime($lead_captured_date_from));
            } elseif ($lead_captured_date_from == '' && $lead_captured_date_to != '') {
                $export_options['capture_to'] = date('Y-m-d', strtotime($lead_captured_date_to));
            } elseif ($lead_captured_date_from != '' && $lead_captured_date_to != '') {
                $export_options['capture_from'] = date('Y-m-d', strtotime($lead_captured_date_from));
                $export_options['capture_to'] = date('Y-m-d', strtotime($lead_captured_date_to));
            } else {
                $export_options['capture_date'] = '';
            }
            if ($modified_date_from != '' && $modified_date_to == '') {
                $export_options['modified_date_from'] = date('Y-m-d', strtotime($modified_date_from));
            } elseif ($modified_date_from == '' && $modified_date_to != '') {
                $export_options['modified_date_to'] = date('Y-m-d', strtotime($modified_date_to));
            } elseif ($modified_date_from != '' && $modified_date_to != '') {
                $export_options['modified_date_from'] = date('Y-m-d', strtotime($modified_date_from));
                $export_options['modified_date_to'] = date('Y-m-d', strtotime($modified_date_to));
            } else {
                $export_options['mri.date_updated'] = '';
            }
            if ($zip_from != '' && $zip_to == '') {
                $export_options['zip_from'] = $zip_from;
            } elseif ($zip_from == '' && $zip_to != '') {
                $export_options['zip_to'] = $zip_to;
            } elseif ($zip_from != '' && $zip_to != '') {
                $export_options['zip_from'] = $zip_from;
                $export_options['zip_to'] = $zip_to;
            } else {
                $export_options['zip'] = '';
            }

            $logs = $this->M_mri->export_options($export_options);
            if (!count($logs)) {
                //set page data
                $data['title'] = 'CRM';
                $data['content'] = 'admin/crm/export';
                $data['sitename'] = $this->M_website->getName();
                $this->session->set_flashdata('msg', 'No Lead Entry Found!');

                //parse template
                //$this->parser->parse('admin/crm_template', $data);
                redirect('admin/crm/export', 'refresh');
            } else {
                $this->session->set_flashdata('msg', '');
                echo '<script>';
                //echo "window.open('".$d."','_new');";
                echo "window.location='" . base_url() . "admin/crm/export';";
                echo '</script>';

                exit();

                redirect('admin/crm/export', 'refresh');
            }
        }
    }

    function import() {
        $this->load->model('default/m_settings');
        //set page data
        $data['title'] = 'CRM Manager';
        $data['content'] = 'admin/crm/import';
        $data['sitename'] = $this->M_website->getName();

        //parse template
        $this->parser->parse('admin/crm_template', $data);
    }

    function import_save() {
        if ($_FILES['webfile1']['name']) {
            require_once("./plugins/excel_reader2.php");

            $target_path1 = "csv/";
            $target_path1 = $target_path1 . basename($_FILES['webfile1']['name']);

            if (move_uploaded_file($_FILES['webfile1']['tmp_name'], $target_path1)) {
                basename($_FILES['webfile1']['name']);
            }

            $data = new Spreadsheet_Excel_Reader();
            $data->setOutputEncoding('CP1251'); // Set output Encoding.			
            $data->read("./csv/" . $_FILES['webfile1']['name']); // relative path to .xls that was uploaded earlier
            $all = array();
            $ctr = 0;
            for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {
                $row = array();
                $row['capture_date'] = (isset($data->sheets[0]['cells'][$i][1])) ? $data->sheets[0]['cells'][$i][1] : "";
                $row['fname'] = (isset($data->sheets[0]['cells'][$i][2])) ? $data->sheets[0]['cells'][$i][2] : "";
                $row['lname'] = (isset($data->sheets[0]['cells'][$i][3])) ? $data->sheets[0]['cells'][$i][3] : "";
                $row['zip'] = (isset($data->sheets[0]['cells'][$i][4])) ? $data->sheets[0]['cells'][$i][4] : "";
                $row['email'] = (isset($data->sheets[0]['cells'][$i][5])) ? $data->sheets[0]['cells'][$i][5] : "";
                $row['number'] = (isset($data->sheets[0]['cells'][$i][6])) ? $data->sheets[0]['cells'][$i][6] : "";
                $this->M_mri->import_record($row);

                //subscribe to mailing list
                $this->load->helper('cs_newsletter_helper');
                subscribe_for_mailing_list(
                        array(
                            'fname' => $row['fname'],
                            'lname' => $row['lname'],
                            'email' => $row['email'],
                        )
                );
            }

            $this->session->set_flashdata('message', '<p class="green bold">Record successfully imported.</p>');
        } else {
            $this->session->set_flashdata('message', '<p class="red bold">Choose csv file to import</p>');
        }

        redirect(base_url() . "admin/crm/import", "refresh");
    }

    // --------------------------------------------------------------------

    /**
     * Get calendar dates for selected time period.
     *
     * @param int $time
     * @return array
     */
    private function _date($time) {
        $data['events'] = $this->M_crm_reminder->get_events($time);

        $today = date("Y/n/j", time());
        $data['today'] = $today;

        $current_month = date("n", $time);
        $data['current_month'] = $current_month;

        $current_year = date("Y", $time);
        $data['current_year'] = $current_year;

        $current_month_text = date("F Y", $time);
        $data['current_month_text'] = $current_month_text;

        $total_days_of_current_month = date("t", $time);
        $data['total_days_of_current_month'] = $total_days_of_current_month;

        $first_day_of_month = mktime(0, 0, 0, $current_month, 1, $current_year);
        $data['first_day_of_month'] = $first_day_of_month;

        //geting Numeric representation of the day of the week for first day of the month. 0 (for Sunday) through 6 (for Saturday).
        $first_w_of_month = date("w", $first_day_of_month);
        $data['first_w_of_month'] = $first_w_of_month;

        //how many rows will be in the calendar to show the dates
        // $total_rows = ceil(($total_days_of_current_month + $first_w_of_month)/7);
        //$data['total_rows']= $total_rows;
        $data['total_rows'] = '6';

        //trick to show empty cell in the first row if the month doesn't start from Sunday
        $day = -$first_w_of_month;
        $data['day'] = $day;

        $next_month = mktime(0, 0, 0, $current_month + 1, 1, $current_year);
        $data['next_month'] = $next_month;

        $next_month_text = date("F \'y", $next_month);
        $data['next_month_text'] = $next_month_text;

        $previous_month = mktime(0, 0, 0, $current_month - 1, 1, $current_year);
        $data['previous_month'] = $previous_month;

        $previous_month_text = date("F \'y", $previous_month);
        $data['previous_month_text'] = $previous_month_text;

        $next_year = mktime(0, 0, 0, $current_month, 1, $current_year + 1);
        $data['next_year'] = $next_year;

        $next_year_text = date("F \'y", $next_year);
        $data['next_year_text'] = $next_year_text;

        $previous_year = mktime(0, 0, 0, $current_month, 1, $current_year - 1);
        $data['previous_year'] = $previous_year;

        $previous_year_text = date("F \'y", $previous_year);
        $data['previous_year_text'] = $previous_year_text;

        return $data;
    }

}

/* End of file mri.php */
    /* Location: ./application/controllers/admin/crm.php */    