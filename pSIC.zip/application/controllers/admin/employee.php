<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Employee extends MY_Controller {

    protected $_form_data;

    function __construct() {
        parent::__construct();
        if (!$this->session->userdata('logged_in'))
            redirect('admin/login');
        $this->load->library('form_validation');
        $this->load->library('pagination');
        $this->load->helper('text');
        $this->load->library('email');
        $this->load->helper('cs_dropdown');
        $this->load->helper('security');
        $this->load->helper('csv');
        $this->load->helper('form');
        $this->load->helper('cs_functions');
        $this->load->helper('cs_emails');
        $this->load->model('default/M_employee');
        $this->load->model('admin/M_website');
        $this->load->model('admin/M_administrator');
        $this->load->model('admin/M_transactional_emails');
        $this->load->model('default/m_settings');
    }

    function index($offset = 0) {
        //set pagination
        $pagination_config = array(
            'perpage' => 10,
            'base_url' => base_url() . index_page() . 'admin/employee/index/',
            'count' => $this->M_employee->get_count()
        );
        $this->pagination($pagination_config);
        //set page data
        $data['user'] = $this->M_employee->get_all($pagination_config['perpage'], $offset);
        $data['title'] = 'User';
        $data['content'] = 'admin/employee/list';
        $data['sitename'] = $this->M_website->getName();

        //for actions messages
        $data['saved'] = $this->session->flashdata('saved');

        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function add() {

        //validate form
        $this->_prep_form_values('validation_employee_form');
        if ($this->input->post('submit')) {

            $this->_form_data['firstname'] = $this->input->post('firstname');
            $this->_form_data['middlename'] = $this->input->post('middlename');
            $this->_form_data['lastname'] = $this->input->post('lastname');
            $this->_form_data['status'] = 1;
            $this->_form_data['department'] = $this->input->post('department');
            $this->_form_data['position'] = $this->input->post('position');


            // Load fields from config.
            $this->load->config('validations');
            $config = $this->config->item('validation_employee_form');

            $this->require_validation($config);

            if ($this->form_validation->run()) {

                $_SESSION['saved'] = TRUE;
                if ($this->M_employee->do_insert($this->_form_data)) {

                    //SAVE ADMIN ACTION LOG
                    $id = $this->db->insert_id();
                    #save_admin_action(array('module' => Constant::AM_ACCOUNT, 'action' => Constant::AL_ADD, 'title' => $this->input->post('username'), 'object_id' => $id));

                    $this->session->set_flashdata('message', 'Employee has been added.');

                    redirect('admin/employee');
                }
            }
        }

        //set page data
        $data['title'] = 'Add User';
        $data['content'] = 'admin/employee/add';
        $data['sitename'] = $this->M_website->getName();
        //for actions messages
        $data['saved'] = $this->session->flashdata('saved');


        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function update() {

        $userList = $this->input->post('users');
        $department = $this->input->post('selectdepartment');

        if ($department != '') {

            foreach ($userList as $item) {
                $user = $this->M_employee->get($item);
                $name = $user['firstname'] . ' ' . $user['lastname'];
                if ($user['department'] != $department) {

                    $data = array(
                        'department' => $department,
                        'status' => 1,
                    );
                    if ($this->M_employee->updatedepartment($data, $item)) {

                        //get site data
                        $website = $this->M_website->getWebsite();

                    }

                    $this->session->set_flashdata('saved', TRUE);
                }
            }
        }

        redirect('admin/employee');
    }

    function deactivate($id = null) {

        if ($id != null) {

            $user = $this->M_employee->get($id);
            if (count($user)) {

                if ($user['department'] != '') {
                    $data = array(
                        'status' => '0',
                    );
                    $this->M_employee->updateStatus($data, $id);
                    $this->session->set_flashdata('message', 'Employee deactivated.');
                }
            }
        }
        redirect('admin/employee');
    }

    function activate($id = null) {

        if ($id != null) {

            $user = $this->M_employee->get($id);
            if (count($user)) {

                if ($user['department'] != '') {
                    $data = array(
                        'status' => '1',
                    );
                    $this->M_employee->updateStatus($data, $id);
                    $this->session->set_flashdata('message', 'Employee activated.');
                }
            }
        }
        redirect('admin/employee');
    }

    function update_department($id = null) {

        if ($id != null) {

            $user = $this->M_employee->get($id);
            if (count($user)) {

             

                if ($department != '') {
                    $data = array(
                        'department' => $department,
                    );
   
                    $this->session->set_flashdata('message', 'User department updated.');
                }
            }
        }
        redirect('admin/employee');
    }

    function settings() {
        $this->load->model('default/m_settings');
        //get transactional email
        $email_recipient = $this->m_settings->get('reg_email_recipient');
        $email_confirmation = $this->m_settings->get('reg_email_confirmation');
        $email_confirmation_subj = $this->m_settings->get('reg_email_confirmation_subject');
        $reg_approv_email_confirmation = $this->m_settings->get('reg_approv_email_confirmation');
        $reg_approv_email_confirmation_subj = $this->m_settings->get('reg_approv_email_confirmation_subject');
        $email_admin_notification = $this->m_settings->get('reg_admin_notification');
        $email_admin_notification_subj = $this->m_settings->get('reg_admin_notification_subject');
        $upgrade_to_premium_confirmation_subj = $this->m_settings->get('upgrade_to_premium_confirmation_subject');
        $upgrade_to_premium_confirmation = $this->m_settings->get('upgrade_to_premium_confirmation');
        $upgrade_to_premium_approve_confirmation_subj = $this->m_settings->get('upgrade_to_premium_approve_confirmation_subject');
        $upgrade_to_premium_approve_confirmation = $this->m_settings->get('upgrade_to_premium_approve_confirmation');
        $reset_password_email_confirmation_subj = $this->m_settings->get('reset_password_email_confirmation_subject');
        $reset_password_email_confirmation = $this->m_settings->get('reset_password_email_confirmation');
        $user_deactivate_email_confirmation_subj = $this->m_settings->get('user_deactivate_email_confirmation_subject');
        $user_deactivate_email_confirmation = $this->m_settings->get('user_deactivate_email_confirmation');

        //set page data
        $data['title'] = 'User Settings';
        $data['content'] = 'admin/employee/settings';
        $data['sitename'] = $this->M_website->getName();
        $data['reg_email_recipient'] = $email_recipient->setting_value;
        $data['reg_email_confirmation'] = $email_confirmation->setting_value;
        $data['reg_email_confirmation_subject'] = $email_confirmation_subj->setting_value;
        $data['reg_approv_email_confirmation'] = $reg_approv_email_confirmation->setting_value;
        $data['reg_approv_email_confirmation_subject'] = $reg_approv_email_confirmation_subj->setting_value;
        $data['reg_admin_notification'] = $email_admin_notification->setting_value;
        $data['reg_admin_notification_subject'] = $email_admin_notification_subj->setting_value;
        $data['upgrade_to_premium_confirmation_subject'] = $upgrade_to_premium_confirmation_subj->setting_value;
        $data['upgrade_to_premium_confirmation'] = $upgrade_to_premium_confirmation->setting_value;
        $data['upgrade_to_premium_approve_confirmation_subject'] = $upgrade_to_premium_approve_confirmation_subj->setting_value;
        $data['upgrade_to_premium_approve_confirmation'] = $upgrade_to_premium_approve_confirmation->setting_value;
        $data['reset_password_email_confirmation_subject'] = $reset_password_email_confirmation_subj->setting_value;
        $data['reset_password_email_confirmation'] = $reset_password_email_confirmation->setting_value;
        $data['user_deactivate_email_confirmation_subject'] = $user_deactivate_email_confirmation_subj->setting_value;
        $data['user_deactivate_email_confirmation'] = $user_deactivate_email_confirmation->setting_value;

        if (isset($_SESSION['saved'])) {
            $data['saved'] = $_SESSION['saved'];
            unset($_SESSION['saved']);
        }
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function settings_save() {
        $this->load->model('default/m_settings');

        //set page data
        $data['title'] = 'Contact Us Settings';
        $data['content'] = 'admin/employee/settings';
        $data['sitename'] = $this->M_website->getName();
        $data['reg_email_recipient'] = $this->input->post('reg_email_recipient');
        $data['reg_email_confirmation'] = $this->input->post('reg_email_confirmation');
        $data['reg_email_confirmation_subject'] = $this->input->post('reg_email_confirmation_subject');
        $data['reg_approv_email_confirmation'] = $this->input->post('reg_approv_email_confirmation');
        $data['reg_approv_email_confirmation_subject'] = $this->input->post('reg_approv_email_confirmation_subject');
        $data['reg_admin_notification'] = $this->input->post('reg_admin_notification');
        $data['reg_admin_notification_subject'] = $this->input->post('reg_admin_notification_subject');
        $data['upgrade_to_premium_confirmation_subject'] = $this->input->post('upgrade_to_premium_confirmation_subject');
        $data['upgrade_to_premium_confirmation'] = $this->input->post('upgrade_to_premium_confirmation');
        $data['upgrade_to_premium_approve_confirmation_subject'] = $this->input->post('upgrade_to_premium_approve_confirmation_subject');
        $data['upgrade_to_premium_approve_confirmation'] = $this->input->post('upgrade_to_premium_approve_confirmation');
        $data['reset_password_email_confirmation_subject'] = $this->input->post('reset_password_email_confirmation_subject');
        $data['reset_password_email_confirmation'] = $this->input->post('reset_password_email_confirmation');
        $data['user_deactivate_email_confirmation_subject'] = $this->input->post('user_deactivate_email_confirmation_subject');
        $data['user_deactivate_email_confirmation'] = $this->input->post('user_deactivate_email_confirmation');


        //validate form
        $this->form_validation->set_rules('reg_email_recipient', 'Email Recipient', 'required|valid_email');
        $this->form_validation->set_rules('reg_email_confirmation', 'Registration Message [Confirmation]', 'required');
        $this->form_validation->set_rules('reg_email_confirmation_subject', 'Subject', 'required');
        $this->form_validation->set_rules('reg_approv_email_confirmation', 'Registration Approved Message [Confirmation]', 'required');
        $this->form_validation->set_rules('reg_approv_email_confirmation_subject', 'Subject', 'required');
        $this->form_validation->set_rules('reg_admin_notification', 'Registration Message [Admin Noification]', 'required');
        $this->form_validation->set_rules('reg_admin_notification_subject', 'Subject', 'required');
        $this->form_validation->set_rules('upgrade_to_premium_confirmation', 'Upgrade to Premium Message [Confirmation]', 'required');
        $this->form_validation->set_rules('upgrade_to_premium_confirmation_subject', 'Subject', 'required');
        $this->form_validation->set_rules('upgrade_to_premium_approve_confirmation', 'Upgrade to Premium Approved Message [Confirmation]', 'required');
        $this->form_validation->set_rules('upgrade_to_premium_approve_confirmation_subject', 'Subject', 'required');
        $this->form_validation->set_rules('reset_password_email_confirmation', 'Reset Password Message [Confirmation]', 'required');
        $this->form_validation->set_rules('reset_password_email_confirmation_subject', 'Subject', 'required');
        $this->form_validation->set_rules('user_deactivate_email_confirmation', 'User Deactivation Message [Confirmation]', 'required');
        $this->form_validation->set_rules('user_deactivate_email_confirmation_subject', 'Subject', 'required');

        if ($this->form_validation->run()) {
            $_SESSION['saved'] = TRUE;
            if ($this->m_settings->save_settings($data)) {

                $this->session->set_flashdata('message', 'Settings Saved.');
                redirect('admin/employee/settings');
            }
        }
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function pagination($pagination_config) {
        /* PAGINATION SETTING */
        $config['base_url'] = $pagination_config['base_url'];
        $config['total_rows'] = $pagination_config['count'];
        $config['per_page'] = $pagination_config['perpage'];
        $config['uri_segment'] = 4;
        $config['num_links'] = 4;
        //first and last links
        $config['first_link'] = '&laquo; First';
        $config['last_link'] = 'Last &raquo;';
        //first link tags
        $config['first_tag_open'] = '<li style="margin-right:20px;">';
        $config['first_tag_close'] = '</li>';
        //last link tags
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '<li>';
        //next link tags
        $config['next_link'] = 'Next &raquo;';
        $config['next_tag_open'] = '<li style="margin-right:20px;margin-left:10px;"">';
        $config['next_tag_close'] = '</li>';
        //previous link tags
        $config['prev_link'] = '&laquo; Previous';
        $config['prev_tag_open'] = '<li style="margin-right:10px;">';
        $config['prev_tag_close'] = '</li>';
        //current link tags
        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '</a></li>';
        //links tags
        $config['num_tag_open'] = '<li class="pages">';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
    }

    function reset_password($id = null) {


        if ($id != null) {

            $password = uniqid();
            if ($this->M_employee->resetPassword($id, base64_encode($password))) {
                //get site data
                $website = $this->M_website->getWebsite();

                //get user data
                $user = $this->M_employee->get($id);
                $name = $user['firstname'] . ' ' . $user['lastname'];

                $email_data = array(
                    'name' => $name,
                    'username' => $user['username'],
                    'password' => $password
                );

                // Send an email to the user.
                send_email_template(
                        'reset_password_email_confirmation', $user['email'], null, $email_data
                );
            }

            //redirect page
            $this->session->set_flashdata('password', TRUE);
            redirect('admin/employee');
        } else {
            show_error('Invalid or no ID specified');
        }
    }

    function view($id = null) {

        if ($id != null) {

            $user = $this->M_employee->get($id);
            //validate form
            $this->_prep_form_values('validation_employee_form');
            if ($this->input->post('submit')) {

                $this->_form_data['firstname'] = $this->input->post('firstname');
                $this->_form_data['lastname'] = $this->input->post('lastname');
                $this->_form_data['middlename'] = $this->input->post('middlename');
                $this->_form_data['status'] = 1;
                $this->_form_data['department'] = $this->input->post('department');
                $this->_form_data['position'] = $this->input->post('position');

#echo "<pre>"; print_r($this->_form_data); echo "</pre>";
                // Load fields from config.
                $this->load->config('validations');
                $config = $this->config->item('validation_employee_form');

                $this->require_validation($config);

                if ($this->form_validation->run()) {

                    $_SESSION['saved'] = TRUE;
                    if ($this->M_employee->updateAdmin($this->_form_data, $id)) {

                        //get site data
                        $website = $this->M_website->getWebsite();
                        $email_recipient = $this->m_settings->get('reg_email_recipient');

                        //get user fullname
                        $name = $this->_form_data['firstname'] . ' ' . $this->_form_data['lastname'];

                        if ($user['department'] != $this->_form_data['department']) {

                            if ($this->_form_data['department'] == 'CC rep') {

                                $email_confirmation = 'reg_approv_email_confirmation';
                            } else if ($this->_form_data['department'] == 'administrator') {

                                $email_confirmation = 'upgrade_to_premium_approve_confirmation';
                            }


                            $email_data = array(
                                'name' => $name,
                                'link' => '<a href="' . base_url() . 'login">' . base_url() . 'login</a>'
                            );

                            // Send an email to the user.
                            send_email_template(
                                    $email_confirmation, $this->_form_data['email'], null, $email_data
                            );
                        }

                        //SAVE ADMIN ACTION LOG
                       // save_admin_action(array('module' => Constant::AM_ACCOUNT, 'action' => Constant::AL_EDIT, 'title' => $this->_form_data['username'], 'object_id' => $id));

                        $this->session->set_flashdata('message', 'Employee details has been updated.');
                        redirect('admin/employee/view/' . $id);
                    }
                }
            }

            //set page data
            $data['title'] = 'Employee Detail';
            $data['content'] = 'admin/employee/view';
            $data['sitename'] = $this->M_website->getName();

            //for actions messages
            $data['saved'] = $this->session->flashdata('saved');

            $this->load->model('default/M_employee');
            $data['user'] = $user;

            //parse template
            $this->parser->parse('admin/template', $data);
        } else {
            show_error('Invalid or no ID specified');
        }
    }

    function export() {
        $website = $this->M_website->getName();
        //SAVE ADMIN ACTION LOG
        save_admin_action(array('module' => Constant::AM_ACCOUNT, 'action' => Constant::AL_EXPORT, 'title' => Constant::ALT_EXPORT));

        $sql = "SELECT firstname AS 'First Name', middlename AS 'Middlename', lastname AS 'Last Name', department AS 'Department', position AS 'Position' FROM ci_employee ORDER BY employee_id DESC";
        $query = $this->db->query($sql);
        query_to_csv($query, TRUE, $website . 'Employees.csv');
    }

    function delete($id) {
        $user = $this->M_employee->get($id);
        if (count($user) > 0) {
            if ($this->M_employee->delete($id)) {
                //SAVE ADMIN ACTION LOG
               // save_admin_action(array('module' => Constant::AM_ACCOUNT, 'action' => Constant::AL_DELETE, 'title' => $user['username'], 'object_id' => $id));

                //$_SESSION['deleted'] = TRUE;
                $this->session->set_flashdata('message', 'Employee successfully deleted.');
                redirect('admin/employee');
            }
        }
    }

    function import() {
        $this->load->model('default/m_settings');
        //set page data
        $data['title'] = 'Accounts Manager';
        $data['content'] = 'admin/employee/import';
        $data['sitename'] = $this->M_website->getName();

        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function import_save() {
        if ($_FILES['webfile1']['name']) {
            require_once("./plugins/excel_reader2.php");

            $target_path1 = "csv/";
            $target_path1 = $target_path1 . basename($_FILES['webfile1']['name']);

            if (move_uploaded_file($_FILES['webfile1']['tmp_name'], $target_path1)) {
                basename($_FILES['webfile1']['name']);
            }

            $data = new Spreadsheet_Excel_Reader();
            $data->setOutputEncoding('CP1251'); // Set output Encoding.			
            $data->read("./csv/" . $_FILES['webfile1']['name']); // relative path to .xls that was uploaded earlier
            $all = array();
            $ctr = 0;
            for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {
                $row = array();
                $row['fname'] = (isset($data->sheets[0]['cells'][$i][1])) ? $data->sheets[0]['cells'][$i][1] : "";
                $row['mname'] = (isset($data->sheets[0]['cells'][$i][2])) ? $data->sheets[0]['cells'][$i][2] : "";
                $row['lname'] = (isset($data->sheets[0]['cells'][$i][3])) ? $data->sheets[0]['cells'][$i][3] : "";
                $row['email'] = (isset($data->sheets[0]['cells'][$i][4])) ? $data->sheets[0]['cells'][$i][4] : "";
                $row['department'] = (isset($data->sheets[0]['cells'][$i][5])) ? $data->sheets[0]['cells'][$i][5] : "";
                $row['position'] = (isset($data->sheets[0]['cells'][$i][6])) ? $data->sheets[0]['cells'][$i][6] : "";
                $this->M_employee->import_record($row);
            }
             //SAVE ADMIN ACTION LOG
            save_admin_action(array('module' => Constant::AM_ACCOUNT, 'action' => Constant::AL_IMPORT, 'title' => Constant::ALT_IMPORT));

            $this->session->set_flashdata('message', '<p class="green bold">Record successfully imported.</p>');
        } else {
            $this->session->set_flashdata('message', '<p class="red bold">Choose csv file to import</p>');
        }

        redirect(base_url() . "admin/employee/import", "refresh");
    }

}
/* Location: ./application/controllers/admin/employee.php */