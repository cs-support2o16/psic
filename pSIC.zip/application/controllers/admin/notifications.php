<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Notifications extends MY_Controller {

    protected $_form_data;

    function __construct() {
        parent::__construct();
        if (!$this->session->userdata('logged_in'))
            redirect('admin/login');
        $this->load->library('form_validation');
        $this->load->library('pagination');
        $this->load->helper('text');
        $this->load->library('email');
        $this->load->helper('cs_dropdown');
        $this->load->helper('security');
        $this->load->helper('csv');
        $this->load->helper('form');
        $this->load->helper('cs_emails');
        $this->load->model('default/M_user');
        $this->load->model('admin/M_website');
        $this->load->model('admin/M_administrator');
        $this->load->model('admin/M_transactional_emails');
        $this->load->model('default/m_settings');
    }

    function index() {
        $this->load->model('default/m_settings');
        //get transactional email
        //New Account Created confirmation email
        $email_recipient = $this->m_settings->get('notif_admin_email_recipient');
        $email_confirmation = $this->m_settings->get('notif_account_created_confirmation');
        $email_confirmation_subj = $this->m_settings->get('notif_account_created_confirmation_subject');

        //New Account Verification email
        $notif_new_account_verification = $this->m_settings->get('notif_new_account_verification');
        $notif_new_account_verification_subj = $this->m_settings->get('notif_new_account_verification_subject');

        $email_admin_confirmation = $this->m_settings->get('notif_account_created_admin_confirmation');
        $email_admin_confirmation_subj = $this->m_settings->get('notif_account_created_admin_confirmation_subject');

        //Reset Password Verification email
        $notif_reset_password_email_confirmation_subj = $this->m_settings->get('notif_reset_password_email_confirmation_subject');
        $notif_reset_password_email_confirmation = $this->m_settings->get('notif_reset_password_email_confirmation');

        $notif_password_update_verification = $this->m_settings->get('notif_password_update_verification');
        $notif_password_update_verification_subject = $this->m_settings->get('notif_password_update_verification_subject');

        //set page data
        $data['title'] = 'Notification Settings';
        $data['content'] = 'admin/notifications/settings';
        $data['sitename'] = $this->M_website->getName();

        //New Account Created confirmation email
        $data['notif_admin_email_recipient'] = $email_recipient->setting_value;
        $data['notif_account_created_confirmation'] = $email_confirmation->setting_value;
        $data['notif_account_created_confirmation_subject'] = $email_confirmation_subj->setting_value;

        $data['notif_account_created_admin_confirmation'] = $email_admin_confirmation->setting_value;
        $data['notif_account_created_admin_confirmation_subject'] = $email_admin_confirmation_subj->setting_value;

        $data['notif_new_account_verification'] = $notif_new_account_verification->setting_value;
        $data['notif_new_account_verification_subject'] = $notif_new_account_verification_subj->setting_value;

        $data['notif_reset_password_email_confirmation_subject'] = $notif_reset_password_email_confirmation_subj->setting_value;
        $data['notif_reset_password_email_confirmation'] = $notif_reset_password_email_confirmation->setting_value;

        $data['notif_password_update_verification'] = $notif_password_update_verification->setting_value;
        $data['notif_password_update_verification_subject'] = $notif_password_update_verification_subject->setting_value;

        if (isset($_SESSION['saved'])) {
            $data['saved'] = $_SESSION['saved'];
            unset($_SESSION['saved']);
        }
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function settings_save() {
        $this->load->model('default/m_settings');

        //set page data
        $data['title'] = 'Contact Us Settings';
        $data['content'] = 'admin/notifications/settings';
        $data['sitename'] = $this->M_website->getName();

        $email_recipient = $this->m_settings->get('notif_admin_email_recipient')->setting_value;
        $email_confirmation = $this->m_settings->get('notif_account_created_confirmation')->setting_value;
        $email_confirmation_subj = $this->m_settings->get('notif_account_created_confirmation_subject')->setting_value;

        //New Account Verification email
        $notif_new_account_verification = $this->m_settings->get('notif_new_account_verification')->setting_value;
        $notif_new_account_verification_subj = $this->m_settings->get('notif_new_account_verification_subject')->setting_value;

        $email_admin_confirmation = $this->m_settings->get('notif_account_created_admin_confirmation')->setting_value;
        $email_admin_confirmation_subj = $this->m_settings->get('notif_account_created_admin_confirmation_subject')->setting_value;

        //Reset Password Verification email
        $notif_reset_password_email_confirmation_subj = $this->m_settings->get('notif_reset_password_email_confirmation_subject')->setting_value;
        $notif_reset_password_email_confirmation = $this->m_settings->get('notif_reset_password_email_confirmation')->setting_value;

        $notif_password_update_verification = $this->m_settings->get('notif_password_update_verification')->setting_value;
        $notif_password_update_verification_subject = $this->m_settings->get('notif_password_update_verification_subject')->setting_value;


        $data['notif_admin_email_recipient'] = $this->input->post('notif_admin_email_recipient');
        $data['notif_account_created_confirmation'] = $this->input->post('notif_account_created_confirmation');
        $data['notif_account_created_confirmation_subject'] = $this->input->post('notif_account_created_confirmation_subject');

        $data['notif_new_account_verification'] = $this->input->post('notif_new_account_verification');
        $data['notif_new_account_verification_subject'] = $this->input->post('notif_new_account_verification_subject');

        $data['notif_account_created_admin_confirmation'] = $this->input->post('notif_account_created_admin_confirmation');
        $data['notif_account_created_admin_confirmation_subject'] = $this->input->post('notif_account_created_admin_confirmation_subject');

        $data['notif_reset_password_email_confirmation_subject'] = $this->input->post('notif_reset_password_email_confirmation_subject');
        $data['notif_reset_password_email_confirmation'] = $this->input->post('notif_reset_password_email_confirmation');

        $data['notif_password_update_verification'] = $this->input->post('notif_password_update_verification');
        $data['notif_password_update_verification_subject'] = $this->input->post('notif_password_update_verification_subject');

        //validate form
        $this->form_validation->set_rules('notif_admin_email_recipient', 'Notification Email Recipient', 'required|valid_email');
        $this->form_validation->set_rules('notif_account_created_confirmation', 'New Account Created [Confirmation]', 'required');
        $this->form_validation->set_rules('notif_account_created_confirmation_subject', 'Subject', 'required');

        $this->form_validation->set_rules('notif_reset_password_email_confirmation', 'Reset Password Message [Confirmation]', 'required');
        $this->form_validation->set_rules('notif_reset_password_email_confirmation_subject', 'Reset Password Subject', 'required');

        $this->form_validation->set_rules('notif_new_account_verification', 'New Account Verification', 'required');
        $this->form_validation->set_rules('notif_new_account_verification_subject', 'New Account Verification Subject', 'required');

        $this->form_validation->set_rules('notif_account_created_admin_confirmation', 'New Account Created [Confirmation]', 'required');
        $this->form_validation->set_rules('notif_account_created_admin_confirmation_subject', 'Subject', 'required');

        $this->form_validation->set_rules('notif_password_update_verification', 'Password Update [Verification]', 'required');
        $this->form_validation->set_rules('notif_password_update_verification_subject', 'Password Update [Verification] Subject', 'required');


        if ($this->form_validation->run()) {
            $_SESSION['saved'] = TRUE;
            if ($this->m_settings->save_settings($data)) {

                //SAVE ADMIN ACTION LOG
                if ($email_recipient != $this->input->post('notif_admin_email_recipient')) {
                    save_admin_action(array('module' => Constant::AM_NOTIFICATIONS, 'action' => Constant::AL_EDIT_EMAIL_SETTINGS, 'title' => Constant::ALT_EMAIL_SETTINGS_RECIPIENT));
                }

                if (compare_large_string_values($email_confirmation, $this->input->post('notif_account_created_confirmation')) === FALSE ||
                        compare_large_string_values($notif_new_account_verification, $this->input->post('notif_new_account_verification')) === FALSE ||
                        compare_large_string_values($email_admin_confirmation, $this->input->post('notif_account_created_admin_confirmation')) === FALSE ||
                        compare_large_string_values($notif_reset_password_email_confirmation, $this->input->post('notif_reset_password_email_confirmation')) === FALSE ||
                        compare_large_string_values($notif_password_update_verification, $this->input->post('notif_password_update_verification')) === FALSE) {

                    save_admin_action(array('module' => Constant::AM_NOTIFICATIONS, 'action' => Constant::AL_EDIT_EMAIL_SETTINGS, 'title' => Constant::ALT_EMAIL_SETTINGS_RTE));
                } else {
                    if ($email_confirmation_subj != $this->input->post('notif_account_created_confirmation_subject')) {

                        save_admin_action(array('module' => Constant::AM_NOTIFICATIONS, 'action' => Constant::AL_EDIT_EMAIL_SETTINGS, 'title' => Constant::ALT_EMAIL_SETTINGS_RTE));
                    }
                    if ($notif_new_account_verification_subj != $this->input->post('notif_new_account_verification_subject')) {

                        save_admin_action(array('module' => Constant::AM_NOTIFICATIONS, 'action' => Constant::AL_EDIT_EMAIL_SETTINGS, 'title' => Constant::ALT_EMAIL_SETTINGS_RTE));
                    }
                    if ($email_admin_confirmation_subj != $this->input->post('notif_account_created_admin_confirmation_subject')) {

                        save_admin_action(array('module' => Constant::AM_NOTIFICATIONS, 'action' => Constant::AL_EDIT_EMAIL_SETTINGS, 'title' => Constant::ALT_EMAIL_SETTINGS_RTE));
                    }
                    if ($notif_reset_password_email_confirmation_subj != $this->input->post('notif_reset_password_email_confirmation_subject')) {

                        save_admin_action(array('module' => Constant::AM_NOTIFICATIONS, 'action' => Constant::AL_EDIT_EMAIL_SETTINGS, 'title' => Constant::ALT_EMAIL_SETTINGS_RTE));
                    }
                    if ($notif_password_update_verification_subject != $this->input->post('notif_password_update_verification_subject')) {

                        save_admin_action(array('module' => Constant::AM_NOTIFICATIONS, 'action' => Constant::AL_EDIT_EMAIL_SETTINGS, 'title' => Constant::ALT_EMAIL_SETTINGS_RTE));
                    }
                }

                $this->session->set_flashdata('message', 'Settings Saved.');
                redirect('admin/notifications');
            }
        }
        //parse template
        $this->parser->parse('admin/template', $data);
    }

}
