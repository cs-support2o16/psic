<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->helper('security');
		$this->load->model('admin/M_website');
		$this->load->model('admin/M_login');
		$this->load->model('admin/M_administrator');
		$this->load->model('default/M_user');
                $this->load->helper('cs_functions');
	}

	function index()
	{
		if($this->session->userdata('logged_in')) redirect('admin/dashboard');
		
		//if the reset password link clicked from the email
		$id_admin = $this->uri->segment(4);
		$reset_key = $this->uri->segment(5);
		if( $id_admin && $reset_key ){
			$admin = $this->M_administrator->confirmAdmin($id_admin, $reset_key);
			if(count($admin)){
				$this->M_administrator->resetPassword($admin['id_admin'], do_hash($admin['reset_pass']));
				//clear reset_key & reset_pass in db
				$this->M_administrator->saveResetPass($admin['id_admin'], '');
				$this->M_administrator->setResetKey($admin['id_admin'], '');
			}
		}		
		//set page data
		$data['title'] = 'Administrator Login';
		$data['website'] = $this->M_website->getWebsite();			
		$data['project_mode'] = $this->M_administrator->project_info("MDnetSolutions","project_mode");
		//parse template
		$this->parser->parse('admin/login/login', $data);
	}
	
	function do_login(){
		//set page data
		$data['title'] = 'Administrator Login';
		$data['website'] = $this->M_website->getWebsite();
		$data['project_mode'] = $this->M_administrator->project_info("MDnetSolutions","project_mode");
		//process 
		$username = $this->input->post('username', TRUE);
		$password = $this->input->post('password', TRUE);
		$admin = $this->M_login->login($username, do_hash($password));
		$admin_crm = $this->M_user->login($username, $password);

		if(count($admin)){
			$admin_data = array(
				'id_admin' => $admin['id_admin'],
				'username' => $admin['username'],
				'name' => $admin['name'],
				'email' => $admin['email'],
				'super_admin' => $admin['super_admin'],
                                'level' => $admin['level'],
                                'role' => '',
				'logged_in' => TRUE
			);
			$this->session->set_userdata($admin_data);

			$project_mode = $this->M_administrator->project_info("MDnetSolutions","project_mode");
			
			if($project_mode=="CreatingSkies")
			{
				$this->session->set_userdata('project_mode','CreatingSkies');
			}else{
				$this->session->set_userdata('project_mode','MDnetSolutions');
			}

                        //save admin login
                        save_admin_login('login');
                        
			redirect('admin/dashboard');
		}else{

                    if(count($admin_crm)){
                        if($admin_crm['status'] != 0){
			$admin_data = array(
				'id_admin' => $admin_crm['user_id'],
				'user_id' => $admin_crm['user_id'],
				'username' => $admin_crm['username'],
				'name' => $admin_crm['firstname'],
				'email' => $admin_crm['email'],
				'role' => $admin_crm['category'],
				'logged_in' => TRUE
			);
			$this->session->set_userdata($admin_data);
                        
                        //save admin login
                        save_admin_login('login');
                        
			redirect('admin/dashboard');
                      }else{
				$data['error1'] = TRUE;
                      }
		  }else{
			if($username && $password){
				$data['error'] = TRUE;
			}

		   }
			//parse template
			$this->parser->parse('admin/login/login', $data);
		}


	}
	
	function logout(){
		$admin_items = array('username' => '', 'email' => '', 'logged_in' => FALSE, 'role' => '', 'id_admin' => '');
		$this->session->unset_userdata($admin_items);
                //save admin login
                save_admin_login('logout');
		redirect('admin/administrator');
	}
	
}

/* End of file login.php */
/* Location: ./application/controllers/admin/login.php */