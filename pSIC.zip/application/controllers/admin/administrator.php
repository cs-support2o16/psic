<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Administrator extends MY_Controller {

    function __construct() {
        parent::__construct();
        if (!$this->session->userdata('logged_in'))
            redirect('admin/login');

        $this->require_validation();
        $this->load->helper('cs_dropdown');
        $this->load->helper('security');
        $this->load->model('admin/M_administrator');
        $this->load->model('admin/M_website');
        $this->load->model('default/M_user');
        $this->load->helper('cs_functions');
        $this->load->library('pagination');
        if ($this->session->userdata('logged_in')) {
            $this->load->model('default/M_admin_login');
            $this->M_admin_login->update_logged_in($this->session->userdata('admin_login_id'));     
        }
    }

    function index() {
        $this->load->helper('cs_dropdown');
        

        //set page data
        $data['title'] = 'Admin Settings';
        $role = $this->session->userdata('role');
        if($role!=''){
        $data['admin'] = $this->M_user->get($this->session->userdata('user_id'));         
        }else{
        $data['admin'] = $this->M_administrator->getAdmin($this->session->userdata('id_admin'));        
        }
        $data['website'] = $this->website_data;
        $data['sitename'] = (count($data['website']) ? $data['website']['name'] : '');
        $data['email_footer'] = $this->get_setting('global_email_footer');
        $data['content'] = 'admin/administrator/administrator';
        $data['saved'] = $this->session->flashdata('saved');

        $data['project_mode']   = $this->M_administrator->project_info("MDnetSolutions","project_mode");
        $data['global_captcha'] = $this->M_administrator->project_info("1","global_captcha");	
	
        // Merge the settings array so we have automatic access to all settings.
        $data = array_merge($data, $this->get_settings());
        //parse template
        $this->parser->parse('admin/template', $data);
    }
    
     function checkUniqueEmail($email) {  
	if($email == $this->session->userdata('email')){
			return TRUE;
	}else{
		$admin = $this->M_administrator->getAdminByEmail($email);
		if (count($admin)) {
			
				$this->form_validation->set_message('checkUniqueEmail', 'Email not available.');
				return FALSE;
			
		} else {
			return TRUE;
		}
	}
 }


    function save() {

        if (!$_POST) {
            redirect('admin/administrator');
            exit();
        }

        $settings = array();

        $this->form_validation->set_rules('sitename', 'Site Name', 'required');
        $this->form_validation->set_rules('admin_name', 'Administrator\'s Name', 'required');
        $this->form_validation->set_rules('admin_email', 'Administrator\'s Email', 'required|valid_email|callback_checkUniqueEmail');
        $this->form_validation->set_rules('admin_outgoing_email', 'Outgoing Email Sender Address', 'required|valid_email');
        $this->form_validation->set_rules('admin_official_address', 'Official Address', 'required');

        if ($this->form_validation->run() == FALSE) {
            //parse template
            $this->parser->parse('admin/template', $this->setPageData());
        } else {            

            if ($this->session->userdata('super_admin')) {
                //templates
                $settings['home_template'] = $this->input->post('home_template');
                $settings['inner_template'] = $this->input->post('inner_template');

                // Seminar settings.            
                $settings['seminars_show_full'] = $this->input->post('seminars_show_full');
                $settings['seminars_show_ended'] = $this->input->post('seminars_show_ended');
                $settings['seminars_enable_captcha'] = $this->input->post('seminars_enable_captcha');

                // Online Seminar settings.            		    		    
                $settings['online_seminars_enable_captcha'] = $this->input->post('online_seminars_enable_captcha');

                // Contact Us settings.
                $settings['contact_us_enable_captcha'] = $this->input->post('contact_us_enable_captcha');

                // Calendar settings.
                $settings['calendar_enable_recurring_events'] = $this->input->post('calendar_enable_recurring_events');

                // Appointment settings.
                $settings['appointment_enable_captcha'] = $this->input->post('appointment_enable_captcha');

                // Page manager settings.
                $settings['page_enable_scratchpad'] = $this->input->post('page_enable_scratchpad');

                // Appointment settings.
                $settings['testimonials_enable_captcha'] = $this->input->post('testimonials_enable_captcha');

                $settings['project_mode'] = $this->input->post('cmb_project');
                $_SESSION['project_mode'] = $this->input->post('cmb_project');
                
                $settings['global_captcha'] = $this->input->post('cmb_global_captcha');
            }

            $settings['global_email_footer'] = $this->input->post('global_email_footer');

            // Outgoing Email Address settings.
            $settings['admin_outgoing_email'] = $this->input->post('admin_outgoing_email');


            // Official Address settings.
            $settings['admin_official_address'] = $this->input->post('admin_official_address');

            //LOGO UPLOAD
            $uploadError = FALSE;
            if ($_FILES['site_logo']['name'] != '') {
                $uploaded_logo = $this->upload_logo();
                if (isset($uploaded_logo['error'])) {
                    $uploadError = TRUE;
                }
            }

            if ($uploadError) {
                $logo_error = $uploaded_logo['error'];
                $this->parser->parse('admin/template', $this->setPageData($logo_error, $settings));
            } else {

                $_POST['site_logo'] = (isset($uploaded_logo['data'])) ? $uploaded_logo['data']['file_name'] : $_POST['site_logo'];

                if ($this->M_administrator->updateAdmin($_POST, $this->session->userdata('id_admin')) && $this->M_website->updateWebsite($_POST)) {

                    //SAVE ADMIN ACTION LOG
                    save_admin_action(array('module' => Constant::AM_SETTINGS, 'action' => Constant::AL_EDIT, 'title' => Constant::ALT_GENERAL));

                    $this->m_settings->save_settings($settings);

                    $this->session->set_flashdata('saved', TRUE);
                    //redirect page
                    redirect('admin/administrator');
                }
            }
        }
    }

    function setPageData($logo_error = '', $settings = NULL) {
        //set page data
        $data['title'] = 'Admin Settings';
        $data['admin'] = $this->M_administrator->getAdmin($this->session->userdata('id_admin'));
        $data['website'] = $this->M_website->getWebsite();
        $data['content'] = 'admin/administrator/administrator';
        $data['sitename'] = (count($data['website']) ? $data['website']['name'] : '');
        $data['logo_error'] = $logo_error;

        if ($settings)
            $data = array_merge($settings, $data);
        // Merge the settings array so we have automatic access to all settings.
        $data = array_merge($data, $this->get_settings());

        return $data;
    }

    function password() {
        //set page data
        $data['title'] = 'Change Password';
          $role = $this->session->userdata('role');
           if($role!=''){
           $data['admin'] = $this->M_user->get($this->session->userdata('user_id'));         
          }else{
          $data['admin'] = $this->M_administrator->getAdmin($this->session->userdata('id_admin'));        
          }
        $data['sitename'] = $this->M_website->getName();
        $data['content'] = 'admin/administrator/administrator_password';

        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function change_password() {
          $role = $this->session->userdata('role');
        $this->form_validation->set_rules('old_password', 'Old password', 'required|xss_clean|callback_oldPasswordCheck');
        $this->form_validation->set_rules('new_password', 'New password', 'required|min_length[7]|xss_clean|matches[confirm_password]');
        $this->form_validation->set_rules('confirm_password', 'Confirm password', 'required|min_length[7]|xss_clean');
        if ($this->form_validation->run() == FALSE) {
            //set page data
            $data['title'] = 'Change Password';
           if($role!=''){
           $data['admin'] = $this->M_user->get($this->session->userdata('user_id'));         
          }else{
          $data['admin'] = $this->M_administrator->getAdmin($this->session->userdata('id_admin'));        
          }
            $data['sitename'] = $this->M_website->getName();
            $data['content'] = 'admin/administrator/administrator_password';

            //parse template
            $this->parser->parse('admin/template', $data);
        } else {
           if($role!=''){
            if ($this->M_user->changePassword($_POST['user_id'], base64_encode($_POST['new_password']))) {
                 //SAVE ADMIN ACTION LOG
                save_admin_action(array('module' => Constant::AM_SETTINGS, 'action' => Constant::AL_CHANGE_PASSWORD, 'title' => Constant::ALT_PASSWORD));
        
                //redirect page
                $this->session->set_flashdata('saved', TRUE);
                redirect('admin/administrator');
            }
           }else{           
            if ($this->M_administrator->changePassword($_POST['id_admin'], do_hash($_POST['new_password']))) {
                 //SAVE ADMIN ACTION LOG
                save_admin_action(array('module' => Constant::AM_SETTINGS, 'action' => Constant::AL_CHANGE_PASSWORD, 'title' => Constant::ALT_PASSWORD));
        
                //redirect page
                $this->session->set_flashdata('saved', TRUE);
                redirect('admin/administrator');
            }
          }
        }
    }

    function oldPasswordCheck($submitted_pass) {
        $role = $this->session->userdata('role');
      if($role!=''){
        $old_pass = $this->M_user->getPassword($this->input->post('user_id'));
        if ($old_pass == base64_encode($submitted_pass)) {
            return TRUE;
        } else {
            $this->form_validation->set_message('oldPasswordCheck', 'The %s field is wrong.');
            return FALSE;
        }
      }else{
        $old_pass = $this->M_administrator->getPassword($this->input->post('id_admin'));
        if ($old_pass == do_hash($submitted_pass)) {
            return TRUE;
        } else {
            $this->form_validation->set_message('oldPasswordCheck', 'The %s field is wrong.');
            return FALSE;
        }
      }
    }

    function upload_logo() {
        $config['upload_path'] = str_replace('system/', '', BASEPATH) . 'uploads/admin/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '2048';
        $config['max_width'] = '350';
        $config['max_height'] = '90';
        $config['file_name'] = 'logo';
        $config['overwrite'] = TRUE;
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('site_logo')) {
            $logo = array('error' => $this->upload->display_errors('<div class="red">', '</div>'));
        } else {
            $logo = array('data' => $this->upload->data());
        }
        return $logo;
    }

    function remove_logo() {
        $website = $this->M_website->getWebsite();
        if ($this->M_website->removeLogo($website['id_website'])) {
            //SAVE ADMIN ACTION LOG
            save_admin_action(array('module' => Constant::AM_SETTINGS, 'action' => Constant::AL_REMOVE_LOGO, 'title' => Constant::ALT_GENERAL));
            
            $filePath = str_replace('system/', '', BASEPATH) . 'uploads/admin/' . $website['site_logo'];
            if (file_exists($filePath)) {
                if (is_file($filePath)) {
                    unlink($filePath);
                    $this->session->set_flashdata('saved', TRUE);
                }
            }
        }
        redirect('admin/administrator');
    }

    function modules() {
        // Allow access to super_admin only.
        if (!$this->session->userdata('super_admin')) {
            redirect('admin');
        }

        $this->load->model('default/m_modules', 'modules');

        //set page data
        $data['title'] = 'Module Settings';
        $data['admin'] = $this->M_administrator->getAdmin($this->session->userdata('id_admin'));
        $data['sitename'] = $this->M_website->getName();
        $data['content'] = 'admin/administrator/modules';
        $data['modules'] = $this->modules->fetch_all()->result();

        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function toggle_module($id = null) {
        $this->load->model('default/m_modules', 'module');

        if (is_null($id) || !$module = $this->module->get($id)) {
            show_error('Invalid or no ID specified');
        }

        if ($module->activated == 1) {
            $toggle = 0;
            //SAVE ADMIN ACTION LOG
            save_admin_action(array('module' => Constant::AM_SETTINGS, 'action' => Constant::AL_DISABLE, 'title' => Constant::ALT_MODULES));
        
        } else {
            $toggle = 1;
            //SAVE ADMIN ACTION LOG
            save_admin_action(array('module' => Constant::AM_SETTINGS, 'action' => Constant::AL_ENABLE, 'title' => Constant::ALT_MODULES));
        
        }

        if ($this->module->do_save(array($this->module->get_primary_key() => $id, 'activated' => $toggle))) {
            $this->session->set_flashdata('message', ucwords($module->url_key) . ' module status updated');
        }

        redirect('admin/administrator/modules');
    }

    function login_history($offset = 0) {

        $this->load->model('default/M_admin_login');
        $this->load->model('default/M_admin_action');
        $this->load->model('default/m_modules', 'modules');

        //set page data
        $data['title'] = 'Module Settings';
        $data['admin'] = $this->M_administrator->getAdmin($this->session->userdata('id_admin'));
        $data['sitename'] = $this->M_website->getName();
        $data['content'] = 'admin/administrator/login_history';

        //FILTER DATA
        $data['filter_username'] = '';
        $data['filter_from'] = '';
        $data['filter_to'] = '';

        $perpage = 10;
        $offset = $this->uri->segment(5);
        $base_url = base_url() . index_page() . 'admin/administrator/login_history/index/';
        if ($this->session->userdata('super_admin')) {
            $total_rows = count($this->M_admin_login->fetch_previous_logs());
            $data['recent_logs'] = $this->M_admin_login->fetch_recent_logs();
            $data['previous_logs'] = $this->M_admin_login->fetch_previous_logs(NULL, NULL, $perpage, $offset);
        } else {
            $total_rows = count($this->M_admin_login->fetch_previous_logs($this->session->userdata('id_admin')));
            $data['recent_logs'] = $this->M_admin_login->fetch_recent_logs($this->session->userdata('id_admin'));
            $data['previous_logs'] = $this->M_admin_login->fetch_previous_logs($this->session->userdata('id_admin'), NULL, $perpage, $offset);
        }

        $this->pagination($perpage, $total_rows, $base_url);

        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function login_history_action() {

        $filter_username = $this->input->post('filter_username');
        $filter_module = $this->input->post('filter_module');
        $filter_from = $this->input->post('filter_from');
        $filter_to = $this->input->post('filter_to');

        $filter_data = array(
            'filter_username' => $filter_username,
            'filter_module' => $filter_module,
            'filter_from' => $filter_from,
            'filter_to' => $filter_to,
        );
        switch ($this->input->post('form_axn')) {
            case 'filter':
                if ($filter_username == '' && $filter_from == '' && $filter_to == '') {
                    redirect('admin/administrator/login_history');
                }
                $this->load->model('default/M_admin_login');
                $this->load->model('default/M_admin_action');
                $this->load->model('default/m_modules', 'modules');

                //set page data
                $data['title'] = 'Module Settings';
                $data['admin'] = $this->M_administrator->getAdmin($this->session->userdata('id_admin'));
                $data['sitename'] = $this->M_website->getName();
                $data['content'] = 'admin/administrator/login_history';

                //FILTER DATA
                $data['filter_username'] = $filter_username;
                $data['filter_from'] = $filter_from;
                $data['filter_to'] = $filter_to;

                if ($this->session->userdata('super_admin')) {
                    $data['recent_logs'] = $this->M_admin_login->fetch_recent_logs(null, $filter_data);
                    $data['previous_logs'] = $this->M_admin_login->fetch_previous_logs(null, $filter_data);
                } else {
                    $data['recent_logs'] = $this->M_admin_login->fetch_recent_logs($this->session->userdata('id_admin'), $filter_data);
                    $data['previous_logs'] = $this->M_admin_login->fetch_previous_logs($this->session->userdata('id_admin'), $filter_data);
                }

                //parse template
                $this->parser->parse('admin/template', $data);
                break;
            case 'export':
                //SAVE ADMIN ACTION LOG
                save_admin_action(array('module' => Constant::AM_SETTINGS, 'action' => Constant::AL_EXPORT_HISTORY, 'title' => Constant::ALT_LOGIN_HISTORY));
        
                $query = '';
                $this->load->helper('csv');
                $website = $this->M_website->getName();
                $query .= "SELECT ci_admin.name AS Name, ci_admin.username AS Username, ci_admin.email AS Email, DATE_FORMAT(ci_admin_login.login_date,'%M %e, %Y %T %p') as 'Login Date', DATE_FORMAT(ci_admin_login.logout_date,'%M %e, %Y %T %p') as 'Logout Date' FROM (`ci_admin_login`) LEFT JOIN `ci_admin` ON `ci_admin`.`id_admin` = `ci_admin_login`.`id_admin`";

                $where_flag = false;
                if (!$this->session->userdata('super_admin')) {
                    $query .= " WHERE ci_admin_login.id_admin = '" . $this->session->userdata('id_admin') . "'";
                    $where_flag = true;
                }
                if ($filter_username != '') {
                    if ($where_flag) {
                        $query .= ' AND ';
                    } else {
                        $query .= ' WHERE ';
                        $where_flag = true;
                    }
                    $query .= " ci_admin.username = '" . $filter_username . "'";
                }

                $filter_from = (isset($filter_data['filter_from'])) ? $filter_data['filter_from'] : '';
                $filter_to = (isset($filter_data['filter_to'])) ? $filter_data['filter_to'] : '';

                if ($filter_from != '' && $filter_to != '') {
                    if ($where_flag) {
                        $query .= ' AND ';
                    } else {
                        $query .= ' WHERE ';
                    }
                    $query .= "DATE_FORMAT(ci_admin_login.login_date,'%Y-%m-%d') BETWEEN '" . date('Y-m-d', strtotime($filter_from)) . "' AND '" . date('Y-m-d', strtotime($filter_to)) . "'";
                } else {
                    if ($filter_from != '') {
                        if ($where_flag) {
                            $query .= ' AND ';
                        } else {
                            $query .= ' WHERE ';
                        }
                        $query .= "DATE_FORMAT(ci_admin_login.login_date,'%Y-%m-%d') = '" . date('Y-m-d', strtotime($filter_from)) . "'";
                    }
                    if ($filter_to != '') {
                        if ($where_flag) {
                            $query .= ' AND ';
                        } else {
                            $query .= ' WHERE ';
                        }
                        $query .= "DATE_FORMAT(ci_admin_login.login_date,'%Y-%m-%d') = '" . date('Y-m-d', strtotime($filter_to)) . "'";
                    }
                }

                $query .= " ORDER BY `ci_admin_login`.`login_date` ASC";


                $query_sql = $this->db->query($query);
                query_to_csv($query_sql, TRUE, $website . '-Login-History-Log.csv');
                break;
            case 'filter_action':
                if ($filter_module == '' && $filter_from == '' && $filter_to == '') {
                    redirect('admin/administrator/login_history');
                }
              

                $this->load->model('default/M_admin_login');
                $this->load->model('default/M_admin_action');
                $this->load->model('default/m_modules', 'modules');

                //set page data
                $data['title'] = 'Module Settings';
                $data['admin'] = $this->M_administrator->getAdmin($this->session->userdata('id_admin'));
                $data['sitename'] = $this->M_website->getName();
                $data['content'] = 'admin/administrator/login_action';

                //FILTER DATA
                $data['filter_module'] = $filter_module;
                $data['filter_from'] = $filter_from;
                $data['filter_to'] = $filter_to;
                
                $url_ext = '';
                if($filter_module != ''){
                    $url_ext .= '/'. $filter_module;
                }else{
                    $url_ext .= '/0';
                }
                
                if($filter_from != ''){
                    $url_ext .= '/'. date('Y-m-d', strtotime($filter_from));
                }else{
                    $url_ext .= '/0';
                }
                if($filter_to != ''){
                    $url_ext .= '/'. date('Y-m-d', strtotime($filter_to));
                }else{
                    $url_ext .= '/0';
                }
               
                $perpage = 10;
                $id = $this->input->post('admin_login_id');
                $offset = $this->uri->segment(6);
                $base_url = base_url() . index_page() . 'admin/administrator/login_history_view/' . $id . $url_ext . '/index/';
                $total_rows = count($this->M_admin_action->find_by_admin_login($id, $filter_data));
                $uri_segment = 6;
                $this->pagination($perpage, $total_rows, $base_url, $uri_segment);
                $data['admin_action'] = $this->M_admin_action->find_by_admin_login($id, $filter_data, $perpage, $offset);
                $data['admin_login_id'] = $id;        
                        
                //parse template
                $this->parser->parse('admin/template', $data);
                break;
            case 'export_action':
                //SAVE ADMIN ACTION LOG
                save_admin_action(array('module' => Constant::AM_SETTINGS, 'action' => Constant::AL_EXPORT_ACTION, 'title' => Constant::ALT_LOGIN_HISTORY));
        
                $query = '';
                $this->load->helper('csv');
                $website = $this->M_website->getName();
                $admin_login_id = $this->input->post('admin_login_id');
                $query .= "SELECT ci_admin.name AS Name, ci_admin.username AS Username, ci_admin.email AS Email, ci_admin_action.action as Action, ci_admin_action.module as 'Module Name', ci_admin_action.title as Title, ci_admin_action.date_created as Date FROM (`ci_admin_action`) LEFT JOIN `ci_admin` ON `ci_admin`.`id_admin` = `ci_admin_action`.`id_admin` WHERE `ci_admin_action`.`admin_login_id` = '" . $admin_login_id . "'";

                $filter_from = (isset($filter_data['filter_from'])) ? $filter_data['filter_from'] : '';
                $filter_to = (isset($filter_data['filter_to'])) ? $filter_data['filter_to'] : '';
                $filter_module = (isset($filter_data['filter_module'])) ? $filter_data['filter_module'] : '';
                
                if ($filter_module != '') {
                    $query .= " AND ci_admin_action.module = '" . $filter_module . "'";
                } 
                
                if ($filter_from != '' && $filter_to != '') {

                    $query .= " AND DATE_FORMAT(ci_admin_action.date_created,'%Y-%m-%d') BETWEEN '" . date('Y-m-d', strtotime($filter_from)) . "' AND '" . date('Y-m-d', strtotime($filter_to)) . "'";
                } else {
                    if ($filter_from != '') {
                        $query .= " AND DATE_FORMAT(ci_admin_action.date_created,'%Y-%m-%d') = '" . date('Y-m-d', strtotime($filter_from)) . "'";
                    }
                    if ($filter_to != '') {
                        $query .= " AND DATE_FORMAT(ci_admin_action.date_created,'%Y-%m-%d') = '" . date('Y-m-d', strtotime($filter_to)) . "'";
                    }
                }

                $query .= " ORDER BY `ci_admin_action`.`date_created` ASC";

                $query_sql = $this->db->query($query);
                query_to_csv($query_sql, TRUE, $website . '-Login-Action-Log.csv');
                break;
        }
    }

    function login_history_view($id = null) {

        if ($id != null) {


            $this->load->model('default/M_admin_login');
            $this->load->model('default/M_admin_action');
            $this->load->model('default/m_modules', 'modules');

            //set page data
            $data['title'] = 'Module Settings';
            $data['admin'] = $this->M_administrator->getAdmin($this->session->userdata('id_admin'));
            $data['sitename'] = $this->M_website->getName();
            $data['content'] = 'admin/administrator/login_action';
            
            $filter_module = $this->uri->segment(5);
            $filter_from = $this->uri->segment(6);
            $filter_to = $this->uri->segment(7);
                
            //FILTER DATA
            $data['filter_module'] = '';
            $data['filter_from'] = '';
            $data['filter_to'] = '';
            
            $url_ext = '';
            $filter_data = array();
            if($filter_module != '' && $filter_module != '0'){
                $url_ext .= '/'. $filter_module;
                $data['filter_module'] = $filter_module;
                $filter_data['filter_module'] = $filter_module;
            }else{
                $url_ext .= '/0';
            }

           if($filter_from != '' && $filter_from != '0'){
                $url_ext .= '/'. date('Y-m-d', strtotime($filter_from));
                $data['filter_from'] = date('F d, Y', strtotime($filter_from));
                $filter_data['filter_from'] = $filter_from;
            }else{
                $url_ext .= '/0';
            }
            if($filter_to != '' && $filter_to != '0'){
                $url_ext .= '/'. date('Y-m-d', strtotime($filter_to));
                $data['filter_to'] = date('F d, Y', strtotime($filter_to));
                $filter_data['filter_to'] = $filter_to;
            }else{
                $url_ext .= '/0';
            }
           
            $perpage = 10;
            $segment = 9;
            $offset = $this->uri->segment($segment);
            $base_url = base_url() . index_page() . 'admin/administrator/login_history_view/' . $id . $url_ext. '/index/';
            $total_rows = count($this->M_admin_action->find_by_admin_login($id, $filter_data));
            $this->pagination($perpage, $total_rows, $base_url, $segment);
            $data['admin_action'] = $this->M_admin_action->find_by_admin_login($id, $filter_data, $perpage, $offset);
            $data['admin_login_id'] = $id;

            //SAVE ADMIN ACTION LOG
            save_admin_action(array('module' => Constant::AM_SETTINGS, 'action' => Constant::AL_VIEW, 'title' => Constant::ALT_LOGIN_HISTORY));
        
            //parse template
            $this->parser->parse('admin/template', $data);
        } else {
            show_error('Invalid or no ID specified');
        }
    }

    function pagination($perpage, $total_rows, $base_url, $uri_segment = NULL) {
        /* PAGINATION SETTING */
        $config['base_url'] = $base_url;
        $config['total_rows'] = $total_rows;
        $config['per_page'] = $perpage;
        $config['uri_segment'] = 5;
        if($uri_segment != NULL){
            $config['uri_segment'] = $uri_segment;
        }
        $config['num_links'] = 5;
        //first and last links
        $config['first_link'] = '&laquo; First';
        $config['last_link'] = 'Last &raquo;';
        //first link tags
        $config['first_tag_open'] = '<li style="margin-right:20px;">';
        $config['first_tag_close'] = '</li>';
        //last link tags
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '<li>';
        //next link tags
        $config['next_link'] = 'Next &raquo;';
        $config['next_tag_open'] = '<li style="margin-right:20px;margin-left:10px;"">';
        $config['next_tag_close'] = '</li>';
        //previous link tags
        $config['prev_link'] = '&laquo; Previous';
        $config['prev_tag_open'] = '<li style="margin-right:10px;">';
        $config['prev_tag_close'] = '</li>';
        //current link tags
        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '</a></li>';
        //links tags
        $config['num_tag_open'] = '<li class="pages">';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
    }


}

/* End of file administrator.php */
/* Location: ./application/controllers/admin/administrator.php */