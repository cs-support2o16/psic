<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Inventory extends MY_Controller {

    // Holds values of form fields.
    protected $_form_data;

    public function __construct() {
        parent::__construct();
        $this->load->helper('cs_dropdown');
        $this->load->helper('cs_functions');
        $this->load->library('form_validation');
        $this->load->model('default/m_inventory', 'inventory');
        $this->load->model('default/M_inventory_category');
    }

    // --------------------------------------------------------------------

    /**
     * Default action, lists all inventory created.
     */
    function index() {
        $this->view_data['content'] = 'admin/inventory/list';

        $inventory = $this->inventory->fetch_latest_inventory_list();

        if ($inventory->num_rows() > 0) {
            $page = $this->uri->segment(4);

            $pagination['total_rows'] = $inventory->num_rows();

            $this->paginate($pagination);

            $results = $this->inventory->fetch_latest_inventory_list(10, $page);

            $this->view_data['inventory'] = $results->result();
        }

        $this->parser->parse('admin/template', $this->view_data);
    }

    // --------------------------------------------------------------------

    /**
     * View single inventory item.
     */
    function view($inventory_id = NULL) {
        $inventory = $this->inventory->get_by_id($inventory_id);
        $updated_by = $this->inventory->get_updated_by($inventory_id);

        if (is_null($inventory_id) || $inventory == FALSE) {
            redirect('admin/inventory/');
        }

        if (count($inventory) > 0) {
            $this->view_data['content'] = 'admin/inventory/view';

            $this->view_data['inventory'] = $inventory;
           if(count($updated_by) > 0){
             $this->view_data['updated_by'] = $updated_by;
           }
            $this->parser->parse('admin/template', $this->view_data);
        } else {
            redirect('admin/inventory/');
        }
    }

    /**
     * Add a single inventory item.
     */
    function add() {
        $this->view_data['content'] = 'admin/inventory/add';
 
        $this->_prep_form_values('inventory_add_form');

        if ($this->input->post('submit')) {

            $config = $this->config->item('inventory_add_form');

            $this->require_validation($config);
            #echo "<pre>"; print_r($this->_form_data); echo "</pre>";
            if ($this->form_validation->run()) {
                    if ($this->inventory->do_save($this->_form_data)) {
                        $this->session->set_flashdata('message', 'Property added!');

                        redirect('admin/inventory');
                    }
                
            }
        }

        $this->parser->parse('admin/template', $this->view_data);
    }

    // --------------------------------------------------------------------
    function scratch($inventory_id = NULL) {
        $inventory = $this->inventory->get_by_id($inventory_id);

        if (is_null($inventory_id) || count($inventory) < 1) {
            redirect('admin/inventory/');
        }
        $this->view_data['inventory'] = $inventory;

        $this->view_data['content'] = 'admin/inventory/scratch';

        $this->_form_data['inventory_id'] = $inventory_id;

        if ($this->input->post('submit-axn') == 'scratch' || $this->input->post('submit-axn') == 'publish') {

            $this->form_validation->set_rules('body', 'Body', 'required');
            $_post_form = array();
            if ($this->form_validation->run()) {

                if ($this->input->post('submit-axn') == 'scratch') {
                    $_post_form = array(
                        'inventory_id' => $_POST['inventory_id'],
                        'draft_body' => $_POST['body'],
                    );
                } else if ($this->input->post('submit-axn') == 'publish') {
                    $_post_form = array(
                        'inventory_id' => $_POST['inventory_id'],
                        'body' => $_POST['body'],
                        'draft_body' => '',
                    );
                }
                if (count($_post_form) > 0) {
                    if ($this->inventory->do_save($_post_form)) {
                        if ($this->input->post('submit-axn') == 'scratch') {
                            $this->session->set_flashdata('message', 'Draft saved!');
                        }
                        if ($this->input->post('submit-axn') == 'publish') {
                        $this->session->set_flashdata('message', 'Draft published!');
                        }
                        redirect('admin/inventory');
                    }
                }
            }
        }

        $this->parser->parse('admin/template', $this->view_data);
    }

    /**
     * Edit single inventory item.
     */
    function edit($inventory_id = NULL) {
        $inventory = $this->inventory->get_by_id($inventory_id);


        if (is_null($inventory_id) || count($inventory) < 1) {
            redirect('admin/inventory/');
        }
        $this->view_data['inventory'] = $inventory;


        $this->view_data['content'] = 'admin/inventory/edit';

        $this->_prep_form_values('inventory_edit_form');

        $this->_form_data['inventory_id'] = $inventory_id;

        if ($this->input->post('submit')) {

            $config = $this->config->item('inventory_edit_form');

            $this->require_validation($config);
            if ($this->form_validation->run()) {
                    $this->_form_data['inventory_id'] = $_POST['inventory_id'];

                  
                    if ($this->inventory->do_save($this->_form_data)) {
                        $this->session->set_flashdata('message', 'inventory item updated!');

                        redirect('admin/inventory');
                    
                }
            
        }
		}

        $this->parser->parse('admin/template', $this->view_data);
    }

    // --------------------------------------------------------------------
    function remove_archive($id) {
        if ($id != '') {
            $inventory = $this->inventory->get_by_id($id);
            if (count($inventory) > 0) {
                if ($this->inventory->update_status($id, 'archived', '0')) {
                    $this->session->set_flashdata('message', 'inventory successfully removed from archived.');
                } else {
                    $this->session->set_flashdata('message', 'Could not remove from archive. Please contact the administrator.');
                }
            }
        }
        redirect('admin/inventory');
    }

    function archive($id) {
        if ($id != '') {
            $inventory = $this->inventory->get_by_id($id);
            if (count($inventory) > 0) {
                if ($this->inventory->update_status($id, 'archived', '1')) {
                    $this->session->set_flashdata('message', 'inventory successfully archived.');
                } else {
                    $this->session->set_flashdata('message', 'Could not archive. Please contact the administrator.');
                }
            }
        }
        redirect('admin/inventory');
    }

    function unpublish($id) {
        if ($id != '') {
            $inventory = $this->inventory->get_by_id($id);
            if (count($inventory) > 0) {
                if ($this->inventory->update_status($id, 'published', '0')) {
                    $this->session->set_flashdata('message', 'inventory successfully unpublished.');
                } else {
                    $this->session->set_flashdata('message', 'Could not unpublish. Please contact the administrator.');
                }
            }
        }
        redirect('admin/inventory');
    }

    function publish($id) {
        if ($id != '') {
            $inventory = $this->inventory->get_by_id($id);
            if (count($inventory) > 0) {
                if ($this->inventory->update_status($id, 'published', '1')) {
                    $this->session->set_flashdata('message', 'inventory successfully published.');
                } else {
                    $this->session->set_flashdata('message', 'Could not publish. Please contact the administrator.');
                }
            }
        }
        redirect('admin/inventory');
    }

    // --------------------------------------------------------------------

    /**
     * Deletes a row/rows from the inventory table.
     *
     * @param mixed $id ID.
     */
    function delete($id = null) {
        if ($id != null) {
            if (is_array($id)) {
                if (count($id) > 0) {
                    foreach ($id as $item) {
                        $this->delete_item($item);
                    }
                } else {
                    $this->session->set_flashdata('error_message', '<p class="red bold">No inventory selected.</p>');
                }
            } else {
                $this->delete_item($id);
            }
        } else {
            $this->session->set_flashdata('error_message', '<p class="red bold">No inventory selected.</p>');
        }
        redirect('admin/inventory/');
    }

    function delete_item($id) {
        if ($id != '') {
            $inventory = $this->inventory->get_by_id($id);
            if (count($inventory) > 0) {
                if ($this->inventory->delete($id)) {

                    $this->session->set_flashdata('message', 'inventory successfully deleted.');
                } else {
                    $this->session->set_flashdata('message', 'Could not delete the inventory item. Please contact the administrator.');
                }
            }
        } else {
            $this->session->set_flashdata('error_message', '<p class="red bold">No inventory selected.</p>');
        }
    }

    // --------------------------------------------------------------------

    /**
     * Control action for bulk selections.
     */
    function action() {
        $data = $this->input->post('data');

        $action = $this->input->post('selectAction');

        if (trim($action) == '') {
            $action = 'index';
        }
        $this->$action($data);
    }

    //Category

    function add_category() {
        //set page data
        $data['title'] = 'Add inventory Category';
        $data['content'] = 'admin/inventory/category/add';
        $data['sitename'] = $this->M_website->getName();
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function edit_category($id) {
        //set page data
        $data['category'] = $this->M_inventory_category->get($id);
        $data['title'] = 'Edit inventory Category';
        $data['content'] = 'admin/inventory/category/edit';
        $data['sitename'] = $this->M_website->getName();
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function category($offset = 0) {
        //set pagination
        $pagination_config = array(
            'perpage' => 10,
            'base_url' => base_url() . index_page() . 'admin/inventory/category/',
            'count' => $this->M_inventory_category->get_count()
        );
        $this->paginate($pagination_config);
        //set page data
        $data['categories'] = $this->M_inventory_category->get_all($pagination_config['perpage'], $offset);
        $data['title'] = 'inventory Category';
        $data['content'] = 'admin/inventory/category/list';
        $data['sitename'] = $this->M_website->getName();

        //for actions message
        $data['action'] = $this->session->flashdata('action');
        $data['saved'] = $this->session->flashdata('saved');
        $data['deleted'] = $this->session->flashdata('deleted');
        $data['no_selected'] = $this->session->flashdata('noSelected');
        $data['actions_failed'] = $this->session->flashdata('actionsFailed');
        $data['actions_success'] = $this->session->flashdata('actionsSuccess');

        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function category_save() {
        $this->form_validation->set_rules('title', 'Prefix', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        $this->form_validation->set_rules('depreciation', 'Depreciation', '');

        if ($this->form_validation->run() == FALSE) {
            //set page data
            $data['title'] = 'Add inventory Category';
            $data['content'] = 'admin/inventory/category/add';
            $data['sitename'] = $this->M_website->getName();
            //parse template
            $this->parser->parse('admin/template', $data);
        } else {
               if($this->input->post('depreciation')==''){
                   $_POST['depreciation'] = '10';
               }
            if ($this->M_inventory_category->do_save($_POST)) {
                $this->session->set_flashdata('saved', TRUE);
                redirect('admin/inventory/category');
            }
        }
    }

    function category_update($id) {
        $this->form_validation->set_rules('title', 'Prefix', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        $this->form_validation->set_rules('depreciation', 'Depreciation', '');

        if ($this->form_validation->run() == FALSE) {
            //set page data
            $data['category'] = $this->M_inventory_category->get($id);
            $data['title'] = 'Edit inventory Category';
            $data['content'] = 'admin/inventory/category/edit';
            $data['sitename'] = $this->M_website->getName();
            //parse template
            $this->parser->parse('admin/template', $data);
        } else {
            if ($this->M_inventory_category->do_save($_POST)) {
                $this->session->set_flashdata('saved', TRUE);
                redirect('admin/inventory/category');
            }
        }
    }

    function category_delete($id) {
        if ($this->M_inventory_category->delete($id)) {
            $this->session->set_flashdata('deleted', TRUE);
            redirect('admin/inventory/category');
        }
    }

    function category_action() {
        $uri_4 = $this->input->post('uri_4');
        $failCtr = 0;
        $successCtr = 0;
        if (!$this->input->post('categories')) {
            $this->session->set_flashdata('noSelected', TRUE);
        } else {
            switch ($this->input->post('selectAction')) {
                case 'delete':
                    //DELETE
                    $this->session->set_flashdata('action', 'deleted');
                    foreach ($this->input->post('categories') as $row) {

                        if (!$this->M_inventory_category->delete($row)) {
                            $failCtr++;
                            $this->session->set_flashdata('actionsFailed', $failCtr);
                        } else {
                            $successCtr++;
                            $this->session->set_flashdata('actionsSuccess', $successCtr);
                        }
                    }
                    break;
            }
        }
        redirect('admin/inventory/category/' . $uri_4);
    }

    function checkpno_o($p_number_old){
    $pn = $this->input->post('pn');
 
    $old = $this->input->post('p_number_old');

        if ($pn == 'Old' && $old == '') {
            $this->form_validation->set_message('checkpno_o', 'Property Number is required.');
            return FALSE;
        }else {
            return TRUE;
        }
    }

    function checkpno_n($p_number_old){
    $pn = $this->input->post('pn');
 
    $m = $this->input->post('p_month');
    $y = $this->input->post('p_year');
    $p = $this->input->post('inventory_category_id');
    $n = $this->input->post('p_number');

        if ($pn == 'New' && $m == '' || $y == '' || $p == '' || $n == ''){
            $this->form_validation->set_message('checkpno_n', 'Property Number is required.');
            return FALSE;
        }elseif ($n != '' && $this->uri->segment(3)!='edit'){
            $result = $this->inventory->checkpn($this->input->post('p_number'));
            if (count($result)) {
            $this->form_validation->set_message('checkpno_n', 'Numeric number in XXXX field exists.');
            return FALSE;
            }
        }else {
            return TRUE;
        }
    }

}

/* End of file inventory.php */
    /* Location: ./application/controllers/admin/inventory.php */
    