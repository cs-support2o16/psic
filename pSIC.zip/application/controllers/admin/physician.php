<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Physician extends MY_Controller {

    function __construct() {
        parent::__construct();
        if (!$this->session->userdata('logged_in'))
            redirect('admin/login');
        $this->load->library('form_validation');
        $this->load->library('pagination');
        $this->load->helper('text');
        $this->load->library('email');
        $this->load->helper('cs_dropdown');
        $this->load->helper('security');
        $this->load->helper('csv');
        $this->load->helper('form');
        $this->load->model('default/M_physician');
        $this->load->model('admin/M_website');
        $this->load->model('admin/M_administrator');
        $this->load->model('admin/M_transactional_emails');
        $this->load->model('default/m_settings');
        $this->load->model('default/M_user');

    }

    function index($offset = 0) {
        //set pagination
        $pagination_config = array(
            'perpage' => 10,
            'base_url' => base_url() . index_page() . 'admin/physician/index/',
            'count' => $this->M_physician->get_count()
        );
        $this->pagination($pagination_config);
        //set page data
        $data['physician'] = $this->M_physician->get_all($pagination_config['perpage'], $offset);
        $data['title'] = 'Physician';
        $data['content'] = 'admin/physician/list';
        $data['sitename'] = $this->M_website->getName();

        //for actions messages
        $data['saved'] = $this->session->flashdata('saved');

        //parse template
        $this->parser->parse('admin/template', $data);
    }
    
    function add() {

            
            //validate form
            $this->_prep_form_values('validation_physician_add_form');
            if ($this->input->post('submit')) {

                // Load fields from config.
                $this->load->config('validations');
                $config = $this->config->item('validation_physician_add_form');

                $this->require_validation($config);

                if ($this->form_validation->run())
                {
                    $_SESSION['saved'] = TRUE;
                    if($this->M_physician->saveAdmin($_POST)){
                    	
                    	if(isset($_POST['patients'])){
	                        foreach ($_POST['patients'] as $item){
	                            $result = $this->M_physician->findRecord($_POST);
	                            $this->M_user->updatePhysician($result['physician_id'], $item);
	                            
	                        }
                        }
                        $this->session->set_flashdata('message', 'Physician details has been saved.');
                        redirect('admin/physician/');
                    }
                }
            }

            //set page data
            $data['title'] = 'Add Physician';
            $data['content'] = 'admin/physician/add';
            $data['sitename'] = $this->M_website->getName();
            
            // user list
            $data['patients'] = $this->M_user->fetch_all();
            

            //for actions messages
            $data['saved'] = $this->session->flashdata('saved');


            //parse template
            $this->parser->parse('admin/template', $data);
       
    }

    // --------------------------------------------------------------------

    /**
     * Set email settings on this page.
     *
     */
    function settings()
    {
        $physician_email_recipient = $this->get_setting('physician_email_recipient')->setting_value;
        // Email content.
        $physician_patient_confirmation = $this->get_setting('physician_patient_confirmation')->setting_value;
        $physician_admin_notification   = $this->get_setting('physician_admin_notification')->setting_value;
        // Email Subject.
        $physician_patient_confirmation_subject = $this->get_setting('physician_patient_confirmation_subject');
        $physician_admin_notification_subject   = $this->get_setting('physician_admin_notification_subject')->setting_value;

        $data['physician_email_recipient'] = set_value('physician_email_recipient', $physician_email_recipient);

        $data['physician_patient_confirmation'] = set_value('physician_patient_confirmation', $physician_patient_confirmation);
        $data['physician_admin_notification'] = set_value('physician_admin_notification', $physician_admin_notification);

        $data['physician_admin_notification_subject'] = set_value('physician_admin_notification_subject', $physician_admin_notification_subject);
        $data['physician_patient_confirmation_subject'] = set_value('physician_patient_confirmation_subject', $physician_patient_confirmation_subject);

        $this->require_validation();

        $this->form_validation->set_rules('physician_email_recipient', 'Email Recipient', 'required');
        $this->form_validation->set_rules('physician_patient_confirmation', 'Patient Email', 'required');
        $this->form_validation->set_rules('physician_patient_confirmation_subject', 'Patient email subject', 'required');
        $this->form_validation->set_rules('physician_admin_notification', 'Admin email', 'required');
        $this->form_validation->set_rules('physician_admin_notification_subject', 'Admin email subject',  'required');

        if ($this->input->post('submit') == 'Save' || $this->isAjax())
        {
            if ($this->form_validation->run() && $this->m_settings->save_settings($_POST))
            {
                if ($this->isAjax())
                {
                    echo "1";
                    exit();
                }
                
                $this->session->set_flashdata('message', 'Settings saved!');

                redirect ('admin/physician/settings');
            }
        }
        
        $this->view_data['content'] = 'admin/physician/settings';
        //parse template
        $this->view_data = array_merge($this->view_data, $data);

        $this->parser->parse('admin/template', $this->view_data);
    }

    // --------------------------------------------------------------------
    

    function pagination($pagination_config) {
        /* PAGINATION SETTING */
        $config['base_url'] = $pagination_config['base_url'];
        $config['total_rows'] = $pagination_config['count'];
        $config['per_page'] = $pagination_config['perpage'];
        $config['uri_segment'] = 4;
        $config['num_links'] = 4;
        //first and last links
        $config['first_link'] = '&laquo; First';
        $config['last_link'] = 'Last &raquo;';
        //first link tags
        $config['first_tag_open'] = '<li style="margin-right:20px;">';
        $config['first_tag_close'] = '</li>';
        //last link tags
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '<li>';
        //next link tags
        $config['next_link'] = 'Next &raquo;';
        $config['next_tag_open'] = '<li style="margin-right:20px;margin-left:10px;"">';
        $config['next_tag_close'] = '</li>';
        //previous link tags
        $config['prev_link'] = '&laquo; Previous';
        $config['prev_tag_open'] = '<li style="margin-right:10px;">';
        $config['prev_tag_close'] = '</li>';
        //current link tags
        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '</a></li>';
        //links tags
        $config['num_tag_open'] = '<li class="pages">';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
    }

    function reset_password() {

        $id = $this->input->post('physician_id');
        $password = $this->input->post('password');
        if ($id != '' || $password != '' ) {

            if ($this->M_physician->resetPassword($id, do_hash($password))) {
                echo 'valid';
            }
        } else {
           echo 'invalid';
        }
    }

    function view($id = null) {

        if ($id != null) {
            
            $physician = $this->M_physician->get($id);

            //set page data
            $data['title'] = 'Physician Detail';
            $data['content'] = 'admin/physician/view';
            $data['sitename'] = $this->M_website->getName();

            $this->load->model('default/M_physician');
            $data['physician'] = $physician;
            
            // user list
            $this->load->model('default/M_user');
            $data['patients'] = $this->M_user->fetch_all();

            //parse template
            $this->parser->parse('admin/template', $data);
        } else {
            show_error('Invalid or no ID specified');
        }
    }
    
    function edit($id = null) {

        if ($id != null) {
            
            $physician = $this->M_physician->get($id);
            //validate form
            $this->_prep_form_values('validation_physician_edit_form');
            if ($this->input->post('submit')) {

                // Load fields from config.
                $this->load->config('validations');
                $config = $this->config->item('validation_physician_edit_form');

                $this->require_validation($config);

                if ($this->form_validation->run())
                {
                    $_SESSION['saved'] = TRUE;
                    if($this->M_physician->updateAdmin($_POST, $id)){
                        
                        //delete previous patients
                        $patients= $this->M_user->fetch_all();
                        foreach($patients as $row){
                            if($row['physician_id'] != ''){
                                $physician_List = explode(",", $row['physician_id']);
                                if(in_array($id, $physician_List)){
                                    $this->M_user->updatePhysician(str_replace($id, '', $row['physician_id']), $row['user_id']);
                                }
                            }
                        }
                        
                        if(isset($_POST['patients'])){
                            foreach ($_POST['patients'] as $item){
                                    $this->M_user->updatePhysician($id, $item);
                            }
                        }
                    }
                        
                    $this->session->set_flashdata('message', 'Physician account details has been updated.');
                    redirect('admin/physician/edit/' . $id);
                    
                }
            }

            //set page data
            $data['title'] = 'Physician Detail';
            $data['content'] = 'admin/physician/edit';
            $data['sitename'] = $this->M_website->getName();

            //for actions messages
            $data['saved'] = $this->session->flashdata('saved');

            $this->load->model('default/M_physician');
            $data['physician'] = $physician;
            
            // user list
            $this->load->model('default/M_user');
            $data['patients'] = $this->M_user->fetch_all();

            //parse template
            $this->parser->parse('admin/template', $data);
        } else {
            show_error('Invalid or no ID specified');
        }
    }

    function export() {
        $website = $this->M_website->getName();
        $query = $this->db->get_where('physician', array('physician_id !=' => '1'), $limit = null, $offset = null);
        query_to_csv($query, TRUE, $website . 'Physician.csv');
    }
    
     // --------------------------------------------------------------------

    /**
     * Deletes a row/rows from the news table.
     *
     * @param mixed $id ID.
     */
    function delete($id)
    {
        if ($this->M_physician->delete($id))
        {
            $this->session->set_flashdata('message', 'Physician successfully deleted.');
        }
        else
        {
            $this->session->set_flashdata('message', 'Could not delete the physician item. Please contact the administrator.');
        }

        redirect('admin/physician/');
    }
    
    // --------------------------------------------------------------------
    
    /**
     * Control action for bulk selections.
     */
    function action()
    {
        $data = $this->input->post('data');

        $action = $this->input->post('selectAction');

	if (trim($action) == '')
	{
		$action = 'index';
	}

        $this->$action($data);
    }   
    
    // --------------------------------------------------------------------
    
    function post_to_uri($value = null)
    {
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('search', 'Search', 'trim|xss_clean|urlencode');

        if ($this->form_validation->run())
        {
            $query_string = set_value('search');
            redirect (site_url('admin/physician/search/' . $query_string));
        }
        else
        {
            show_error('Nice try! Your IP has been logged and we are notifying proper authorities');
        }
    }

     // --------------------------------------------------------------------
    
    function search($value = '', $offset = 0)
    {
        // Decode uri encoded string.
        $value = urldecode($value);

        //set page data
        $physicians = $this->M_physician->search(array('firstname', 'lastname', 'username', 'email'), $value);
        //set pagination
        $perpage = 10;
         //set pagination
        $pagination_config = array(
            'perpage' => 10,
            'base_url' =>  site_url('admin/physician/search/' . $value . '/'),
            'count' => $physicians->num_rows(),
            'uri_segment' => 5
        );
        $this->pagination($pagination_config);
        $physicians = $this->M_physician->search(array('firstname', 'lastname', 'username', 'email'), $value, $perpage, $offset)->result();

        $physicianList = array();
        foreach ($physicians as $physician)
        {
            $physicianList[] = (array) $physician;
        }

        $data['physician'] = $physicianList;
        $data['title'] = 'Physician';
        $data['content'] = 'admin/physician/list';
        $data['sitename'] = $this->M_website->getName();
         //parse template
        $this->parser->parse('admin/template', $data);
    }
    
   

}

/* End of file physician.php */
/* Location: ./application/controllers/admin/physician.php */