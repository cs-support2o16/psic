<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Seo extends MY_Controller {

    function __construct() {
        parent::__construct();
        if (!$this->session->userdata('logged_in'))
            redirect('admin/login');
        $this->load->library('form_validation');
        $this->load->helper('cs_functions');
        $this->load->library('pagination');
        $this->load->model('admin/M_website');
        $this->load->model('default/M_redirect');
        $this->load->helper('cs_dropdown');
    }

    function index() {
        //set page data
        $data['title'] = 'SEO';
        $data['content'] = 'admin/seo/form';
        $data['sitename'] = $this->M_website->getName();
        $data['website'] = $this->M_website->getWebsite();
        $data['saved'] = $this->session->flashdata('saved');
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function robots() {
        //set page data
        $data['title'] = 'SEO';
        $data['content'] = 'admin/seo/robots';
        $data['sitename'] = $this->M_website->getName();
        $data['website'] = $this->M_website->getWebsite();
        //parse template

        if ($this->input->post('submit')) {
            if (isset($uploaded_file['error'])) {
                $data['file_error'] = $uploaded_file['error'];
            }
            //$this->robot_upload();

            if ($this->robot_upload()) {
                 //SAVE ADMIN ACTION LOG
                save_admin_action(array('module' => Constant::AM_SEO, 'action' => Constant::ALT_UPLOAD, 'title' => Constant::ALT_SEO_ROBOTS));

                $this->session->set_flashdata('saved', TRUE);
                $data['saved'] = $this->session->flashdata('saved');
            }
        }
        $this->parser->parse('admin/template', $data);
    }

    function seo_uploads() {
        //set page data
        $data['title'] = 'SEO';
        $data['content'] = 'admin/seo/seo_uploads';
        $data['sitename'] = $this->M_website->getName();
        $data['website'] = $this->M_website->getWebsite();
        //parse template
        $this->form_validation->set_rules('file', 'File', 'trim|xss_clean');

        if ($this->input->post('submit')) {
            if (($_FILES && $_FILES['file']['name'] !== "")) {
                $uploaded_file = $this->seo_upload_data();
                if (!isset($uploaded_file['error'])) {
                     //SAVE ADMIN ACTION LOG
                    save_admin_action(array('module' => Constant::AM_SEO, 'action' => Constant::ALT_UPLOAD, 'title' => Constant::ALT_SEO_UPLOADS));
                    $data['saved'] = 'Successfully uploaded!';
                }
            } else {
                $data['title'] = 'SEO';
                $data['content'] = 'admin/seo/seo_uploads';
                $data['sitename'] = $this->M_website->getName();
                $data['website'] = $this->M_website->getWebsite();
                $data['saved'] = 'You did not select any file.';
            }

            if (isset($uploaded_file['error'])) {
                $data['file_error'] = $uploaded_file['error'];
            }
        }

        $this->parser->parse('admin/template', $data);
    }

    function robot_upload() {

        $config['upload_path'] = str_replace('system/', '', BASEPATH) . '/';
        $config['allowed_types'] = 'txt';
        $config['overwrite'] = TRUE;
        $this->load->library('upload', $config);

        // $this->upload->overwrite = true;

        if (!$this->upload->do_upload('file')) {
            $file = array('error' => $this->upload->display_errors('<div class="red">', '</div>'));
            $this->session->set_flashdata('file_error', TRUE);
        } else {
            $file = array('data' => $this->upload->data());
        }
        return $file;
    }

    function seo_upload_data() {

        $config['upload_path'] = str_replace('system/', '', BASEPATH) . '/';
        $config['allowed_types'] = '*';
        $config['overwrite'] = TRUE;
        $this->load->library('upload', $config);

        // $this->upload->overwrite = true;
        if ($_FILES && $_FILES['file']['name'] !== "") {
            if (!$this->upload->do_upload('file')) {
                $file = array('error' => $this->upload->display_errors('<div class="red">', '</div>'));
                $this->session->set_flashdata('file_error', TRUE);
            } else {
                $file = array('data' => $this->upload->data());
                $this->session->set_flashdata('saved', TRUE);
            }
            return $file;
        } else {
            $this->session->set_flashdata('saved', FALSE);
        }
    }

    function save() {
        $this->form_validation->set_rules('sitename', 'Site Title', 'required');
        $this->form_validation->set_rules('default_metakeywords', 'Global Meta Keywords', 'required');
        $this->form_validation->set_rules('default_metadesc', 'Global Meta Description', 'required');
        $this->form_validation->set_rules('meta_robots', 'Meta Robots', 'required');
        if ($this->form_validation->run()) {
            if ($this->M_website->updateSeo($_POST)) {
                 //SAVE ADMIN ACTION LOG
                save_admin_action(array('module' => Constant::AM_SEO, 'action' => Constant::AL_EDIT, 'title' => Constant::ALT_SEO));

                $this->session->set_flashdata('saved', TRUE);
                //redirect page
                redirect('admin/seo');
            }
        } else {
            //set page data
            $data['title'] = 'SEO';
            $data['content'] = 'admin/seo/form';
            $data['sitename'] = $this->M_website->getName();
            $data['website'] = $this->M_website->getWebsite();
            $data['saved'] = $this->session->flashdata('saved');
            //parse template
            $this->parser->parse('admin/template', $data);
        }
    }

    function google_analytics() {

        //set page data
        $data['title'] = 'SEO';
        $data['content'] = 'admin/seo/ga';
        $data['sitename'] = $this->M_website->getName();
        $data['website'] = $this->M_website->getWebsite();
        //parse template

        $this->form_validation->set_rules('google_analytics', 'Google Analytics', 'required|xss_clean');
        $this->form_validation->set_rules('ga_position', 'Where to insert code', 'required|xss_clean');
        if ($this->form_validation->run()) {

            if ($this->M_website->updateGA($_POST)) {
                //SAVE ADMIN ACTION LOG
                save_admin_action(array('module' => Constant::AM_SEO, 'action' => Constant::AL_EDIT, 'title' => Constant::ALT_SEO_GA));

                $this->session->set_flashdata('saved', TRUE);
                //redirect page
                redirect('admin/seo/google_analytics');
            }
        } else {
            //set page data
            $data['title'] = 'SEO';
            $data['content'] = 'admin/seo/ga';
            $data['sitename'] = $this->M_website->getName();
            $data['website'] = $this->M_website->getWebsite();
            $data['saved'] = $this->session->flashdata('saved');
            //parse template
            $this->parser->parse('admin/template', $data);
        }
    }

    function advanced() {
        $this->load->helper('cs_functions');

        $data['sitename'] = $this->M_website->getName();
        $data['website'] = $this->M_website->getWebsite();
        $data['title'] = 'Advanced Site Statistics';
        $data['content'] = 'admin/seo/advanced';

        $data['url'] = '';
        if ($this->session->userdata('super_admin')) {
            if ($this->get_setting('seo_enable_advanced')->setting_value == 1) {
                $data['hash'] = base64_encode(date('Ymd') . 'MahalNaAraw');
                $data['url'] = base_url() . 'webstat/index.php?hash=' . $data['hash'];
            }
        }

        $this->parser->parse('admin/template', $data);
    }


    //Redirect
    function redirect($offset = 0) {
        //set pagination
        $pagination_config = array(
            'perpage' => 10,
            'base_url' => base_url() . index_page() . 'admin/seo/redirect/',
            'count' => $this->M_redirect->fetch_all()->num_rows()
        );
        $this->pagination($pagination_config);
        //set page data
        $data['redirects'] = $this->M_redirect->fetch_all($pagination_config['perpage'], $offset)->result();
        $data['title'] = '301 Redirects';
        $data['content'] = 'admin/seo/redirect/list';
        $data['sitename'] = $this->M_website->getName();

        //for actions messages
        $data['saved'] = $this->session->flashdata('saved');

        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function add_redirect() {
        //set page data
        $data['title'] = 'Add 301 Redirect';
        $data['content'] = 'admin/seo/redirect/add';
        $data['sitename'] = $this->M_website->getName();
        if ($this->input->post('submit')) {
            $this->form_validation->set_rules('directory', 'Directory', 'required');
            $this->form_validation->set_rules('redirect_url', 'Redirect URL', 'required');
            if ($this->form_validation->run()) {
                unset($_POST['submit']);
                if ($this->M_redirect->do_save($_POST)) {
                    $this->session->set_flashdata('message', '301 Redirect has been saved.');
                    redirect('admin/seo/redirect');
                }
            }
        }
        //parse template
        $this->parser->parse('admin/template', $data);
    }

    function edit_redirect($id = null) {

        if ($id != null) {
            //set page data
            $data['title'] = 'Edit 301 Redirect';
            $data['content'] = 'admin/seo/redirect/edit';
            $data['sitename'] = $this->M_website->getName();
            $redirect = $this->M_redirect->find_by_id($id);
            if (count($redirect) > 0) {
                $data['redirect'] = $redirect;
                //for actions messages
                $data['saved'] = $this->session->flashdata('saved');

                //validate form
                if ($this->input->post('submit')) {

                    // Load fields from config.
                    $this->load->config('validations');
                    $this->form_validation->set_rules('directory', 'Directory', 'required');
                    $this->form_validation->set_rules('redirect_url', 'Redirect URL', 'required');

                    if ($this->form_validation->run()) {
                        $_form_data['redirect_id'] = $this->input->post('redirect_id');
                        $_form_data['directory'] = $this->input->post('directory');
                        $_form_data['redirect_url'] = $this->input->post('redirect_url');
                        if ($this->M_redirect->do_save($_form_data)) {

                            $this->session->set_flashdata('message', '301 Redirect has been updated.');
                            redirect('admin/seo/redirect');
                        }
                    }
                }


                //parse template
                $this->parser->parse('admin/template', $data);
            }
        }
    }

    function delete_redirect($id) {
        $redirect = $this->M_redirect->find_by_id($id);
        if (count($redirect)) {
            if ($this->M_redirect->delete($redirect['redirect_id'])) {
                $this->session->set_flashdata('message', '301 Redirect successfully deleted.');
                redirect('admin/seo/redirect');
            }
        }
    }

    function redirect_action() {
        $uri_4 = $this->input->post('uri_4');
        $failCtr = 0;
        $successCtr = 0;
        if (!$this->input->post('items')) {
            $this->session->set_flashdata('no_selected', 'No item(s) selected.');
        } else {
            switch ($this->input->post('selectAction')) {
                case 'delete_redirect':
                    //DELETE
                    $this->session->set_flashdata('action', 'deleted');
                    $deleted = array();
                    $deleted_array = $this->M_redirect->find_deleted_items($this->input->post('items'));
                    foreach ($this->input->post('items') as $row) {

                        if (!$this->M_redirect->delete($row)) {
                            $failCtr++;
                        } else {
                            $deleted[] = $row;
                            if (!array_key_exists($row, $deleted_array)) {
                                unset($deleted_array[$row]);
                            }
                            $successCtr++;
                        }
                    }
                    $deleted_list = '';
                    $deleted_ids_list = '';
                    if (count($deleted_array) > 0) {
                        $deleted_list = implode(",", $deleted_array);
                        $deleted_list = rtrim($deleted_list, ',');
                        $deleted_ids_list = implode(",", $deleted);
                        $deleted_ids_list = rtrim($deleted_ids_list, ',');
                    }
                    //SAVE ADMIN ACTION LOG
                    save_admin_action(array('module' => Constant::AM_SEO, 'action' => Constant::AL_DELETE_ALL . ' 301 Redirects', 'title' => $deleted_list, 'object_ids' => $deleted_ids_list));

                    break;
            }

            if ($failCtr > 0) {
                $this->session->set_flashdata('actions_failed', $failCtr . ' item(s) failed to delete.');
            }
            if ($successCtr > 0) {
                $this->session->set_flashdata('actions_success', $successCtr . ' item(s) successfully deleted.');
            }
        }
        redirect('admin/seo/redirect/' . $uri_4);
    }

    function pagination($pagination_config) {
        /* PAGINATION SETTING */
        $config['base_url'] = $pagination_config['base_url'];
        $config['total_rows'] = $pagination_config['count'];
        $config['per_page'] = $pagination_config['perpage'];
        $config['uri_segment'] = (isset($pagination_config['uri_segment'])) ? $pagination_config['uri_segment'] : 4;
        $config['num_links'] = 4;
        //first and last links
        $config['first_link'] = '&laquo; First';
        $config['last_link'] = 'Last &raquo;';
        //first link tags
        $config['first_tag_open'] = '<li style="margin-right:20px;">';
        $config['first_tag_close'] = '</li>';
        //last link tags
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '<li>';
        //next link tags
        $config['next_link'] = 'Next &raquo;';
        $config['next_tag_open'] = '<li style="margin-right:20px;margin-left:10px;"">';
        $config['next_tag_close'] = '</li>';
        //previous link tags
        $config['prev_link'] = '&laquo; Previous';
        $config['prev_tag_open'] = '<li style="margin-right:10px;">';
        $config['prev_tag_close'] = '</li>';
        //current link tags
        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '</a></li>';
        //links tags
        $config['num_tag_open'] = '<li class="pages">';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
    }


}

/* End of file faq.php */
/* Location: ./application/controllers/admin/seo.php */