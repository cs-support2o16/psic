<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class product_catalog extends CI_Controller {

	function __construct(){
		parent::__construct();
		if(!$this->session->userdata('logged_in')) redirect('admin/login');
		$this->load->library('form_validation');
		$this->load->library('pagination');
		
		$this->load->model('admin/M_website');
		$this->load->model('admin/M_page');
		$this->load->model('default/M_product_catalog');
	}
	
	function index($offset = 0){ 
		//set pagination
		$pagination_config = array(
			'perpage' => 10,
			'base_url' => base_url().index_page().'admin/product_catalog/index/',
			'count' => $this->M_download->get_count()
		);
		$this->pagination($pagination_config);
		//set page data
		$data['product_catalog'] = $this->M_product_catalog->get_all($pagination_config['perpage'], $offset);
		$data['title'] = 'Product Catalog';
		$data['content'] = 'admin/product_catalog/list';
		$data['sitename'] = $this->M_website->getName();
		
		//for actions messages
		$data['action'] = $this->session->flashdata('action');
		$data['saved'] = $this->session->flashdata('saved');
		$data['deleted'] = $this->session->flashdata('deleted');
		$data['no_selected'] = $this->session->flashdata('noSelected');
		$data['actions_failed'] = $this->session->flashdata('actionsFailed'); 
		$data['actions_success'] = $this->session->flashdata('actionsSuccess');
		
		//parse template
		$this->parser->parse('admin/template', $data);
	}
	
	function add(){
		//set page data
		$data['title'] = 'Product Catalog';
		$data['content'] = 'admin/product_catalog/add';
		$data['sitename'] = $this->M_website->getName();
		$data['pages'] = $this->M_page->get_all();	
		$data['categories'] = $this->M_product_catalog->get_categories();	
		//parse template
		$this->parser->parse('admin/template', $data);
	}
	
	function edit($id){

		//set page data
		$data['download'] 		= $this->M_product_catalog->get($id);
		$data['title'] 			= 'Edit Product Catalog';
		$data['content'] 		= 'admin/product_catalog/edit';
		$data['sitename'] 		= $this->M_website->getName();
		$data['pages'] 			= $this->M_page->get_all();
		$data['categories'] 	= $this->M_product_catalog->get_categories();		
		
		$data['subcategories'] 	= $this->M_product_catalog->get_sub_spec_categories($data['download']['p_category']);	

		#$data['page_location'] = $this->M_download_page_loc->getByDownloads($id);		

		//parse template
		$this->parser->parse('admin/template', $data);
	}
	
	function update($id)
	{		
		$this->form_validation->set_rules('p_number', 'Number', 'required');
		$this->form_validation->set_rules('p_title', 'Title','required');
		$this->form_validation->set_rules('p_description', 'Description','required');
		$this->form_validation->set_rules('p_price', 'Price','required');
		$this->form_validation->set_rules('p_category', 'Category','required');			
		$this->form_validation->set_rules('p_subcategory', 'Sub Category','required');	
		$this->form_validation->set_rules('p_image', 'Image');

		if ($this->form_validation->run() == FALSE){			
			//set page data			
			//parse template
			$data['download'] 		= $this->M_product_catalog->get($id);
			$data['title'] 			= 'Edit Product';
			$data['content'] 		= 'admin/product_catalog/edit';
			$data['sitename'] 		= $this->M_website->getName();
			$data['pages'] 			= $this->M_page->get_all();	
			$data['page_locations'] = $this->input->post('page_location');
			$data['subcategories'] 	= $this->M_product_catalog->get_sub_spec_categories($data['download']['p_category']);
			$data['categories'] 	= $this->M_product_catalog->get_categories();
			$this->parser->parse('admin/template', $data);
		}else{										
				if(!isset($_POST['p_image']))
				{
	                $target_path1 = "./uploads/product_catalog/";
	                $target_path1 = $target_path1 . basename($_FILES['p_image']['name']);                

	                if(move_uploaded_file($_FILES['p_image']['tmp_name'], $target_path1)) {
	                     basename( $_FILES['p_image']['name']);                                                        
	                }  
					$_POST['p_image'] = $_FILES['p_image']['name'];
            	}else{
            		$_POST['p_image'] = $_POST['txtoriginal'];
            	}
                
                $_POST['p_image'] = ($_POST['p_image']=="")? $_POST['txtoriginal'] : $_POST['p_image'];
            	
            	#echo $_POST['p_image'];



				if($this->M_product_catalog->update($_POST)){
					$this->session->set_flashdata('saved', TRUE);
					redirect('admin/product_catalog');
				}
				
		}
	}
	
	function save(){ 
		$this->form_validation->set_rules('p_number', 'Number', 'required');
		$this->form_validation->set_rules('p_title', 'Title','required');
		$this->form_validation->set_rules('p_description', 'Description','required');
		$this->form_validation->set_rules('p_price', 'Price','required');
		$this->form_validation->set_rules('p_category', 'Category','required');
		$this->form_validation->set_rules('p_subcategory', 'Sub Category','required');
		$this->form_validation->set_rules('p_image', 'Image');

		if ($this->form_validation->run() == FALSE){
			//set page data			
			//parse template
			$data['title'] 			= 'Add Product';
			$data['content'] 		= 'admin/product_catalog/add';
			$data['sitename'] 		= $this->M_website->getName();
			$data['pages'] 			= $this->M_page->get_all();	
			$data['page_locations'] = $this->input->post('page_location');
			$data['categories'] 	= $this->M_product_catalog->get_categories();
			$this->parser->parse('admin/template', $data);
		}else{				

                $target_path1 = "./uploads/product_catalog/";
                $target_path1 = $target_path1 . basename($_FILES['p_image']['name']);                

                if(move_uploaded_file($_FILES['p_image']['tmp_name'], $target_path1)) {
                     basename( $_FILES['p_image']['name']);                                                        
                }  

                $_POST['p_image'] = $_FILES['p_image']['name'];

				if($this->M_product_catalog->insert($_POST)){
					$this->session->set_flashdata('saved', TRUE);
					redirect('admin/product_catalog');
				}
				
		}
	}
	
	function set_page_data($page = NULL){
		$data['title'] = $page['title'];
		$data['content'] = $page['content'];
		$data['sitename'] = $this->M_website->getName();
		$data['pages'] = $this->M_page->get_all();
		$data['file_error'] = (isset($page['file_error']))?$page['file_error']:'';
		$data['page_location'] = (isset($page['page_locations']))?$page['page_locations']:'';
		$data['download'] = (isset($page['download']))?$page['download']:'';
		return $data;
	}
	
	function upload_file(){
		$config['upload_path'] = str_replace('system/','',BASEPATH).'uploads/product_catalog/';
		$config['allowed_types'] = 'gif|jpg|png';

		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload('download_file')){
			$file = array('error' => $this->upload->display_errors('<div class="red">','</div>'));
		}
		else{
			$file = array('data' => $this->upload->data());
		}
		return $file;
	}
	
	function action(){
		$uri_4 = $this->input->post('uri_4');
		$failCtr = 0;
		$successCtr = 0;	

		#echo "<pre>"; print_r($this->input->post('product_catalog')); echo "</pre>";

		if(!$this->input->post('product_catalog')){
			$this->session->set_flashdata('noSelected', TRUE);
		}else{

			switch($this->input->post('selectAction')){
				case 'delete':
					//DELETE

						$this->session->set_flashdata('action', 'deleted'); 						
						
						$filePath   = str_replace('system/','',BASEPATH).'uploads/product_catalog/';
						$image_name = "";

						foreach($this->input->post('product_catalog') as $key)
						{

							$image_name = $this->M_product_catalog->get_image_name($key);
							$filePath.= $image_name;

							//delete downloads 			
							if(!$this->M_product_catalog->delete($key)){ 
								$failCtr++;
								$this->session->set_flashdata('actionsFailed', $failCtr);
							}else{
								
								if(file_exists($filePath)){
									if(is_file($filePath))
										unlink($filePath);									
								}

								$successCtr++;
								$this->session->set_flashdata('actionsSuccess', $successCtr);
							}								
						}
					break;
			}

		}		
		redirect('admin/product_catalog/index/'.$uri_4);
	}
	
	function delete($id){		
		$image_name = "";

		$filePath   = str_replace('system/','',BASEPATH).'uploads/product_catalog/';			
		$image_name = $this->M_product_catalog->get_image_name($id);
		$filePath.= $image_name;

		//delete download
		if($this->M_product_catalog->delete($id))
		{			
			if(file_exists($filePath)){
				if(is_file($filePath))
					unlink($filePath);									
			}

			$this->session->set_flashdata('deleted', TRUE);	
			redirect('admin/product_catalog');
		}
	}
	
	function delete_file($file){
		$filePath = str_replace('system/','',BASEPATH).'uploads/product_catalog/'.$file;
		if(file_exists($filePath)){
			if(is_file($filePath))unlink($filePath);
			return TRUE;
		}
		return FALSE;
	}
	
	function download_file($id){ 
		$download = $this->M_download->get($id); 
		if(count($download)){
			$filePath = str_replace('system/','',BASEPATH).'uploads/downloads/'.$download['file_name'];
			$name = $download['file_name'];
			force_download($name, file_get_contents($filePath));
			return TRUE;
		}
		return FALSE;
	}
	
	function pagination($pagination_config){
		/*PAGINATION SETTING*/
		$config['base_url'] = $pagination_config['base_url'];
		$config['total_rows'] = $pagination_config['count']; 
		$config['per_page'] = $pagination_config['perpage']; 
		$config['uri_segment'] = 4;
		$config['num_links'] = 4;
		//first and last links
		$config['first_link'] = '&laquo; First';
		$config['last_link'] = 'Last &raquo;';
		//first link tags
		$config['first_tag_open'] = '<li style="margin-right:20px;">';
		$config['first_tag_close'] = '</li>';
		//last link tags
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '<li>';
		//next link tags
		$config['next_link'] = 'Next &raquo;';
		$config['next_tag_open'] = '<li style="margin-right:20px;margin-left:10px;"">';
		$config['next_tag_close'] = '</li>';
		//previous link tags
		$config['prev_link'] = '&laquo; Previous';
		$config['prev_tag_open'] = '<li style="margin-right:10px;">';
		$config['prev_tag_close'] = '</li>';
		//current link tags
		$config['cur_tag_open'] = '<li class="active"><a>';
		$config['cur_tag_close'] = '</a></li>';
		//links tags
		$config['num_tag_open'] = '<li class="pages">';
		$config['num_tag_close'] = '</li>';
		$this->pagination->initialize($config);
	}

	function export(){
		$this->load->helper('csv');
		$website = $this->M_website->getName();
		$sql = "SELECT p.p_number AS 'Number', p.p_title AS 'Title', p.p_description AS 'Description', p.p_price AS 'Price', c.pc_category AS 'Category'
FROM ci_product_catalog p
LEFT JOIN ci_product_category c ON p.p_category = c.pc_id
ORDER BY p.p_id ASC
LIMIT 0 , 30";
		$query = $this->db->query($sql);
		query_to_csv($query, TRUE, $website.'-Product-Catalog.csv');
	}

	/* PRODUCT CATEGORY */
	function category($offset = 0){
		//set pagination
		$pagination_config = array(
			'perpage' => 10,
			'base_url' => base_url().index_page().'admin/product_catalog/category/',
			'count' => $this->M_product_catalog->get_count_category()
		);
		$this->pagination($pagination_config);
		//set page data
		$data['catalog_category'] = $this->M_product_catalog->get_all_category($pagination_config['perpage'], $offset);		

		$data['title'] = 'Product Catalog Category';
		$data['content'] = 'admin/product_catalog/product_catalog_category';
		$data['sitename'] = $this->M_website->getName();
		
		//for actions message
		$data['action'] = $this->session->flashdata('action');
		$data['saved'] = $this->session->flashdata('saved');
		$data['deleted'] = $this->session->flashdata('deleted');
		$data['no_selected'] = $this->session->flashdata('noSelected');
		$data['actions_failed'] = $this->session->flashdata('actionsFailed'); 
		$data['actions_success'] = $this->session->flashdata('actionsSuccess'); 
		
		//parse template
		$this->parser->parse('admin/template', $data);
	}
	function product_catalog_add(){
		//set page data
		$data['title'] = 'Add Product Catalog Category';
		$data['content'] = 'admin/product_catalog/product_catalog_category_add';
		$data['sitename'] = $this->M_website->getName();
		//parse template
		$this->parser->parse('admin/template', $data);
	}

	function product_catalog_category_save(){ 
		$this->form_validation->set_rules('pc_category', 'Category', 'required');
		if ($this->form_validation->run() == FALSE){
			//set page data
			$data['title'] = 'Add Product Catalog Category';
			$data['content'] = 'admin/product_catalog/product_catalog_category_add';
			$data['sitename'] = $this->M_website->getName();
			//parse template
			$this->parser->parse('admin/template', $data);
		}else{
			if($this->M_product_catalog->insert_category($_POST)){
				$this->session->set_flashdata('saved', TRUE);
				redirect('admin/product_catalog/category');
			}
		}
	}
	function product_catalog_delete($id){
		if($this->M_product_catalog->delete_category($id)){
			$this->session->set_flashdata('deleted', TRUE);	
			redirect('admin/product_catalog/category');
		}
	}
	
	function product_catalog_action(){ 
		$uri_4 = $this->input->post('uri_4');
		$failCtr = 0;
		$successCtr = 0;
		if(!$this->input->post('categories')){
			$this->session->set_flashdata('noSelected', TRUE);
		}else{
			switch($this->input->post('selectAction')){
				case 'delete':
					//DELETE
					$this->session->set_flashdata('action', 'deleted'); 
					foreach($this->input->post('categories') as $row){ 
					
						if(!$this->M_product_catalog->delete_category($row)){ 
							$failCtr++;
							$this->session->set_flashdata('actionsFailed', $failCtr);
						}else{
							$successCtr++;
							$this->session->set_flashdata('actionsSuccess', $successCtr);
						}
						
					}
					break;
			}
		}
		redirect('admin/product_catalog/category/'.$uri_4);
	}
	
	function product_catalog_edit($id){
		//set page data
		$data['category'] = $this->M_product_catalog->get_category($id);
		$data['title'] = 'Edit Product Catalog Category';
		$data['content'] = 'admin/product_catalog/product_catalog_category_edit';
		$data['sitename'] = $this->M_website->getName();
		//parse template
		$this->parser->parse('admin/template', $data);
	}
	
	function product_catalog_save(){ 
		$this->form_validation->set_rules('pc_category', 'Category', 'required');
		if ($this->form_validation->run() == FALSE){
			//set page data
			$data['title'] = 'Add Product Catalog';
			$data['content'] = 'admin/product_catalog/product_catalog_edit';
			$data['sitename'] = $this->M_website->getName();
			//parse template
			$this->parser->parse('admin/template', $data);
		}else{
			if($this->M_product_catalog->update_category($_POST)){
				$this->session->set_flashdata('saved', TRUE);
				redirect('admin/product_catalog/category');
			}
		}
	}

	#SUB CATEGORY
	function subcategory($offset = 0)
	{
		//set pagination
		$pagination_config = array(
			'perpage' => 10,
			'base_url' => base_url().index_page().'admin/product_catalog/subcategory/',
			'count' => $this->M_product_catalog->get_count_sub_category()
		);
		$this->pagination($pagination_config);
		//set page data
		$data['catalog_category'] = $this->M_product_catalog->get_all_subcategory($pagination_config['perpage'], $offset);		

		$data['title'] = 'Product Catalog Category';
		$data['content'] = 'admin/product_catalog/product_catalog_subcategory';
		$data['sitename'] = $this->M_website->getName();
		
		//for actions message
		$data['action'] = $this->session->flashdata('action');
		$data['saved'] = $this->session->flashdata('saved');
		$data['deleted'] = $this->session->flashdata('deleted');
		$data['no_selected'] = $this->session->flashdata('noSelected');
		$data['actions_failed'] = $this->session->flashdata('actionsFailed'); 
		$data['actions_success'] = $this->session->flashdata('actionsSuccess'); 
		
		//parse template
		$this->parser->parse('admin/template', $data);
	}

	function product_catalog_subcategory_add(){		
		//set page data
		$data['title'] = 'Add Product Sub Category';
		$data['content'] = 'admin/product_catalog/product_catalog_subcategory_add';
		$data['sitename'] = $this->M_website->getName();
		$data['categories'] = $this->M_product_catalog->get_categories();	
		//parse template
		$this->parser->parse('admin/template', $data);
	}
	
	function product_catalog_subcategory_save(){ 
		$this->form_validation->set_rules('sub_name', 'Sub Category', 'required');

		if ($this->form_validation->run() == FALSE){
			//set page data
			$data['title'] = 'Add Sub Category';
			$data['content'] = 'admin/product_catalog/product_catalog_subcategory_add';
			$data['sitename'] = $this->M_website->getName();
			$data['categories'] = $this->M_product_catalog->get_categories();
			//parse template
			$this->parser->parse('admin/template', $data);
		}else{
			if($this->M_product_catalog->insert_subcategory($_POST)){
				$this->session->set_flashdata('saved', TRUE);
				redirect('admin/product_catalog/subcategory');
			}
		}
	}

	function product_catalog_subdelete($id){
		if($this->M_product_catalog->delete_subcategory($id)){
			$this->session->set_flashdata('deleted', TRUE);	
			redirect('admin/product_catalog/subcategory');
		}
	}

	function product_subcatalog_action(){ 
		$uri_4 = $this->input->post('uri_4');
		$failCtr = 0;
		$successCtr = 0;
		if(!$this->input->post('categories')){
			$this->session->set_flashdata('noSelected', TRUE);
		}else{			
			switch($this->input->post('selectAction')){
				case 'delete':
					//DELETE
					$this->session->set_flashdata('action', 'deleted'); 					

					foreach($this->input->post('categories') as $row){ 
					
						if(!$this->M_product_catalog->delete_subcategory($row)){ 
							$failCtr++;
							$this->session->set_flashdata('actionsFailed', $failCtr);
						}else{
							$successCtr++;
							$this->session->set_flashdata('actionsSuccess', $successCtr);
						}
						
					}
					break;
			}
		}
		redirect('admin/product_catalog/subcategory/'.$uri_4);
	}

	function product_catalog_subcategory_edit($id){
		//set page data
		
		$data['category'] = $this->M_product_catalog->get_subcategory($id);

		$data['title'] = 'Edit Sub Category';
		$data['content'] = 'admin/product_catalog/product_catalog_subcategory_edit';
		$data['sitename'] = $this->M_website->getName();
		$data['categories'] = $this->M_product_catalog->get_categories();
		//parse template
		$this->parser->parse('admin/template', $data);
	}

	function product_catalog_subsave(){ 
		$this->form_validation->set_rules('sub_name', 'Sub Category', 'required');
		if ($this->form_validation->run() == FALSE){
			//set page data
			$data['title'] = 'Edit Sub Category';
			$data['content'] = 'admin/product_catalog/product_catalog_subcategory_edit';
			$data['sitename'] = $this->M_website->getName();
			$data['categories'] = $this->M_product_catalog->get_categories();
			//parse template
			$this->parser->parse('admin/template', $data);
		}else{			
			if($this->M_product_catalog->update_subcategory($_POST)){
				$this->session->set_flashdata('saved', TRUE);
				redirect('admin/product_catalog/subcategory');
			} 
		}
	}

    function get_sub()
    {
            $p_category = $this->input->post('p_category');

            if($p_category != '')
            {                
				$subcategories = $this->M_product_catalog->get_sub_spec_categories($p_category);	

                if($subcategories){     
                        #echo "<option value=''>-Select-</option>";                                                
                        foreach ($subcategories as $row)
                        {
                            $sub_name = $row['sub_name'];
                            
                            #if ($download['p_subcategory'] == $row['sub_id']) $selected = "selected='selected'";else $selected = '';
                            $selected = "";

                            echo "<option value='".$row['sub_id']."' ".$selected.">";
                            echo $sub_name;
                            echo "</option>";
                        }                               
                }else{
                    echo 'false';
                }

            }else{
                echo 'false';
            }
    }
	

}

/* End of file download.php */
/* Location: ./application/controllers/admin/download.php */