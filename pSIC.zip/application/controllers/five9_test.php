<?PHP
class Five9_test extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('admin/M_website');
    }

    function index() {
$config = $this->config->item('five9');
$auth = array(
    'trace' => 1,
    "login" => $config['username'],
    "password" => $config['password']);

$soap = new SoapClient($config['wsdl'], $auth);

$result = $soap->getContactFields();

print_r($result);
}
}