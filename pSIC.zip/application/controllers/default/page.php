<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper('text');
        $this->load->model('admin/M_website');
        $this->load->model('default/M_page');
        $this->load->model('default/M_newsletter');
    }

    function index() {
    

        //get site data
        $website = $this->M_website->getWebsite();
        //get url key
        $url_key = $this->get_current_module();
        //get page data
        $page = $this->M_page->getHomePage();

        // Check if recaptcha has been enabled in admin settings.
        if ($this->get_setting('appointment_enable_captcha')->setting_value) {
            $this->view_data['recaptcha'] = $this->load->view('recaptcha', array('recaptcha' => $this->recaptcha->get_html()), TRUE);
        }

        //set page data
        if (!count($page)) {
            //DEFAULT HOME DATA
            $data['sitename'] = $website['name'];
            $data['title'] = 'Home';
            $data['site_title'] = 'Home';
            $data['content'] = '';
            $data['page'] = 'default/page/home';
            $data['keywords'] = $website['default_metakeywords'];
            $data['desc'] = $website['default_metadesc'];
            $data['robots'] = $website['meta_robots'];
            $data['canonical'] = '3';
        } else {
            $data['sitename'] = $website['name'];
            $data['title'] = $page['page_title'];
            $data['site_title'] = $page['site_title'];
            $data['content'] = $page['content'];
            $data['page'] = 'default/page/home';
            $data['keywords'] = $page['keywords'];
            $data['desc'] = $page['desc'];
            $data['robots'] = $page['robots'];
            $data['canonical'] = $page['canonical'];

            //set global meta data if page meta data is blank
            if ($page['keywords'] == '') {
                $data['keywords'] = $website['default_metakeywords'];
            }
            if ($page['site_title'] == '') {
                $data['site_title'] = $page['page_title'];
            }
            if ($page['desc'] == '') {
                $data['desc'] = $website['default_metadesc'];
            }
            if ($page['robots'] == '') {
                $data['robots'] = $website['meta_robots'];
            }
            if ($page['canonical'] == '' && $page['canonical_href']=='') {
                $data['canonical'] = '3';
            }elseif($page['canonical_href']!=''){
                $data['canonical'] = $page['canonical_href'];
            }elseif($page['canonical'] == '0'){
                $data['canonical'] = '0';
            }else{
                $data['canonical'] = '3';
            }
        }

        //$data['downloads'] = $this->M_download->get_downloads($page['id_page']);
        //parse template
        $data = array_merge($this->view_data, $data);

        $this->parser->parse('default/templates/' . $this->get_setting('home_template'), $data);
    }

    function view() {

        // Check if recaptcha has been enabled in admin settings.
        if ($this->get_setting('appointment_enable_captcha')->setting_value) {
            $this->view_data['recaptcha'] = $this->load->view('recaptcha', array('recaptcha' => $this->recaptcha->get_html()), TRUE);
        }

        $this->load->helper('cs_template');
        //get site data
        $website = $this->M_website->getWebsite();
        //get url key
        $url_key = $this->get_current_module();
        //get page data
        $page = $this->M_page->get($url_key);

        if (isset($this->view_data['related_pages'])) {
            $data['related_pages'] = $this->view_data['related_pages'];
        }
        //set page data
        if (count($page)) {
            $data['url_key'] = $url_key;
            $data['class'] = $page['class'];
            $data['sitename'] = $website['name'];
            $data['title'] = $page['page_title'];
            $data['site_title'] = $page['site_title'];
            $data['content'] = $page['content'];
            $data['page'] = 'default/page/inner_page';
            $data['keywords'] = $page['keywords'];
            $data['desc'] = $page['desc'];
            $data['robots'] = $page['robots'];
            $data['canonical'] = $page['canonical'];
            $data['includes_sidebar2'] = 'default/includes/sidebar2';
            $data['downloads'] = $this->M_download->get_downloads($page['id_page']);

            //set global meta data if page meta data is blank
            if ($page['keywords'] == '') {
                $data['keywords'] = '';
            } 
if ($page['site_title'] == '') {
                $data['site_title'] = $page['page_title'];
            }

            if ($page['desc'] == '') {
                $data['desc'] = '';
            }
            if ($page['robots'] == '') {
                $data['robots'] = $website['meta_robots'];
            }
            if ($page['canonical'] == '' && $page['canonical_href']=='') {
                $data['canonical'] = '3';
            }elseif($page['canonical_href']!=''){
                $data['canonical'] = $page['canonical_href'];
            }elseif($page['canonical'] == '0'){
                $data['canonical'] = '0';
            }else{
                $data['canonical'] = '3';
            }
        } else {
            //Page Not Found
            redirect('Page_not_found');
        }
        //parse template
        $data = array_merge($this->view_data, $data);


        $this->parser->parse(set_template($url_key), $data);
    }

    function save_page() {

        $this->load->model('default/m_page');

        $data = array(
            'url_key' => $this->input->post('url_key'),
            'page_title' => $this->input->post('page_title'),
            'content' => $this->input->post('content')
        );

        if ($this->M_page->update_page_content($data)) {
            $data ['title'] = $data['page_title'];
            echo $data['title'];
            echo $data['content'];
        }

    }

}

/* End of file page.php */
/* Location: ./application/controllers/default/page.php */