<?php
error_reporting(0);
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Mri extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->require_validation();
    }

    function index() {
        //load objects
        $this->load->helper('text');
        $this->load->model('admin/M_website');
        $this->load->model('default/M_page');
        $this->load->model('default/M_newsletter');
        //get site data
        $website = $this->M_website->getWebsite();
        //get url key
        $url_key = end($this->uri->segment_array());
        //get page data
        $page = $this->M_page->get($url_key);

        // Check if recaptcha has been enabled in admin settings.
if($url_key!='contact-form'){
        if ($this->get_setting('mri_enable_captcha')->setting_value) {
            if ($this->config->item('captcha-type')->setting_value === __RECAPTCHA__) {
                $this->view_data['recaptcha'] = $this->load->view('recaptcha', array('recaptcha' => $this->recaptcha->get_html()), TRUE);
            } else if ($this->config->item('captcha-type')->setting_value === __CAPTCHA_AYAH__) {
                $this->load->library('ayah');
                $this->view_data['recaptcha'] = $this->ayah->getPublisherHTML();
            } else if ($this->config->item('captcha-type')->setting_value === __NEW_RECAPTCHA__) {

                $_rConfig = $this->config->item('new_recaptcha');
                $this->view_data['recaptcha'] = '<div class="g-recaptcha" data-sitekey="' . $_rConfig['site_key'] . '"></div> ';
            }
        }
}

        //set page data
        if (count($page)) {
            $url_key = $this->view_data['url_key'];
            $data['class'] = $page['class'];
            $data['sitename'] = $website['name'];
            $data['title'] = $page['page_title'];
            $data['content'] = $page['content'];
            $data['page'] = 'default/page/inner_page';
            $data['keywords'] = $page['keywords'];
            $data['desc'] = $page['desc'];
            $data['robots'] = $website['meta_robots'];
            $data['canonical'] = $page['canonical'];
            $data['downloads'] = $this->M_download->get_downloads($page['id_page']);
            if (isset($_SESSION['contact_msg_sent'])) {
                $data['contact_msg_sent'] = $_SESSION['contact_msg_sent'];
                unset($_SESSION['contact_msg_sent']);
            }
            $data['site_title'] = $page['site_title'];

            //set global meta data if page meta data is blank
            if ($page['site_title'] == '') {
                $data['site_title'] = $page['page_title'];
            }
            if ($page['canonical'] == '' && $page['canonical_href'] == '') {
                $data['canonical'] = '3';
            } elseif ($page['canonical_href'] != '') {
                $data['canonical'] = $page['canonical_href'];
            } elseif ($page['canonical'] == '0') {
                $data['canonical'] = '0';
            } else {
                $data['canonical'] = '3';
            }

            //set global meta data if page meta data is blank
            if ($page['keywords'] == '') {
                $data['keywords'] = $website['default_metakeywords'];
            }
            if ($page['desc'] == '') {
                $data['desc'] = $website['default_metadesc'];
            }
        } else {
            //Page Not Found
            redirect('Page_not_found');
        }
        $data['duplicate_entry'] = FALSE;
        //parse template
        $data = array_merge($data, $this->view_data);
if($url_key=='contact-form'){
        $this->parser->parse('default/templates/mri_template', $data);
}else{
        $this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $data);
}
    }

    function send() {
        //load objects
        $this->load->model('default/m_settings');
        $this->require_validation();
        $this->load->library('email');
        $this->load->helper('text');
        $this->load->model('admin/M_transactional_emails');
        $this->load->model('admin/M_administrator');
        $this->load->model('admin/M_website');
        $this->load->model('default/M_page');
        $this->load->model('default/M_newsletter');
        $this->load->model('default/M_mri');

        //get site data
        $website = $this->M_website->getWebsite();
        //get url key
        $url_key = $this->view_data['url_key'];
        //get page data
        $page = $this->M_page->get($url_key);

        //set page data
        $data['url_key'] = $url_key;
        $data['class'] = $page['class'];
        $data['sitename'] = $website['name'];
        $data['title'] = $page['page_title'];
        $data['content'] = $page['content'];
        $data['page'] = 'default/page/inner_page';
        $data['keywords'] = $page['keywords'];
        $data['desc'] = $page['desc'];
        $data['robots'] = $website['meta_robots'];
        $data['downloads'] = $this->M_download->get_downloads($page['id_page']);
        $data['site_title'] = $page['site_title'];
        $data['canonical'] = $page['canonical'];
        //set global meta data if page meta data is blank
        if ($page['site_title'] == '') {
            $data['site_title'] = $page['page_title'];
        }

        if ($page['canonical'] == '' && $page['canonical_href'] == '') {
            $data['canonical'] = '3';
        } elseif ($page['canonical_href'] != '') {
            $data['canonical'] = $page['canonical_href'];
        } elseif ($page['canonical'] == '0') {
            $data['canonical'] = '0';
        } else {
            $data['canonical'] = '3';
        }
        //set global meta data if page meta data is blank
        if ($page['keywords'] == '') {
            $data['keywords'] = $website['default_metakeywords'];
        }
        if ($page['desc'] == '') {
            $data['desc'] = $website['default_metadesc'];
        }

        //validate form
        $this->form_validation->set_rules('fname', 'First Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('lname', 'Last Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('number', 'Phone', 'required|xss_clean');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('zip', 'Zip', 'required');
        $this->form_validation->set_rules('agree', 'Agreement checkbox', 'trim|required|xss_clean');

        // Check if recaptcha has been enabled in admin settings.
if($url_key!='contact-form'){
        if ($this->get_setting('mri_enable_captcha')->setting_value) {
            if ($this->config->item('captcha-type')->setting_value === __RECAPTCHA__) {
                $this->form_validation->set_rules('recaptcha_response_field', 'lang:recaptcha_field_name', 'required|callback_check_captcha');
                $this->view_data['recaptcha'] = $this->load->view('recaptcha', array('recaptcha' => $this->recaptcha->get_html()), TRUE);
            } else if ($this->config->item('captcha-type')->setting_value === __CAPTCHA_AYAH__) {
                $this->load->library('ayah');
                $this->form_validation->set_rules('recaptcha', 'This field is required.', 'required|callback_checkAYAHRecaptcha');
                $this->view_data['recaptcha'] = $this->ayah->getPublisherHTML();
            } else if ($this->config->item('captcha-type')->setting_value === __NEW_RECAPTCHA__) {

                $_rConfig = $this->config->item('new_recaptcha');
                $this->view_data['recaptcha'] = '<div class="g-recaptcha" data-sitekey="' . $_rConfig['site_key'] . '"></div> ';
                $this->form_validation->set_rules('g-recaptcha-response', 'Recaptcha', 'required|callback_checkNewRecaptcha');
            }
        }
}

        $duplicate_entry_flag = FALSE;
        $duplicate = $this->M_mri->check_duplicate($_POST);

        if (count($duplicate) > 0) {
            $duplicate_entry_flag = TRUE;
        } else {
            if ($this->form_validation->run()) {                
                
                // subscribe email to mailing list.
if($url_key!='contact-form'){
               /* if ($this->input->post('subscribe') == 1) {
                    
                    
                    //MailChimp API
                    $this->load->model('Mailchimp');
                    $this->Mailchimp->subscribe(array(
                                'fname' => $this->input->post('fname'),
                                'lname' => $this->input->post('lname'),
                                'email' => $this->input->post('email'),
                            ));
                
                    $this->load->helper('cs_newsletter_helper');
                    subscribe_for_mailing_list(
                            array(
                                'fname' => $this->input->post('fname'),
                                'lname' => $this->input->post('lname'),
                                'email' => $this->input->post('email'),
                            )
                    );
                }*/
}

                //insert contact log
                $_POST['source'] = 'Free MRI Review';
                $this->M_mri->insert($_POST);
                
                //Constant Contact Integration
                unset($_POST['source']);
                /*if ($this->input->post('subscribe') == 1 || $this->input->post('agree') == 1) {
                        $this->load->helper('cs_constantcontact');  
                        add_constantcontact($_POST);
                }*/
                if ($this->input->post('agree') == 1) {
                        $this->load->helper('cs_constantcontact');  
                        add_constantcontact($_POST);
                }
                
                //Televoips 
                $this->load->model('televoips');
                $this->televoips->insert($this->input->post('number'));
                
                //FIVE9 API
                /*$this->load->model('five9');
                $this->five9->insert(array(
                    'first_name' => $this->input->post('fname'),
                    'last_name' => $this->input->post('lname'),
                    'number1' => $this->input->post('number'),
                    'email' => $this->input->post('email'),
                    'zip' => $this->input->post('zip'),
                    'capture_date' => date('Y-m-d'),
                ));*/
                
                $mri_id = $this->db->insert_id();
                //add lead status history
                $this->load->model('default/M_crm_status_history');
                $_status_history = array(
                    'status_id' => '1',
                    'id_mri' => $mri_id,
                    'comment' => '',
                    'attachment' => '',
                    'posted_by' => '',
                    'history_date' => date('Y-m-d H:i:s')
                );
                $this->M_crm_status_history->do_save($_status_history);

                //get admin data
                $admin = $this->M_administrator->getSuperAdmin();
                //get transactional emails
                $email_recipient = $this->m_settings->get('mri_email_recipient');
                $email_confirmation = $this->m_settings->get('mri_email_confirmation');
                $email_confirmation_subj = $this->m_settings->get('mri_email_confirmation_subject');
                $email_admin_notification = $this->m_settings->get('mri_admin_notificaion');
                $email_admin_notification_subj = $this->m_settings->get('mri_admin_notificaion_subject');
                //send contact us email
                //get admin email
                $admin_email = $this->m_settings->get('admin_outgoing_email')->setting_value;
                $email_sender_from = ($admin_email) ? $admin_email : 'no-reply@' . strtolower(preg_replace('/\s/', '-', $website['name']));

                //for sender
                $closing = $this->m_settings->get('global_email_footer')->setting_value;
                $email_sender_subj = $email_confirmation_subj->setting_value;
                $email_sender_msg = $email_confirmation->setting_value;
                $name = $this->input->post('fname') . ' ' . $this->input->post('lname');
                $email_sender_msg = str_replace('%%NAME%%', $name, $email_sender_msg);
                $email_sender_msg = str_replace('%%CLOSING%%', $closing, $email_sender_msg);

               $this->email->clear();
                $config['mailtype'] = 'html';
                $this->email->initialize($config);
                $this->email->from($email_sender_from, $website['name']);
                $this->email->to($this->input->post('email'));
                $this->email->bcc('kirby@creatingskies.com');
                $this->email->subject('[' . $website["name"] . '] ' . $email_sender_subj);
                $this->email->message($email_sender_msg);
                $this->email->send();


                //for administrator
                $admin_notif_from = 'no-reply@' . strtolower(preg_replace('/\s/', '-', str_replace(',', '', $website['name'])));
                $admin_notif_subj = $email_admin_notification_subj->setting_value;
                $admin_notif_msg = str_replace('%%NAME%%', $name, $email_admin_notification->setting_value);
                $admin_notif_msg = str_replace('%%NUMBER%%', $this->input->post('number'), $admin_notif_msg);
                $admin_notif_msg = str_replace('%%EMAIL%%', $this->input->post('email'), $admin_notif_msg);
                $admin_notif_msg = str_replace('%%ZIP%%', $this->input->post('zip'), $admin_notif_msg);
                $admin_notif_msg = str_replace('%%CLOSING%%', $closing, $admin_notif_msg);


                $this->email->clear();
                $config['mailtype'] = 'html';
                $this->email->initialize($config);
                $this->email->from($email_sender_from, $website['name']);
                $this->email->to($email_recipient->setting_value);
                $this->email->bcc('kirby@creatingskies.com');
                $this->email->subject('[' . $website["name"] . '] ' . $admin_notif_subj);
                $this->email->message($admin_notif_msg);
                $this->email->send();
                //redirect page
               // $_SESSION['contact_msg_sent'] = TRUE;
            if($url_key=='contact-form'){
                echo'<script>window.top.location.href = "http://www.aroinfo.com/thank-you";</script>';
            }else{
                redirect(base_url() . "mri-thank-you-page", "refresh");
            }
            }
        }

        $data['duplicate_entry'] = $duplicate_entry_flag;
        //parse template
        $data = array_merge($data, $this->view_data);
if($url_key=='contact-form'){
        $this->parser->parse('default/templates/mri_template', $data);
}else{
        $this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $data);
}
    }

}

/* End of file mri.php */
/* Location: ./application/controllers/default/mri.php */