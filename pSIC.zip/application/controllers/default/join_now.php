<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Join_now extends MY_Controller {

    protected $_form_data;

    function __construct() {
        parent::__construct();
        $this->load->helper('security');
        $this->load->helper('form');
        $this->load->model('default/M_user');
    }

    function index() {

        $this->load->helper('cs_dropdown');    

        $this->_prep_form_values('validation_register_form');
        if ($this->input->post('submit')) {
            
            if ($this->_form_data['inches'] >= 0 and $this->_form_data['inches'] < 10)
            {
                $inches = '0'. $this->_form_data['inches'];
            } else{
                $inches = $this->_form_data['inches'];
            }
            
            $this->_form_data['height'] = $this->_form_data['feet'] . '.' .$inches;
            $this->_form_data['phone'] = implode('-', $_POST['phone']);
            $this->_form_data['birthday'] = $this->_form_data['year'] . '-' . $this->_form_data['month'] . '-' . $this->_form_data['date'];

            
            if ($this->_save('validation_register_form', $this->M_user)) {

                
                // Send email to admin and person.
                $this->load->helper('cs_emails');  
                $this->_form_data['name'] = $this->_form_data['firstname'].' '. $this->_form_data['lastname'];
               
                
                // Get country.
                $this->load->model('default/m_states');
                $state = $this->m_states->get($this->_form_data['state']);
                $this->_form_data['state'] = $state->state_name;
                
                $this->_form_data['link'] = '<a href="' . base_url() . '">' . base_url() . '</a>';
                
                // Send an email to the registrant.
               send_email_template(
                        'reg_email_confirmation',
                        $this->_form_data['email'],
                        null,
                        $this->_form_data
                  );

                // Send email to admin.
                send_email_template('reg_admin_notification', $this->get_setting('reg_email_recipient'), null, $this->_form_data);

                    $this->session->set_flashdata('message', "Thank you for registering! Please wait until you've received your confirmation e-mail before logging in.");
                    redirect (current_url());
                    exit();
             
            }
        }
        
        $this->view_data['page'] = 'default/join_now/register';
        //parse template
        $this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $this->view_data);
    }

}

/* End of file join_now.php */
/* Location: ./application/controllers/admin/join_now.php */