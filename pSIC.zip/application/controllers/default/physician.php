<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Physician extends MY_Controller {

    protected $_form_data;

    function __construct()
    {
        parent::__construct();
        if(!$this->session->userdata('logged_user')) redirect('login');
        $this->load->helper('form');
        $this->load->model('default/M_physician');
        $this->load->model('default/M_user');
    }

    // --------------------------------------------------------------------

    /**
     * Default action. Physician form.
     */
    function index()
    {
        //some page data
        $url_key = $this->get_current_module(); 
        $this->load->model('default/M_page');

        $page = $this->M_page->get($url_key);

        $data['content'] = $page['content'];
        $data['class'] = $page['class'];
        $data['current_url'] = $this->_get_current_page_url();
        $data['page'] = 'default/physician/view';

        $this->view_data = array_merge($data, $this->view_data);

    	$this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $this->view_data);
    }

    // --------------------------------------------------------------------
    
    function search()
    {
        $this->load->helper('cs_dropdown'); 
        //some page data
        $url_key = $this->get_current_module(); 
        $this->load->model('default/M_page');

        $page = $this->M_page->get($url_key);

        $data['content'] = $page['content'];
        $data['class'] = $page['class'];
        $data['current_url'] = $this->_get_current_page_url();
        $data['page'] = 'default/physician/search';

        $this->view_data = array_merge($data, $this->view_data);

    	$this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $this->view_data);
    }
    // --------------------------------------------------------------------
    
    function search_result()
    {
        $condition = array(
                'lastname' => '', 
                'specialty' => '', 
                'physician_id' => '');
        
        if(isset($_POST['lastname'])){
            $condition['lastname'] = $_POST['lastname'];
        }
        
        if(isset($_POST['specialty'])){
            $condition['specialty'] = $_POST['specialty'];
        }
        
         //get user physician id
         $this->load->model('default/M_user');
        $userId = $this->session->userdata('user_id');
        $user = $this->M_user->get($userId);

        if($user['physician_id']  != ''){

            $physicianId = explode(",", $user['physician_id']);
            
            $condition['physician_id'] = implode('","', $physicianId);
        }
        
        $this->load->helper('cs_dropdown'); 
        //some page data
        $url_key = $this->get_current_module(); 
        $this->load->model('default/M_page');

        $page = $this->M_page->get($url_key);
        
        $data['physicians'] = $this->M_physician->searchRecord($condition);
        
        $data['content'] = $page['content'];
        $data['class'] = $page['class'];
        $data['current_url'] = $this->_get_current_page_url();
        $data['page'] = 'default/physician/search_result';
        
        $data['lastname'] = $condition['lastname'];
        $data['specialty'] = $condition['specialty'];

        $this->view_data = array_merge($data, $this->view_data);

    	$this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $this->view_data);
    }
    // --------------------------------------------------------------------
    
    function add() {
        
        
        $this->load->helper('cs_dropdown'); 
        $this->_prep_form_values('validation_physician_form');
        
        if ($this->input->post('submit'))
        {
                $this->_form_data['status'] = "approved";
                $this->_form_data['date_sent'] = date('Y-m-d H:i:s');
                if ($this->_save('validation_physician_form', $this->M_physician)){
                    
                     //get user id
                    $userId = $this->session->userdata('user_id');
                    $user = $this->M_user->get($userId);
                    
                        // Send email to admin and person.
                        $this->load->helper('cs_emails');
                        // Send email to admin.
                        send_email_template('physician_admin_notification', $this->get_setting('physician_email_recipient')->setting_value, null, $this->_form_data);
                        // Send email to patient.
                        send_email_template('physician_patient_confirmation',$this->_form_data['email'], null, $this->_form_data);                

                    $this->session->set_flashdata('message', 'Physician successfully added to your list.');

                    redirect (current_url());  
                }
            }
        
	    $this->view_data['page'] = 'default/physician/add';

    	$this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $this->view_data);
       
    }
    // --------------------------------------------------------------------
    
    function action()
    {
        $this->load->model('default/M_user');
        
        //get physicians id
        $physicianId = implode(",", $this->input->post('physicians'));
        
        if($physicianId != ''){

            //get user id
            $userId = $this->session->userdata('user_id');
            $user = $this->M_user->get($userId);

            if($user['physician_id']  != ''){

                $physicianId = $user['physician_id'] . ','. $physicianId;
            }

            //update 
            $this->M_user->updatePhysician($physicianId, $userId);

            $this->session->set_flashdata('message', 'Physician successfully added to your list.');
            redirect($this->_get_current_page_url(). '/search');
        }
        
    }  
}
/* End of file physician.php */
/* Location: ./application/controllers/default/physician.php */