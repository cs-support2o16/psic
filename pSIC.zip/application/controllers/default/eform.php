<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Eform extends MY_Controller {

    function __construct() {
        parent::__construct();
        if (!$this->session->userdata('logged_user'))
            redirect('login');
        $this->load->helper('form');
        $this->load->helper('download');
        $this->load->model('default/M_eform', 'form');
        $this->load->model('default/M_eform_user_response', 'form_user_response');
        $this->load->model('admin/M_website');
        $this->load->model('default/M_page');
        $this->load->model('default/M_user');
    }

    function index($page = 0)
    {
            //get site data
            $website = $this->M_website->getWebsite();
            //get url key
            $url_key = end($this->uri->segment_array()); 
            //get page data
            $page = $this->M_page->get($url_key);
         
            
            //get user data
            $this->load->model('default/M_user');
            $userId = $this->session->userdata('user_id');
            $data['user'] = $this->M_user->get($userId);

            //set page data
            if(count($page)){ 
                $url_key = $this->view_data['url_key'];
                    
   	        $page_url = 'inner_page';
   	        if($url_key == 'patient-confidentiality'){
			$page_url = 'patient-confidentiality';
		}
		if($url_key == 'info-sheet'){
			$page_url = 'info-sheet';
		}
		if($url_key == 'financial-policy'){
			$page_url = 'financial-policy';
		}
		if($url_key == 'post-op'){
			$page_url = 'post-op';
		}
		if($url_key == 'breast-check'){
			$page_url = 'breast-check';
		}
		if($url_key == 'medical-history'){
			$page_url = 'medical-history';
		}
		if($url_key == 'pediatric-health-quest'){
			$page_url = 'pediatric-health-quest';
		}
                
                $data['page'] = 'default/eform/'.$page_url;
                    
		$data['class'] = $page['class'];
		$data['sitename'] = $website['name'];
		$data['title'] = $page['page_title'];
		$data['content'] = $page['content'];
		$data['keywords'] = $page['keywords'];
		$data['desc'] = $page['desc'];
		$data['robots'] = $website['meta_robots'];
		$data['downloads'] = $this->M_download->get_downloads($page['id_page']);
			$data['site_title'] = $page['site_title'];
			
			//set global meta data if page meta data is blank
			if($page['site_title'] == ''){
				$data['site_title'] = $page['page_title'];
			}
	

		if(isset($_SESSION['form_msg_sent'])){
		    $data['form_msg_sent'] = $_SESSION['form_msg_sent']; 
		    unset($_SESSION['form_msg_sent']);
		}
            }
            else{
                    //Page Not Found
                    redirect('Page_not_found');
            }
            $this->view_data = array_merge($data, $this->view_data);

            // Display the form.
            $this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $this->view_data);
        
    }

    function send(){
		//load objects
		$this->load->model('default/m_settings');
                $this->require_validation();
                
                $userId = $this->session->userdata('user_id');
                
                $user = $this->M_user->get($userId);

		//get site data
		$website = $this->M_website->getWebsite();
		//get url key
                $url_key = $this->get_current_module();
		//get page data
		$page = $this->M_page->get($url_key);
		
		
		//get user data
		$this->load->model('default/M_user');
        	$userId = $this->session->userdata('user_id');
		$data['user'] = $this->M_user->get($userId);
                    
                if($url_key == 'patient-confidentiality'){
                	$eformId = '1';
                	$template = 'patient-confidentiality';
                }
                if($url_key == 'info-sheet'){
                	$eformId = '2';
                	$template = 'info-sheet';
                }
                if($url_key == 'financial-policy'){
                	$eformId = '4';
                	$template = 'financial-policy';
                }
                if($url_key == 'post-op'){
                	$eformId = '5';
                	$template = 'post-op';
                }
                if($url_key == 'breast-check'){
                	$eformId = '6';
                	$template = 'breast-check';
                }
                if($url_key == 'medical-history'){
                	$eformId = '7';
                	$template = 'medical-history';
                }
                if($url_key == 'pediatric-health-quest'){
                	$eformId = '8';
                	$template = 'pediatric-health-quest';
                }
                
                $filename = $template . '.pdf';
                
                    //get eform data
                    $eform = $this->form_user_response->getByFormType($eformId,$userId);
                   
                    //set data
                    $_POST['id_eform'] = $eformId;
                    $_POST['file_name'] = $filename;
                    $_POST['user_id'] = $userId;
                    if(!isset($_POST['patient_name'])){
                    	$_POST['patient_name'] = $_POST['firstname'] .' '. $_POST['lastname'];
                    }
                
                    if(!isset($_POST['patient_dob'])){
                    	$_POST['patient_dob'] = '';
                    }
                    if(!isset($_POST['patient_age'])){
                    	$_POST['patient_age'] = '';
                    }
                    if(count($eform)){ 
                    	    //insert eform user response data
	                    $this->form_user_response->update($_POST);
                    }else{
                    	    //insert eform user response data
	                    $this->form_user_response->insert($_POST);
                    }
                    
                    //get eform result data
                    $result = $this->form_user_response->getByFormType($eformId,$userId);
                    
                    $formData = $this->form->get($eformId);
                    
                    //setmail data
                    $mail_data = array();
                    $mail_data['patient_name'] = $_POST['patient_name'];
                    $mail_data['date_posted'] = date('M d, Y', strtotime($result['date_posted']));
                    $mail_data['user_name'] = $user['username'];
                    $mail_data['form_type'] = $formData['title'];
                    $mail_data['vd_link'] = base_url().index_page().'admin/eform/view_file/'.$result['id'];
                    
                    // Send email to admin.
                    $this->load->helper('cs_emails');
                    send_email_template('eform_admin_notification', $this->get_setting('eform_email_recipient')->setting_value, null, $mail_data);

                    //generate pdf file
                    include("mpdf/mpdf.php");
                    
		    $mpdf=new mPDF();
		    
		    $html = $this->parser->parse('default/eform/templates/' . $template, $_POST);
		    $mpdf->WriteHTML($html);
		    $filePath = str_replace('system/','',BASEPATH).'uploads/eform/'.$eformId."_".$userId."_".$filename;
		    $mpdf->Output($filePath);
		    
		//redirect page
		$_SESSION['form_msg_sent'] = TRUE;
                
                //get page data
                if($page['parent_id'] != 0){
                    $parent_url = $this->M_page->get_id($page['parent_id']);
                    $url_key = $parent_url['url_key'] . '/' . $url_key;
                }
		redirect($url_key);
	}

}
/* End of file form.php */
/* Location: ./application/controllers/default/eform.php */