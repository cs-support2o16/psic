<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Insurance extends MY_Controller {

    protected $_form_data;

    function __construct()
    {
        parent::__construct();

        $this->require_validation();
        $this->load->helper('form');
        $this->load->library('ayah');
    }

    // --------------------------------------------------------------------

    /**
     * Default action. Insurance form.
     */
    function index()
    {
        $this->load->helper('cs_dropdown');    

        if($this->config->item('captcha-type')->setting_value === __RECAPTCHA__) {
            $this->view_data['recaptcha'] = $this->load->view('recaptcha', array('recaptcha'=> $this->recaptcha->get_html()), TRUE);
            // Add captcha validation to config.
            enable_recaptcha('validation_appointment_form');
        } else if($this->config->item('captcha-type')->setting_value === __CAPTCHA_AYAH__) {
            $this->form_validation->set_rules('recaptcha', 'recaptcha', 'required|callback_checkAYAHRecaptcha');
            $this->view_data['recaptcha'] = $this->ayah->getPublisherHTML(); 
        }

	    $this->_prep_form_values('validation_insurance_form'); 


        if ($this->input->post('submit') || $this->isAjax())
        {
            $this->load->model('default/m_insurance');

            $captcha_value = $this->config->item('captcha-type')->setting_value;
            if($captcha_value === __RECAPTCHA__) {
                $this->form_validation->set_rules('recaptcha_response_field', 'lang:recaptcha_field_name', 'required|callback_check_captcha');
                $this->view_data['recaptcha'] = $this->load->view('recaptcha', array('recaptcha' => $this->recaptcha->get_html()), TRUE);
            } else if($captcha_value === __CAPTCHA_AYAH__) {
                $this->load->library('ayah');
                $this->form_validation->set_rules('recaptcha', 'This field is required.', 'required|callback_checkAYAHRecaptcha');
                $this->view_data['recaptcha'] = $this->ayah->getPublisherHTML(); 
            }

            $id = $this->_save('validation_insurance_form', $this->m_insurance);
            if ($id)
            {                
                // Send email to admin and person.
                $this->load->helper('cs_emails');                
                // Send email to admin.
                $this->_form_data['date'] = date('F d, Y');                
                send_email_template('insurance_admin_notification', $this->get_setting('insurance_email_recipient')->setting_value, null, $this->_form_data);
                // Send email to patient.
                send_email_template('insurance_patient_confirmation',$this->_form_data['email'], null, $this->_form_data);                            
                
                if ($this->isAjax())
                {
                    echo $id;
                    exit();
                }                
                $this->session->set_flashdata('message', 'Your insurance request has been submitted.');
                redirect (current_url());
            }
        }
        
            $url_key = $this->get_current_module();
            $this->load->model('default/M_page'); 
        	$page = $this->M_page->get($url_key);
        	$this->load->model('admin/M_website');
        	$website = $this->M_website->getWebsite();
    		
        	$this->view_data['robots'] = $website['meta_robots'];			
        	$this->view_data['keywords'] = $page['keywords'];
            $this->view_data['title'] = $page['page_title'];
        	$this->view_data['desc'] = $page['desc'];
            $this->view_data['site_title'] = $page['site_title'];

			//set global meta data if page meta data is blank
			if($page['site_title'] == ''){
				$this->view_data['site_title'] = $page['page_title'];
			}	
        	//set global meta data if page meta data is blank
        	if($page['keywords'] == ''){
        		$this->view_data['keywords'] = $website['default_metakeywords'];
        	}
        	if($page['desc'] == ''){
        		$this->view_data['desc'] = $website['default_metadesc'];
        	}

	    $this->view_data['page'] = 'default/insurance/edit';
    	$this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $this->view_data);
    }

    // --------------------------------------------------------------------
}
/* End of file insurance.php */
/* Location: ./application/controllers/default/insurance.php */