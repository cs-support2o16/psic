<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Account extends MY_Controller {

    function __construct() {
        parent::__construct();
        if (!$this->session->userdata('logged_user'))
            redirect('login');
        $this->load->helper('security');
        $this->load->helper('text');
        $this->load->helper('form');
        $this->load->model('admin/M_website');
        $this->load->model('default/M_page');
        $this->load->model('default/M_newsletter');
        $this->load->model('default/M_user');
        $this->load->model('default/M_physician');
        $this->load->helper('cs_dropdown');   
    }

    function index() {
        //get user id
        $userId = $this->session->userdata('user_id');
        //get user type
        $userType = $this->session->userdata('user_type');
        //get site data
        $website = $this->M_website->getWebsite();
        //get url key
        $url_key = $this->get_current_module();
        //get page data
        $page = $this->M_page->get($url_key);

        if (isset($this->view_data['related_pages'])) {
            $data['related_pages'] = $this->view_data['related_pages'];
        }

        if($userType == 'user'){
            $data['user'] = $this->M_user->get($userId);
            $data['page'] = 'default/account/form';
        }else if($userType == 'physician'){
            $data['user'] = $this->M_physician->get($userId);
            $data['page'] = 'default/account/physician_form';
        }

        $data['message'] = '';

        //set page data
        if (count($page)) {
            $data['url_key'] = $url_key;
            $data['class'] = $page['class'];
            $data['sitename'] = $website['name'];
            $data['title'] = $page['page_title'];
            $data['content'] = $page['content'];
            $data['keywords'] = $page['keywords'];
            $data['desc'] = $page['desc'];
            $data['robots'] = $website['meta_robots'];
            $data['includes_sidebar2'] = 'default/includes/sidebar2';
            $data['downloads'] = $this->M_download->get_downloads($page['id_page']);
        } else {
            //Page Not Found
            redirect('Page_not_found');
        }
        //parse template
        $data = array_merge($this->view_data, $data);
        $this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $data);
    }

    function update() {

        //get user id
        $userId = $this->session->userdata('user_id');
        //get user type
        $userType = $this->session->userdata('user_type');
        $message = '';
        
        //validate form
        $this->_prep_form_values('validation_account_form');
        if ($this->input->post('submit')) {
            
            if($userType == 'user'){
                
                 if ($this->_form_data['inches'] >= 0 and $this->_form_data['inches'] < 10)
                    {
                        $inches = '0'. $this->_form_data['inches'];
                    } else{
                        $inches = $this->_form_data['inches'];
                    }

                    $this->_form_data['height'] = $this->_form_data['feet'] . '.' .$inches;
                    $this->_form_data['phone'] = implode('-', $_POST['phone']);
                    $this->_form_data['birthday'] = $this->_form_data['year'] . '-' . $this->_form_data['month'] . '-' . $this->_form_data['date'];


                    if ($this->_update('validation_account_form', $this->M_user, $userId)) {
                        $message = 'Your account details has been updated.';
                    }
                    
            }else if($userType == 'physician'){
                    // Load fields from config.
                $this->load->config('validations');
                $config = $this->config->item('validation_physician_profile_form');

                $this->require_validation($config);

                if ($this->form_validation->run())
                {
                    if($this->M_physician->updateAdmin($_POST, $userId)){
                        $message = 'Your account details has been updated.';
                    }
                }
            }
           
        }
        
        $data['message'] = $message;
        

        //get site data
        $website = $this->M_website->getWebsite();
        //get url key
        $url_key = $this->view_data['url_key'];
        //get page data
        $page = $this->M_page->get($url_key);

        if($userType == 'user'){
            $data['user'] = $this->M_user->get($userId);
            $data['page'] = 'default/account/form';
        }else if($userType == 'physician'){
            $data['user'] = $this->M_physician->get($userId);
            $data['page'] = 'default/account/physician_form';
        }

        //set page data
        $data['url_key'] = $url_key;
        $data['class'] = $page['class'];
        $data['sitename'] = $website['name'];
        $data['title'] = $page['page_title'];
        $data['content'] = $page['content'];
        $data['keywords'] = $page['keywords'];
        $data['desc'] = $page['desc'];
        $data['robots'] = $website['meta_robots'];
        $data['downloads'] = $this->M_download->get_downloads($page['id_page']);

        //parse template
        $data = array_merge($this->view_data, $data);
        $this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $data);
    }
    
    function change_password($id =  null) {
        
        if($id != null){
            $message = '';
            $password_error = '';

            $this->require_validation();

            //validate form
            $this->form_validation->set_rules('old_password', 'Old password', 'required|xss_clean|callback_oldPasswordCheck');
            $this->form_validation->set_rules('new_password', 'New password', 'required|min_length[7]|xss_clean|matches[confirm_password]');
            $this->form_validation->set_rules('confirm_password', 'Confirm password', 'required|min_length[7]|xss_clean');
            if ($this->input->post('submit')) {
                $this->_form_data['old_password'] = $this->input->post('old_password');
                $this->_form_data['new_password'] = $this->input->post('new_password');
                
                //get user type
                $userType = $this->session->userdata('user_type');
                if($userType == 'user'){
                    $user_data = $this->M_user->get($id);
                    $user_model = 'M_user';
                    $password = base64_encode($this->_form_data['old_password']);
                }else if($userType == 'physician'){
                    $user_data = $this->M_physician->get($id);
                    $user_model = 'M_physician';
                    $password = do_hash($this->_form_data['old_password']);
                }
                
                if($user_data['password'] == $password){
                   if ($this->form_validation->run()) {
                        $this->$user_model->changePassword($id, base64_encode($this->_form_data['new_password']));
                        $message = 'Your account password has been changed.';
                    } 
                }else{
                    $password_error = '<label class="error">The Old password is invalid.</label>';
                }
            }

            $data['message'] = $message;
            $data['user_id'] = $id;
            $data['password_error'] = $password_error;

            //get site data
            $website = $this->M_website->getWebsite();
            //get url key
            $url_key = $this->view_data['url_key'];
            //get page data
            $page = $this->M_page->get($url_key);

            //set page data
            $data['url_key'] = $url_key;
            $data['class'] = $page['class'];
            $data['sitename'] = $website['name'];
            $data['title'] = $page['page_title'];
            $data['content'] = $page['content'];
            $data['page'] = 'default/account/password';
            $data['keywords'] = $page['keywords'];
            $data['desc'] = $page['desc'];
            $data['robots'] = $website['meta_robots'];
            $data['downloads'] = $this->M_download->get_downloads($page['id_page']);

            //parse template
            $data = array_merge($this->view_data, $data);
            $this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $data);
        }else{
            show_error('Invalid or no ID specified');
        }
    }


}

/* End of file page.php */
/* Location: ./application/controllers/default/page.php */
