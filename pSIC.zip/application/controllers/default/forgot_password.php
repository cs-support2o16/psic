<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forgot_password extends MY_Controller {

	function __construct(){
		parent::__construct();
		if($this->session->userdata('logged_user')) redirect('default/page');
		$this->load->library('form_validation');
		$this->load->library('email');
		$this->load->helper('security');
		$this->load->helper('string');
		$this->load->model('admin/M_website');
		$this->load->model('default/M_user');
		$this->load->helper('cs_template');
	}
	
	function index(){
                
		//set page data
		$data['title'] = 'Forgot Password';
                $data['sitename'] =$this->M_website->getName();
		$data['website'] = $this->M_website->getWebsite();
		
		//get url key
		$url_key = $this->get_current_module(); 
		$data['page'] = 'default/forgot_password/forgot_password';
		
		//parse template
                $data = array_merge($this->view_data, $data);
		$this->parser->parse(set_template($url_key), $data);
	}	
	
	function retrieve(){ 
		//set page data
		$data['title'] = 'Forgot Password';
                $data['sitename'] =$this->M_website->getName();
		$data['website'] = $this->M_website->getWebsite();
                $error = '';
                $msg = '';
                
                //get url key
		$url_key = $this->get_current_module(); 
		$data['page'] = 'default/forgot_password/forgot_password';
                
		//process
		$this->form_validation->set_rules('email', 'Email Address', 'required|valid_email');
		if($this->form_validation->run() == FALSE){
			$data['error'] = form_error('email', '<p style="color: #f93d3d; text-align:center; border: 1px solid #f93d3d; padding: 10px 0"><i>','</i><p>');
		}else{
			$email = $this->input->post('email', TRUE);
			$user = $this->M_user->getUserByEmail($email);
			if(count($user)){
				//set new password
				$new_password = $this->set_new_password();
				$this->M_user->saveResetPass($user['user_id'], base64_encode($new_password));
				
				//create email message 
				$message = "<h4>Dear ".$user['firstname']." ".$user['lastname'].",</h4>
				<p>You received this email because the Forgot Password Form has been submitted.</p>
				
				<p>
					Your access details are:
					<div style='background: #f9f9f9; border: 1px solid silver; padding: 20px; margin: 0'>
					<strong>Username:</strong> ".$user['username']." <br />
					<strong>New password:</strong> ".$new_password."
					</div>
				</p>
				<p>
					You can now log in using your new access details. Please click this <a href='".base_url().index_page()."login/'>login</a> link
					or you may copy-paste the link below to your browser:<br />
					".base_url().index_page()."login/index/
				</p>
				<p>
					Thank you.
				</p>
				<p>
					".$data['website']['name']."<br />
					".base_url()."
				</p>";
				//send email
					$config['mailtype'] = 'html';
					$this->email->initialize($config);
					$this->email->from('noreply@'.$_SERVER['HTTP_HOST'], $data['website']['name']);
					$this->email->to($user['email']);
					$this->email->subject('['.$data["website"]["name"].'] New password for '.$user['username']);
					$this->email->message($message);
					$this->email->send();
				$data['msg'] = 'A new password was sent to your email address. Please check your email.';
			}else{ 
                            $this->load->model('default/M_physician');
                            $physician = $this->M_user->getUserByEmail($email);
                            if(count($physician)){
                                    //set new password
                                    $new_password = $this->set_new_password();
                                    $this->M_user->saveResetPass($physician['physician_id'], base64_encode($new_password));

                                    //create email message 
                                    $message = "<h4>Dear ".$physician['firstname']." ".$physician['lastname'].",</h4>
                                    <p>You received this email because the Forgot Password Form has been submitted.</p>

                                    <p>
                                            Your access details are:
                                            <div style='background: #f9f9f9; border: 1px solid silver; padding: 20px; margin: 0'>
                                            <strong>Username:</strong> ".$physician['username']." <br />
                                            <strong>New password:</strong> ".$new_password."
                                            </div>
                                    </p>
                                    <p>
                                            You can now log in using your new access details. Please click this <a href='".base_url().index_page()."login/'>login</a> link
                                            or you may copy-paste the link below to your browser:<br />
                                            ".base_url().index_page()."login/index/
                                    </p>
                                    <p>
                                            Thank you.
                                    </p>
                                    <p>
                                            ".$data['website']['name']."<br />
                                            ".base_url()."
                                    </p>";
                                    //send email
                                            $config['mailtype'] = 'html';
                                            $this->email->initialize($config);
                                            $this->email->from('noreply@'.$_SERVER['HTTP_HOST'], $data['website']['name']);
                                            $this->email->to($physician['email']);
                                            $this->email->subject('['.$data["website"]["name"].'] New password for '.$physician['username']);
                                            $this->email->message($message);
                                            $this->email->send();
                                    $data['msg'] = 'A new password was sent to your email address. Please check your email.';
                            }else{
                                    $data['error'] = '<p style="color: #f93d3d; text-align:center; border: 1px solid #f93d3d; padding: 10px 0"><i>Cannot find the email address.</i></p>';

                            }
                        }
		}
                
                
		//parse template
                $data = array_merge($data, $this->view_data);
		$this->parser->parse(set_template($url_key), $data);
	}
	
	
	function set_new_password(){
		$new_password = random_string('alnum', 7);
		return $new_password;
	}
	

}


/* End of file forgot_password.php */
/* Location: ./application/controllers/admin/forgot_password.php */