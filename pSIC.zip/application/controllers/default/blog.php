<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Blog extends MY_Controller {

    protected $_form_data;

    function __construct() {
        parent::__construct();

        // Load the model and assign it to "blog" object.
        $this->load->model('default/m_blog', 'blog');
        $this->load->model('default/m_blog_category', 'blog_category');
        $this->load->model('default/m_blog_comment', 'blog_comment');
        $this->load->model('default/M_page');
        $this->load->helper('cs_blog');
        $this->load->helper('cs_news');
        $this->load->helper('cs_dropdown');
    }

    // --------------------------------------------------------------------

    /**
     * Default action. This action displays all blog which are available.
     */
    function index($page = 0, $blog_id = NULL) {
        // Get all blog so we know how to paginate.
        $blog = $this->blog->fetch_latest_blog();

        $this->view_data['blog_categories'] = $this->blog_category->fetch_all()->result();
        $this->view_data['blog_archive'] = $this->blog->fetch_archive()->result();
        $this->view_data['related_blog'] = $this->blog->fetch_latest_blog('2', '5')->result();
        $this->view_data['page'] = 'default/page/inner_page';

        if ($blog->num_rows() > 0) {
            $pagination['per_page'] = 5;
            $pagination['total_rows'] = $blog->num_rows();
            $pagination['uri_segment'] = 3;
            $this->load->library('CS_Url_Tree', null, 'tree');

            $this->tree->id_page = $this->view_data['id_page'];
            if ($this->uri->segment(2) == 'index') {
                $pagination['base_url'] = base_url() . index_page() . $this->tree->get_link() . '/index/' . $blog_id;
            } else {
                $pagination['base_url'] = 'aro-blog/index/' . $blog_id;
            }

            $this->paginate($pagination);

            $results = $this->blog->fetch_latest_blog($pagination['per_page'], $page);

            $this->view_data['blog'] = $results->result();
        } else {
            $this->view_data['blog'] = array();
        }

        //some page data
        $url_key = $this->get_current_module();

        $page = $this->M_page->get($url_key);
        $this->load->model('admin/M_website');
        $website = $this->M_website->getWebsite();

        $data['downloads'] = $this->M_download->get_downloads($page['id_page']);
        $data['content'] = $page['content'];
        $data['class'] = $page['class'];
        $data['robots'] = $website['meta_robots'];
        $data['keywords'] = $page['keywords'];
        $data['desc'] = $page['desc'];
        $data['site_title'] = $page['site_title'];
        $data['canonical'] = $page['canonical'];
        //set global meta data if page meta data is blank
        if ($page['site_title'] == '') {
            $data['site_title'] = $page['page_title'];
        }


        //set global meta data if page meta data is blank
        if ($page['keywords'] == '') {
            $data['keywords'] = $website['default_metakeywords'];
        }
        if ($page['desc'] == '') {
            $data['desc'] = $website['default_metadesc'];
        }

        $this->view_data = array_merge($data, $this->view_data);

        // Display the form.
        $this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $this->view_data);
    }

    // --------------------------------------------------------------------

    /**
     * Display a single blog item.     
     * 
     * @param string
     */
    function view($value = NULL, $value2 = NULL, $value3 = NULL) {

        if (is_null($value)) {
            redirect('page_not_found');
        }
       if($value =='index' && $this->uri->segment(3)!=''){
         $this->index($this->uri->segment(3), $blog_id = NULL);
       }elseif($value =='index' && $this->uri->segment(3)==''){
         $this->index();
       }

//echo $value;
//echo $value2;
//echo $value3;
$this->view_data['related_posts'] = array();
$value = str_replace("-","_",$value);
$value2 = str_replace("-","_",$value2);

        $type = '';
        $show_comment_form = false;
        if ($value2 != null) {
          if($value == 'tag'){
                $value = $value2;
                $type = 'tag';
                $blog = $this->blog->find_by_type($value, $type);
          }elseif($value=='author'){
                $value = $value2;
                $type = 'author';
                $blog = $this->blog->find_by_type($value, $type);

          }elseif($value=='category'){
                $value = $value2;
                $type = 'category';
                $blog = $this->blog->find_by_type($value, $type);

          }elseif($value=='archive'){
            $value = $value2 . '-' . $value3;
            $type = 'date';
            $blog = $this->blog->find_by_type($value, $type);

          }else{
            $value = $value . '-' . $value2;
            $type = 'date';
            $blog = $this->blog->find_by_type($value, $type);
          }

        } else {
            $value = urldecode($value);
            $type = 'title';
            $blog = $this->blog->find_by_type($value, $type);
            if ($blog->num_rows > 0) {
                $show_comment_form = true;
                $blog_data = $blog->result();
                foreach ($blog_data as $bd) {
                    $this->view_data['comment_array'] = $this->blog_comment->fetch_by_blog($bd->blog_id)->result();
                    $this->view_data['related_posts'] = $this->blog->fetch_related_posts($value)->result();
                }
            } else {
                $type = 'tag';
                $blog = $this->blog->find_by_type($value, $type);
                if ($blog->num_rows < 1) {
                    $type = 'author';
                    $blog = $this->blog->find_by_type($value, $type);
                    if ($blog->num_rows < 1) {
                        $type = 'category';
                        $blog = $this->blog->find_by_type($value, $type);
                    }
                }
            }
        }
        $this->view_data['show_comment_form'] = $show_comment_form;
        $this->view_data['blog_categories'] = $this->blog_category->fetch_all()->result();
        $this->view_data['blog_archive'] = $this->blog->fetch_archive()->result();
        //$this->view_data['related_posts'] = $this->blog->fetch_related_posts($value)->result();
        $this->view_data['related_blog'] = array();
        $this->view_data['page'] = 'default/page/inner_page';

        $this->view_data['blog'] = $blog->result();

        //some page data
        $url_key = $this->get_current_module();

        $page = $this->M_page->get($url_key);
        $this->load->model('admin/M_website');
        $website = $this->M_website->getWebsite();

        $data['downloads'] = $this->M_download->get_downloads($page['id_page']);
        $data['content'] = $page['content'];
        $data['class'] = $page['class'];
        $data['robots'] = $website['meta_robots'];
        $data['keywords'] = $page['keywords'];
        $data['desc'] = $page['desc'];
        $data['site_title'] = $page['site_title'];
        $data['canonical'] = $page['canonical'];
        //set global meta data if page meta data is blank
        if ($page['site_title'] == '') {
            $data['site_title'] = $page['page_title'];
        }


        //set global meta data if page meta data is blank
        if ($page['keywords'] == '') {
            $data['keywords'] = $website['default_metakeywords'];
        }
        if ($page['desc'] == '') {
            $data['desc'] = $website['default_metadesc'];
        }

        $this->view_data = array_merge($data, $this->view_data);

        // Display the form.
        $this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $this->view_data);
    }

    function post_comment() {

        if ($this->input->post('submit-axn') == 'submit') {
            $blog_id = $this->input->post('blog_id');
            $comment = $this->input->post('comment');
            $name = $this->input->post('name');
            $blog_url = $this->input->post('uri_string');
            if ($comment != '' && $name != '') {
                $_form_data = array(
                    'blog_id' => $blog_id,
                    'comment' => $comment,
                    'name' => $name
                );

                $this->blog_comment->do_save($_form_data);
            }
            redirect($blog_url);
        } else {
            redirect('aro-blog');
        }
    }

}

/* End of file blog.php */
/* Location: ./application/controllers/default/blog.php */
