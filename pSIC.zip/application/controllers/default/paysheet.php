<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Paysheet extends MY_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->helper('security');
		$this->load->model('admin/M_website');
		$this->load->model('default/M_paysheet_login');
		$this->load->model('default/M_paysheet');
		$this->load->helper('cs_template');
		$this->load->model('default/M_page');
	}

	function index()
	{
                if($this->session->userdata('logged_user')) 
                redirect(base_url(). '/forms');
		//set page data
		$data['title'] = 'Patient/Doctor Login';
                $data['sitename'] =$this->M_website->getName();;
		$data['website'] = $this->M_website->getWebsite();
		//get url key
		$url_key = $this->get_current_module(); 
		$data['page'] = 'default/paysheet/login';
		
		//parse template
                $data = array_merge($this->view_data, $data);
		$this->parser->parse(set_template($url_key), $data);
	}
	
	function do_login(){
		//set page data
		$data['title'] = 'Patient/Doctor Login';
                $data['sitename'] =$this->M_website->getName();;
		$data['website'] = $this->M_website->getWebsite();
		//get url key
		$url_key = $this->get_current_module(); 
		$data['page'] = 'default/paysheet/login';
		//process 
		$username = $this->input->post('username', TRUE);
		$password = $this->input->post('password', TRUE);
		
		$user = $this->M_paysheet_login->login($username, base64_encode($password));
		if(count($user)){
		    if($user['category'] != 'pending'){
	                    //check if premium user
	                    if($user['category'] == 'premium_membership'){
	                        $premium_user = TRUE;
	                    }else{
	                        $premium_user = FALSE;
	                    }
	                    
	                    $user_data = array(
	                    	    'user_id'     => $user['userid'],
	                            'id_paysheet' => $user['id_paysheet'],
	                            'username'    => $user['username'],
	                            'logged_user' => TRUE
	                    );
	                    
	                    $this->session->set_userdata($user_data);	                    
			    redirect('paysheet/view_sheet','refresh');
                    
                    }else{
                    	if($username && $password){
				$data['status_error'] = TRUE;
			}
			//parse template
			$data = array_merge($this->view_data, $data);
			$this->parser->parse(set_template($url_key), $data);  
                    
                    }
                    
		}else{
                    
                    $physician = $this->M_paysheet_login->loginPhysician($username, do_hash($password));
                    if(count($physician)){

                        $user_data = array(
                        	'user_id'     => $user['userid'],
                                'id_paysheet' => $physician['id_paysheet'],
                                'username' => $physician['username'],
                                'logged_user' => TRUE
                                
                        );
                        $this->session->set_userdata($user_data);
                        redirect(base_url());
                        //$this->view_paysheet();
                       // redirect(current_url());
                        
                    }else{
                       if($username && $password){
				$data['error'] = TRUE;
			}
			//parse template
			$data = array_merge($this->view_data, $data);
			$this->parser->parse(set_template($url_key), $data);  
                    }
		}
	}
	
	function logout(){
		$user_items = array('userid' => '', 'logged_user' => FALSE, 'user_type' => '');
		$this->session->unset_userdata($user_items);
		redirect('paysheet');
	}
	
	function view_sheet()
	{
                if(!$this->session->userdata('logged_user')) 
                redirect('paysheet');
		//set page data
		$data['title'] = 'Paysheet';
                $data['sitename'] =$this->M_website->getName();;
		$data['website'] = $this->M_website->getWebsite();
		//get url key
		$url_key = $this->get_current_module(); 
		$data['page'] = 'default/paysheet/view';
		$data['dataList'] = $this->M_paysheet->load_info($_SESSION['id_paysheet']);		
		
		//parse template
                $data = array_merge($this->view_data, $data);
		$this->parser->parse(set_template($url_key), $data);
	}
	
	function print_pdf()
	{
                if(!$this->session->userdata('logged_user')) 
                redirect('paysheet');
                
		$id = $this->uri->segment(3);
		$data['dataList'] = $this->M_paysheet->load_info($id);		

		//set page data
		$data['title'] = 'Paysheet';
                $data['sitename'] =$this->M_website->getName();;
		$data['website'] = $this->M_website->getWebsite();
		//get url key
		$url_key = $this->get_current_module(); 
		$data['page'] = 'default/paysheet/print_pdf';
		
		//parse template		
                $data = array_merge($this->view_data, $data);
		$this->parser->parse(set_template($url_key), $data);
	}
	
}

/* End of file login.php */
/* Location: ./application/controllers/admin/login.php */