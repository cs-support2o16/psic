<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Insurance_verification extends MY_Controller {

    protected $_form_data;

    function __construct()
    {
        parent::__construct();

        $this->load->helper('form');
    }

    // --------------------------------------------------------------------

    /**
     * Default action. Insurance verification form.
     */
    function index()
    {
        $this->load->helper('cs_dropdown');                               
	$this->_prep_form_values('validation_insurance_verification_form');    
	
        $captcha_value = $this->config->item('captcha-type')->setting_value; #FOR LIVE
        if($captcha_value === __RECAPTCHA__) 
        {
            $this->view_data['recaptcha'] = $this->load->view('recaptcha', array('recaptcha' => $this->recaptcha->get_html()), TRUE);
        } else if($captcha_value === __CAPTCHA_AYAH__) {
            $this->load->library('ayah');
            $this->view_data['recaptcha'] = $this->ayah->getPublisherHTML(); 
        }

        if ($this->input->post('submit') || $this->isAjax())
        {
            $this->load->model('default/m_insurance_verification');
            
            $captcha_value = $this->config->item('captcha-type')->setting_value; #FOR LIVE
            if($captcha_value === __RECAPTCHA__) {
                $this->view_data['recaptcha'] = $this->load->view('recaptcha', array('recaptcha'=> $this->recaptcha->get_html()), TRUE);
                // Add captcha validation to config.
                enable_recaptcha('validation_insurance_verification_form');
            } else if($captcha_value === __CAPTCHA_AYAH__) {
                $this->load->library('ayah');
                $this->require_validation();
                $this->form_validation->set_rules('recaptcha', 'recaptcha', 'required|callback_checkAYAHRecaptcha');
                #$this->view_data['recaptcha'] = $this->ayah->getPublisherHTML();
            }
            
            $id = $this->_save('validation_insurance_verification_form', $this->m_insurance_verification);
            
            if ($id)
            {
                // Send email to admin and person.
                $this->load->helper('cs_emails');
                
                if($this->_form_data['have_insurance'] == 1) {
                	$have_insurance = 'Yes';
                }else {
                	$have_insurance = 'No';
                }
                
                $this->_form_data['have_insurance'] = $have_insurance;
                // Send email to admin.
                $this->_form_data['date'] = date('F d, Y');
                
                send_email_template('insurance_verification_admin_notification', $this->get_setting('insurance_verification_email_recipient')->setting_value, null, $this->_form_data);
                // Send email to patient.
                send_email_template('insurance_verification_patient_confirmation',$this->_form_data['email'], null, $this->_form_data);                
            
                if ($this->isAjax())
                {
                    echo $id;
                    exit();
                }
                
                $this->session->set_flashdata('message', 'Your insurance verification request has been submitted.');
                
                redirect (current_url());            
            }
        }
        
        $url_key = $this->get_current_module();
        $this->load->model('default/M_page'); 
	$page = $this->M_page->get($url_key);
	$this->load->model('admin/M_website');
	$website = $this->M_website->getWebsite();
		
	$this->view_data['robots'] = $website['meta_robots'];			
	$this->view_data['keywords'] = $page['keywords'];
	$this->view_data['desc'] = $page['desc'];
			$this->view_data['site_title'] = $page['site_title'];
			
			//set global meta data if page meta data is blank
			if($page['site_title'] == ''){
				$this->view_data['site_title'] = $page['page_title'];
			}
	
	
	//set global meta data if page meta data is blank
	if($page['keywords'] == ''){
		$this->view_data['keywords'] = $website['default_metakeywords'];
	}
	if($page['desc'] == ''){
		$this->view_data['desc'] = $website['default_metadesc'];
	}
        	                     
                           
	$this->view_data['page'] = 'default/insurance_verification/edit';

    	$this->parser->parse('default/templates/' . $this->get_setting('inner_template'), $this->view_data);
    }

    // --------------------------------------------------------------------
}
/* End of file insurance_verification.php */
/* Location: ./application/controllers/default/insurance_verification.php */