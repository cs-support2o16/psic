<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Send_newsletter extends MY_Controller {

	function __construct()
	{
		parent::__construct();
                $this->load->library('email');
		$this->load->model('admin/M_newsletter');
		$this->load->model('admin/M_subscribers');
                $this->load->model('admin/M_website');
		$this->load->model('admin/M_administrator');
		$this->load->model('default/m_settings');
	}

	function index()
        {
       
            
            $quant = 400; // number of newsletters to send each time
            
            // are there any newsletters queued?
            if($this->M_newsletter->getQueuedNewsletters()->num_rows > 0)
            {
                
                $newsletter_pending = $this->M_newsletter->getQueuedNewsletterStatus('pending');
                
                // get the data of the FIRST item in queue
                if($newsletter_pending->num_rows > 0)
                {
                    $newsletterData = $this->M_newsletter->getFirstQueuedMailing('pending');
                }else{
                     $newsletterData = $this->M_newsletter->getFirstQueuedMailing('open');
                }

                $newsletterID = $newsletterData->id_newsletter;

                $subscribersList = $this->M_subscribers->getBatchNewsletterSubscribers('open');
                
                //get admin outgoing email
		$admin_email = $this->m_settings->get('admin_outgoing_email')->setting_value;
		$email_sender_from = ($admin_email) ? $admin_email : 'no-reply@'.strtolower(preg_replace('/\s/', '-', $sitename));
		$official_address = $this->m_settings->get('admin_official_address')->setting_value;
                
                if($subscribersList->num_rows > 0){
                    
                    $subscribers = $this->M_subscribers->getBatchNewsletterSubscribers('open', $quant);

                    foreach ($subscribers->result() as $address) {

                        $sitename = $this->M_website->getName();
                        $admin = $this->M_administrator->getSuperAdmin();
                        
			$newsletter_message = sprintf($newsletterData->body, base_url(), $address->subscription_key);
			$newsletter_body = str_replace('href="/ckfinder/userfiles', 'href="'.base_url().'ckfinder/userfiles', $newsletter_message);
				
			$newsletter_body = $newsletter_body. '<p style=" font-size: small; color: #999; line-height: normal; ">*Did not subscribe to this newsletter? Please <a href="'. base_url().index_page().'newsletter/unsubscribe/'.$address->subscription_key.'">unsubscribe</a> to remove your subscription.<br/>'.$official_address.'</p>'; 
				

                        $this->email->clear(TRUE); // clear anything that's already here
                        $config['mailtype'] = 'html';
                        $this->email->initialize($config);
                        $this->email->from($email_sender_from);
                        $this->email->to($address->email);
                        $this->email->subject($newsletterData->title);
                        $this->email->message($newsletter_body);
                        if(!empty($newsletterData->attachment)){
                                $file = str_replace('system/','',BASEPATH).'uploads/'.$newsletterData->attachment;
                                $this->email->attach($file);
                        }

                        $this->email->send();

                        //update subscribers status to sent
                        $this->M_subscribers->updateSubscribersStatus('sent', $address->id_subscriber);

                    }
                    
                    
                    if($subscribersList->num_rows > $quant){
                        
                        // update the newsletter status to pending  
                        $this->M_newsletter->updateNewsletterStatus('pending',$newsletterID);
                        
                    }else{
                        
                        // update the newsletter status to close  
                        $this->M_newsletter->updateNewsletterStatus('close',$newsletterID);
                        
                        if($this->M_newsletter->getQueuedNewsletterStatus('open')->num_rows > 0){
                            // update the subscribers status to open  
                            $this->M_subscribers->updateAllSubscribersStatus('open');
                        }else{
                            // update the subscribers status to close  
                            $this->M_subscribers->updateAllSubscribersStatus('close');
                        }
                    }
                
                }
                

            } // end check for queued newsletters
        }
}

/* End of file page_not_found.php */
/* Location: ./application/controllers/page_not_found.php */
