<?PHP
class Televoip_test extends MY_Controller {

    function __construct() {
        parent::__construct();
    }

    function index() {
	$this->load->model('televoips');
               echo $this->televoips->insert('813-541-1339');

	}
}