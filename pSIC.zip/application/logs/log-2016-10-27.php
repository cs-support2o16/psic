<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-10-27 08:27:08 --> Query error: MySQL server has gone away
ERROR - 2016-10-27 08:32:50 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /home/arorthopedics/public_html/application/views/default/templates/main.php 55
ERROR - 2016-10-27 08:44:40 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /home/arorthopedics/public_html/application/views/default/templates/main.php 55
ERROR - 2016-10-27 09:06:04 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /home/arorthopedics/public_html/application/views/default/templates/main.php 55
ERROR - 2016-10-27 09:32:54 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /home/arorthopedics/public_html/application/views/default/templates/main.php 55
