<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_ordering_manager extends CI_Model {

	function get_count(){
		return $this->db->count_all('contact_us');
	}
	
	function get($id){
		$data = array();
		$this->db->limit(1);
		$this->db->where('o_id', $id);
		$q = $this->db->get('ci_order');
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		$q->free_result();
		return $data;
	}
	
	function get_all($perpage, $offset){
		$data = array();
		$this->db->order_by('o_datereg', 'DESC');
		$this->db->limit($perpage,$offset);		
		$q = $this->db->get('ci_order');

		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$row['o_datereg'] = date('M d, Y', strtotime($row['o_datereg']));
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}
	
	function get_item($o_id)
	{
		$data = array();
		$this->db->order_by('oi_id', 'DESC');
		$this->db->where('o_id',$o_id);
		$q    = $this->db->get('ci_order_item');		
		
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}

		$q->free_result();
		return $data;
	}


	function delete($id){
		$this->db->where('o_id', $id);
		if($this->db->delete('ci_order')){
			
			$this->db->where('o_id',$id);
			$this->db->delete('ci_order_item');

			return TRUE;
		}else{
			return FALSE;
		}
	}

	function update_status($data)
	{
		$record = array("o_status" => $data['o_status']);

		$this->db->where('o_id',$data['o_id']);
		$this->db->update('ci_order',$record);
	}
	
}
/* End of file M_ordering_manager.php */
/* Location: ./application/models/admin/M_ordering_manager.php */