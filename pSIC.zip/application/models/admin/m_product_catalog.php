<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_product_catalog extends CI_Model 
{

    function fetch_all($limit = null, $offset = null, $alias = FALSE)
    {
        $this->db->order_by('p_id' . ' DESC');
        return $this->db->get('product_catalog', $limit, $offset);
    }



	function get_count(){
		return $this->db->count_all('download');
	}
	
	function get($id){
		$data = array();
		$this->db->where('p_id', $id);
		$this->db->limit(1);
		$q = $this->db->get('product_catalog');
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		return $data;
	}
	
	function get_all($perpage, $offset){
		$data = array();
		$this->db->limit($perpage,$offset);
		$this->db->join('ci_product_category','ci_product_catalog.p_category=ci_product_category.pc_id');		
		$q = $this->db->get('product_catalog');

		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$row['p_datereg'] = date('M d, Y; g:i A',strtotime($row['p_datereg']));
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}

	function get_all_category($perpage, $offset){
		$data = array();
		$this->db->limit($perpage,$offset);
		$q = $this->db->get('product_category');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$row['pc_datereg'] = date('M d, Y; g:i A',strtotime($row['pc_datereg']));
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}

	function insert($data){

		$data = array(
			'p_number' => $data['p_number'],
			'p_title' => $data['p_title'],
			'p_description' => $data['p_description'],
			'p_price' => $data['p_price'],
			'p_image' => $data['p_image'],
			'p_status' => 'ACTIVE',
			'p_category' => $data['p_category'],
			'p_datereg' => date('Y-m-d H:i:s')			
		);

		if($this->db->insert('product_catalog', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function update($post){            
		$data = array(
			'p_number'      => $post['p_number'],
			'p_title'       => $post['p_title'],
			'p_description' => $post['p_description'],
			'p_price' 	 	=> $post['p_price'],
			'p_image' 	 	=> $post['p_image'],
			'p_status' 	 	=> 'ACTIVE',
			'p_category' 	=> $post['p_category'],
			'p_subcategory'	=> $post['p_subcategory']
		);

		$this->db->where('p_id', $post['p_id']);
		if($this->db->update('product_catalog', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function delete($id){ 
		$this->db->where('p_id', $id);
		if($this->db->delete('product_catalog')){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function get_downloads($id_page){
		$downloads = array();
		$pages = $this->M_download_page_loc->getByPage($id_page);
		foreach($pages as $row){
			$downloads[] = $this->M_download->get($row['id_download']);
		}
		return $downloads;
	}


	function get_categories(){
		$data = array();
		$this->db->order_by('pc_category', 'ASC');
		$q = $this->db->get('product_category');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}

	function get_sub_spec_categories($cat_id){
		$data = array();
		$this->db->order_by('sub_name', 'ASC');
		$this->db->where('pc_id',$cat_id);
		$q = $this->db->get('product_subcategory');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}

	function get_image_name($id)
	{
		$image_name = "";
		
		$this->db->where('p_id',$id);
		$get_sql = $this->db->get('ci_product_catalog');

		foreach($get_sql->result() as $key => $values)
		{
			$image_name = $values->p_image;
		}
		#echo $id." ".$image_name."--";
		return $image_name;
	}

	function insert_category($data){

		$data = array(
			'pc_category' => strtoupper($data['pc_category']),
			'pc_datereg'  => date('Y-m-d H:i:s')			
		);

		if($this->db->insert('product_category', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}

	function delete_category($id){ 
		$this->db->where('pc_id', $id);
		if($this->db->delete('product_category')){
			return TRUE;
		}else{
			return FALSE;
		}
	}

	function get_category($id){
		$data = array();
		$this->db->where('pc_id', $id);
		$this->db->limit(1);
		$q = $this->db->get('product_category');
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		$q->free_result();
		return $data;
	}
	
	function update_category($post){
		$data = array(
			'pc_category' => strtoupper($post['pc_category'])
		);
		$this->db->where('pc_id', $post['pc_id']);
		if($this->db->update('product_category', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}

	#SUB CATEGORY
	function get_all_subcategory($perpage, $offset){
		$data = array();
		$this->db->limit($perpage,$offset);
		$this->db->join('product_category','product_category.pc_id=product_subcategory.pc_id');
		$q = $this->db->get('product_subcategory');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$row['sub_datereg'] = date('M d, Y; g:i A',strtotime($row['sub_datereg']));
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}

	function insert_subcategory($data){

		$data = array(
			'pc_id'			=> $data['pc_id'],
			'sub_name' 		=> strtoupper($data['sub_name']),
			'sub_datereg'   => date('Y-m-d H:i:s')			
		);

		if($this->db->insert('product_subcategory', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}

	function delete_subcategory($id){ 
		$this->db->where('sub_id', $id);
		if($this->db->delete('product_subcategory')){
			return TRUE;
		}else{
			return FALSE;
		}
	}

	function get_subcategory($id){
		$data = array();
		$this->db->where('sub_id', $id);
		$this->db->limit(1);
		$q = $this->db->get('product_subcategory');
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		$q->free_result();
		return $data;
	}

	function update_subcategory($post){
		$data = array(
			'pc_id'		=> $post['pc_id'],
			'sub_name'  => strtoupper($post['sub_name'])
		);

		$this->db->where('sub_id', $post['sub_id']);
		if($this->db->update('product_subcategory', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}


	#FOR DEFAULT

}

/* End of file m_download.php */
/* Location: ./application/models/admin/m_download.php */