<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_mri extends MY_Model {

    private $_table_name = 'mri';
    private $_primary_key = 'id_mri';

    public function  __construct() {
        parent::__construct();

        // Set the values for MY_Model::_table and MY_Model::_primary .
        $this->set_table_name($this->_table_name);
        $this->set_primary_key($this->_primary_key);
    }

    function get_count() {
        return $this->db->count_all('mri');
    }

    function get($id) {
        $data = array();
        $this->db->limit(1);
        $this->db->select(
                'mri.*, crm_status.code AS status, crm_status.description AS description, '
                . 'crm_note.note AS note, crm_note.attachment AS note_attachment', FALSE
        );
        $this->db->join('crm_status', 'crm_status.status_id = mri.status_id', 'left');
        $this->db->join('crm_note', 'crm_note.note_id = mri.note_id', 'left');
        $this->db->where('id_mri', $id);
        $q = $this->db->get('mri');
        if ($q->num_rows() > 0) {
            $data = $q->row_array();
        }
        $q->free_result();
        return $data;
    }
    
    function check_duplicate($params) {
        $data = array();
        $this->db->limit(1);
        $this->db->select(
                'mri.*, crm_status.code AS status, crm_status.description AS description, '
                . 'crm_note.note AS note, crm_note.attachment AS note_attachment', FALSE
        );
        $this->db->join('crm_status', 'crm_status.status_id = mri.status_id', 'left');
        $this->db->join('crm_note', 'crm_note.note_id = mri.note_id', 'left');
        
        
        $this->db->where("(lname = '". $params['lname']."' OR fname = '". $params['fname']. "')");
        $this->db->where('zip', $params['zip']);
        //$this->db->where('email', $params['email']);
        //$this->db->where('number', $params['number']);
        $q = $this->db->get('mri');
        if ($q->num_rows() > 0) {
            $data = $q->row_array();
        }
        $q->free_result();
        return $data;
    }

    function get_all($perpage = null, $offset = null, $order_by = 'capture_date', $is_mri = false) {
        $data = array();
        $this->db->select(
                'mri.*, crm_status.description AS description, crm_status.code AS status', FALSE
        );
        $this->db->join('crm_status', 'crm_status.status_id = mri.status_id', 'left');
        if($is_mri){
            $this->db->where("ci_mri.id_mri NOT IN (SELECT a.id_mri as id_mri FROM ci_mri a where a.source IN ('Contact Us', 'Blog Contact Us'))");
        }
        
        $order_by = ($order_by == '') ? 'capture_date' : ($order_by == 'status') ? 'crm_status.code' : $order_by;
        $order_direction = ($this->session->userdata('crm_ob_type') != '') ? $this->session->userdata('crm_ob_type') : 'DESC';
        $this->db->order_by($order_by, $order_direction);
        if($perpage != null){
        $this->db->limit($perpage, $offset);
        }
        $q = $this->db->get('mri');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $row['date_sent'] = date('M d, Y', strtotime($row['date_sent']));
                $data[] = $row;
            }
        }
        $q->free_result();
        
        return $data;
    }

    function multi_search($params, $perpage = null, $offset = null, $order_by = 'capture_date') {
        $data = array();
        $this->db->select(
                'mri.*, crm_status.code AS status, crm_status.description as description', FALSE
        );
        $this->db->join('crm_status', 'crm_status.status_id = mri.status_id', 'left');

        $order_by = ($order_by == '') ? 'capture_date' : ($order_by == 'status') ? 'crm_status.code' : $order_by;
        $order_direction = ($this->session->userdata('crm_ob_type') != '') ? $this->session->userdata('crm_ob_type') : 'DESC';
        $this->db->order_by($order_by, $order_direction);
        if ($perpage != null) {
            $this->db->limit($perpage, $offset);
        }
        if (count($params) > 0) {
            foreach ($params as $k => $v) {
                if ($k == 'fname' || $k == 'lname') {
                    $this->db->or_where($k . " LIKE '%" . $v. "%'");
                } else {
                    $this->db->or_where($k, $v);
                }
            }
        }
        $q = $this->db->get('mri');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $row['date_sent'] = date('M d, Y', strtotime($row['date_sent']));
                $data[] = $row;
            }
        }
        $q->free_result();
        return $data;
    }
    
    function lead_report() {
        $data = array();
        $this->db->select(
                'mri.status_id, crm_status.code AS status_code, COUNT(ci_mri.id_mri) AS lead_count, (COUNT(ci_mri.status_id)* 100 / (SELECT COUNT(*) FROM ci_mri)) AS percentage', FALSE
        );
        $this->db->join('crm_status', 'crm_status.status_id = mri.status_id', 'left');
        $this->db->group_by('mri.status_id');
        $q = $this->db->get('mri');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $data[] = $row;
            }
        }
        $q->free_result();
        return $data;
    }

    function delete($id) {
        $this->db->where('id_mri', $id);
        if ($this->db->delete('mri')) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    function do_save($data) {

        $data['date_sent'] = date('Y-m-d H:i:s');
        $data['date_updated'] = date('Y-m-d H:i:s');
        if ($this->db->insert('mri', $data)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    function do_merge($data) {


        $data['date_updated'] = date('Y-m-d H:i:s');
        $this->db->where('id_mri', $data['id_mri']);
        if ($this->db->update('mri', $data)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
    
    function find_deleted_items($deleted_pages) {
        $data = array();

        $this->db->where_in('id_mri', $deleted_pages);
        $q = $this->db->get('mri');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $data[$row['id_mri']] = $row['fname'] . ' ' . $row['lname'];
            }
        }
        $q->free_result();
        return $data;
    }

    function export() {
        $data = array();
	$website = $this->M_website->getName();
        $this->db->select("mri.capture_date AS 'Lead Captured Date', mri.fname AS 'First Name', mri.lname AS 'Last Name', mri.number AS 'Phone Number', mri.email AS 'Email Address', mri.zip AS 'Zip Code', crm_status.code AS Status");
        $this->db->join("crm_status", "crm_status.status_id = mri.status_id", "left");
        $q = $this->db->get("mri");
	query_to_csv($q, TRUE, $website."-MRI.csv");

        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                //$row['capture_date'] = date('M d, Y', strtotime($row['capture_date']));
                $data[] = $row;
            }
        }
        $q->free_result();
        return $data;
    }

    function export_options($params) {
	$website = $this->M_website->getName();
        $data = array();
        $this->db->select("mri.capture_date AS 'Lead Captured Date', mri.fname AS 'First Name', mri.lname AS 'Last Name', mri.number AS 'Phone Number', mri.email AS 'Email Address', mri.zip AS 'Zip Code', crm_status.code AS Status");
        $this->db->join("crm_status", "crm_status.status_id = mri.status_id", "left");
        $this->db->order_by('capture_date', 'DESC');

        if (count($params) > 0) {
            foreach ($params as $k => $v) {
                if ($k == 'capture_from') {
                    $this->db->where('capture_date >= ',$v);
                } elseif($k == 'capture_to') {
                    $this->db->where('capture_date <= ',$v);
                } elseif($k=='capture_from' && $k=='capture_to') {
                    $this->db->where('capture_date >= ',$v);
                    $this->db->where('capture_date <= ',$v);
                }elseif ($k == 'modified_date_from') {
                    $this->db->where('mri.date_updated >= ',$v);
                } elseif($k == 'modified_date_to') {
                    $this->db->where('mri.date_updated <= ',$v);
                } elseif($k=='modified_date_from' && $k=='modified_date_to') {
                    $this->db->where('mri.date_updated >= ',$v);
                    $this->db->where('mri.date_updated <= ',$v);
                }elseif ($k == 'zip_from') {
                    $this->db->where('mri.zip >= ',$v);
                } elseif($k == 'zip_to') {
                    $this->db->where('mri.zip <= ',$v);
                } elseif($k=='zip_from' && $k=='zip_to') {
                    $this->db->where('mri.zip >= ',$v);
                    $this->db->where('mri.zip <= ',$v);
                }elseif ($k == 'lname') {
                    $this->db->where('lname', $v);
                }else{
                    $this->db->where($k . " LIKE '%" . $v. "%'");
               }
            }
        }
        $q = $this->db->get('mri');
        if ($q->num_rows() > 0) {
	  query_to_csv($q, TRUE, $website."-MRI.csv");
        }
        $q->free_result();

    } 

    public function contacted($id)
    {
		$data = array(
			'contacted' => 1
		);
		$this->db->where('id_mri', $id);
		if($this->db->update('mri', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
    } 

    function get_all_contacted($perpage = null, $offset = null) {
        $data = array();
        $this->db->select(
                'mri.*', FALSE
        );
	$this->db->where('contacted', 1);
       if($perpage!= null || $offset != null){
        $this->db->limit($perpage, $offset);
       }else{
        $this->db->limit(1);
       }
        $q = $this->db->get('mri');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $row['date_sent'] = date('M d, Y', strtotime($row['date_sent']));
                $data[] = $row;
            }
        }
        $q->free_result();
        return $data;
    }

    function get_all_uncontacted($perpage, $offset, $order_by = 'capture_date') {
        $data = array();
        $this->db->select(
                'mri.*, crm_status.description AS description, crm_status.code AS status', FALSE
        );
        $this->db->join('crm_status', 'crm_status.status_id = mri.status_id', 'left');
	$this->db->where_not_in('contacted', 1);
        $order_by = ($order_by == '') ? 'capture_date' : ($order_by == 'status') ? 'crm_status.code' : $order_by;
        $order_direction = ($this->session->userdata('crm_ob_type') != '') ? $this->session->userdata('crm_ob_type') : 'DESC';
        $this->db->order_by($order_by, $order_direction);
        $this->db->limit($perpage, $offset);
        $q = $this->db->get('mri');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $row['date_sent'] = date('M d, Y', strtotime($row['date_sent']));
                $data[] = $row;
            }
        }
        $q->free_result();
        return $data;
    }

	function import_record($data)
	{	
		#SEARH FIRST IF DUPLICATE
		$this->db->where('fname',$data['fname']);
		$this->db->where('lname',$data['lname']);
		$q = $this->db->get('ci_mri');

		foreach($q->result() as $r => $v)
		{
			$update_id = $v->d_id;
		}

		if($this->db->affected_rows()<=0)
		{			
			/**

			#######INSERT NEW RECORD

			**/
			$data_primary = array(
					"fname" 			=> $data['fname'],
					"lname" 			=> $data['lname'],
					"email" 			=> $data['email'],

					"number" 		=> $data['number'],
					"zip" 			=> $data['zip'],

					"status_id" 			=> 1,
					"status_flag" => 0,
					"note_id" 	=> "",
					"comment" 	=> "",
					"attachment" => "",
					"s_update_by" => $this->session->userdata('id_admin'),

					"s_update_date" => date("Y-m-d H:i:s"),
					"capture_date"  	=> $data['capture_date'],
					
					"date_sent" 			=> date("Y-m-d H:i:s"),
					"date_updated" 			=> date("Y-m-d H:i:s")
			);	
			$this->db->insert("ci_mri",$data_primary);
			$last_id = $this->db->insert_id();

		}else{
			/**
			#######UPDATE EXISTING RECORD
			**/
			$data_primary = array(
					"fname" 			=> $data['fname'],
					"lname" 			=> $data['lname'],
					"email" 			=> $data['email'],

					"number" 		=> $data['number'],
					"zip" 			=> $data['zip'],

					"status_id" => 1,
					"status_flag" => 0,
					"note_id" 	=> "",
					"comment" 	=> "",
					"attachment" => "",
					"s_update_by" => $this->session->userdata('id_admin'),

					"s_update_date" => date("Y-m-d H:i:s"),
					"capture_date"  => $data['capture_date'],
					
					"date_sent" => date("Y-m-d H:i:s"),
					"date_updated" => date("Y-m-d H:i:s")
			);	
			$this->db->where('fname',$data['fname']);
			$this->db->where('lname',$data['lname']);
			$this->db->update("ci_mri",$data_primary);

		}		

	}

}

/* End of file m_mri.php */
/* Location: ./application/models/admin/m_mri.php */