<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_modules extends CI_Model {

	function getAllModules(){
		$data = array();
		$this->db->order_by('order', 'ASC');
		$q = $this->db->get('modules');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}
	
	function getActivatedModules($role){
            $module_id = array('26');
		$data = array();
		$this->db->where('activated', 1);
              if($role=='staff'){
		$this->db->where_not_in('id_module', $module_id);
              }
		$this->db->order_by('name', 'ASC');
		$q = $this->db->get('modules');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}

}


/* End of file m_modules.php */
/* Location: ./application/models/admin/m_modules.php */
