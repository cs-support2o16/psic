<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_subscribers extends MY_Model {

	function __construct()
        {
        	$this->set_table_name('subscribers');
       		$this->set_primary_key('id_subscriber');
        }

	function insert($data){
		$data = array(
			'fname' => $data['fname'],
			'lname' => $data['lname'],
			'email' => $data['email'],
			'active' => 1,
			'subscription_key' => $data['subscription_key']
			
		);
		if($this->db->insert('subscribers', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function update($data){
		$subscriberData = array(
			'fname' => $data['fname'],
			'lname' => $data['lname'],
			'email' => $data['email'],
			'subscription_key' => $data['subscription_key']
			
		);
		$this->db->where('id_subscriber', $data['id_subscriber']);
		if($this->db->update('subscribers', $subscriberData)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function unsubscribe($id){
		$subscriberData = array(
			'active' => 0
		);
		$this->db->where('id_subscriber', $id);
		if($this->db->update('subscribers', $subscriberData)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function subscribe($id){
		$subscriberData = array(
			'active' => 1
		);
		$this->db->where('id_subscriber', $id);
		if($this->db->update('subscribers', $subscriberData)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function get_all($perpage,$offset){
		$data = array();
		$this->db->limit($perpage,$offset);
		$q = $this->db->get('subscribers');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}
	
	function get_count(){
		return $this->db->count_all('subscribers');
	}
	
	function get($id){
		$data = array();
		$this->db->limit(1);
		$this->db->where('id_subscriber', $id);
		$q = $this->db->get('subscribers');
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		$q->free_result();
		return $data;
	}
	
	function delete($id){
		$this->db->where('id_subscriber', $id);
		if($this->db->delete('subscribers')){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function get_subscribers(){
		$data = array();
		$this->db->where('active', 1);
		$q = $this->db->get('subscribers');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}
	
	function import($data){
	
		if(count($data) == 1) {
			$email = $data[0];
			$fname = '';
			$lname = '';
		}else{
			$fname = (isset($data[0])) ? $data[0] : '';
			$lname = (isset($data[1])) ? $data[1] : '';
			$email = (isset($data[2])) ? $data[2] : '';
		}

		$data = array(
			'fname' => $fname,
			'lname' => $lname,
			'email' => $email,
			'active' => 1
		);
		
		if($email == null || $email == ''){
			return FALSE;
		}else{
			if($this->db->insert('subscribers', $data)){
				return TRUE;
			}else{
				return FALSE;
			}
		}
	}

	
	function getByEmail($email){
		$data = array();
		$q = $this->db->get_where('subscribers', array('email' => $email), 1);
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		$q->free_result();
		return $data;
	}
	
	function do_subscribe($subscription_key){
		$subscriberData = array(
			'active' => 1
		);
		$this->db->where('subscription_key', $subscription_key);
		if($this->db->update('subscribers', $subscriberData)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function updateAllSubscribersStatus($status){
		$subscriberData = array(
			'status' => $status
			
		);
                $this->db->where('active', '1');
		if($this->db->update('subscribers', $subscriberData)){
			return TRUE;
		}else{
			return FALSE;
		}
	}

	function getBatchNewsletterSubscribers($status, $quant = 0)
        {
            $this->db->where('active', '1');
            if($quant != '0'){
                $this->db->limit($quant, 0);
            }
            $this->db->where('status', $status);
            return $this->db->get('subscribers'); 
        }

	function updateSubscribersStatus($status, $id){
		$subscriberData = array(
			'status' => $status
			
		);
                $this->db->where('active', '1');
		$this->db->where('id_subscriber', $id);
		if($this->db->update('subscribers', $subscriberData)){
			return TRUE;
		}else{
			return FALSE;
		}
	}

        function find_deleted_items($deleted) {
            $data = array();

            $this->db->where_in('id_subscriber', $deleted);
            $q = $this->db->get('subscribers');
            if ($q->num_rows() > 0) {
                foreach ($q->result_array() as $row) {
                    $data[$row['id_subscriber']] = $row['email'];
                }
            }
            $q->free_result();
            return $data;
        }
	
}



/* End of file m_subscribers.php */
/* Location: ./application/models/admin/m_subscribers.php */