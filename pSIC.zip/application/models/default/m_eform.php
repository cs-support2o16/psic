<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_eform extends MY_Model {

	function __construct()
        {
            parent::__construct();

            $this->set_table_name('eform');
            $this->set_primary_key('id_eform');
        }

	function get_count(){
		return $this->db->count_all('eform');
	}
	
	function get($id){
		$data = array();
		$this->db->where('id_eform', $id);
		$this->db->limit(1);
		$q = $this->db->get('eform');
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		return $data;
	}
	
	function get_all($perpage, $offset){
		$data = array();
		$this->db->limit($perpage,$offset);
		$q = $this->db->get('eform');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$row['date_posted'] = date('M d, Y g:i A',strtotime($row['date_posted']));
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}
	
	function getByFormType($form_type){
		$data = array();
                $this->db->where('eform_type', $form_type);
                $this->db->limit(1);
		$q = $this->db->get('eform');
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		return $data;
	}

	
	function insert($data){
		$data = array(
			'title' => $data['title'],
			'date_posted' => date('Y-m-d H:i:s')
		);
		if($this->db->insert('eform', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function update($post){            
		$data = array(
			'title' => $post['title']
		);
		$this->db->where('id_eform', $post['id_eform']);
		if($this->db->update('eform', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function delete($id){ 
		$this->db->where('id_eform', $id);
		if($this->db->delete('eform')){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
}

/* End of file m_eform.php */
/* Location: ./application/models/admin/m_eform.php */