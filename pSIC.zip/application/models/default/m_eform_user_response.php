<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_eform_user_response extends CI_Model {

	function get_count(){
		return $this->db->count_all('eform_user_response');
	}
	
	function get($id){
		$data = array();
		$this->db->where('id', $id);
		$this->db->limit(1);
		$q = $this->db->get('eform_user_response');
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		return $data;
	}
	
	function getByFormType($id, $userId){
		$data = array();
		$this->db->where('id_eform', $id);
		$this->db->where('user_id', $userId);
		$this->db->limit(1);
		$q = $this->db->get('eform_user_response');
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		return $data;
	}
	
	function findByTpe($typeId){
		$data = array();
                $this->db->where('id_eform', $typeId);
		$q = $this->db->get('eform_user_response');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}
                $q->free_result();
		return $data;
	}
	
	function searchByType($value, $limit = null, $offset = null)
	    {
	        $this->db->where('eform.id_eform', $value);
	
	        return self::get_all($limit, $offset);
	    }
	
	
	function get_all($perpage, $offset){
		$data = array();
		$this->db->limit($perpage,$offset);
		$this->db->select(
                '*, eform_user_response.date_posted AS logs_date_posted',
                FALSE
                );
		$this->db->join('eform', 'eform.id_eform = eform_user_response.id_eform', 'left');
		$q = $this->db->get('eform_user_response');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$row['date_posted'] = date('M d, Y g:i A',strtotime($row['date_posted']));
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}
        
        function insert($post){
                        
		$data = array(
                        'id_eform' => $post['id_eform'],
                        'user_id' => $post['user_id'],
			'patient_name' => $post['patient_name'],
			'patient_age' => $post['patient_age'],
			'patient_dob' => $post['patient_dob'],
			'file_name' => $post['file_name'],
			'date_posted' => date('Y-m-d H:i:s'),
		);
		if($this->db->insert('eform_user_response', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function update($post){            
		$data = array(
			'patient_name' => $post['patient_name'],
			'patient_age' => $post['patient_age'],
			'patient_dob' => $post['patient_dob'],
                        'date_posted' => date('Y-m-d H:i:s'),
		);
		$this->db->where('id_eform', $post['id_eform']);
		$this->db->where('user_id', $post['user_id']);
		if($this->db->update('eform_user_response', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function delete($id){ 
		$this->db->where('id', $id);
		if($this->db->delete('eform_user_response')){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
}

/* End of file m_eform_user_response.php */
/* Location: ./application/models/admin/m_eform_user_response.php */