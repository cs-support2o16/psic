<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_admin_action extends MY_Model {

        function __construct()
        {
            parent::__construct();

            $this->set_table_name('admin_action');
            $this->set_primary_key('admin_action_id');
        }
        
        function get_last_activity_date($admin_login_id = null){
		$data = array();
                $date_created = '';
                $this->db->select(
                'admin_action.date_created as date_created',
                FALSE
                );
                $where = 'admin_action.date_created =(SELECT MAX(b.date_created) FROM ci_admin_action b WHERE b.admin_login_id = ci_admin_action.admin_login_id )';
                $this->db->where($where);
                $this->db->join('admin', 'admin.id_admin = admin_action.id_admin', 'left');
                $this->db->where('admin_action.admin_login_id', $admin_login_id);
		$q = $this->db->get('admin_action');
                if($q->num_rows() > 0){
			$data = $q->row_array();
                        $date_created = $data['date_created'];
		}
		$q->free_result();
		return $date_created;
	}
        function find_by_admin_login($admin_login_id = null, $filter_data = null, $perpage = NULL, $offset = NULL){
		$data = array();
                $this->db->select(
                'admin_action.*, admin.username AS username',
                FALSE
                );
                $this->db->join('admin', 'admin.id_admin = admin_action.id_admin', 'left');
                if($admin_login_id != null){
                    $this->db->where('admin_action.admin_login_id', $admin_login_id);
                }
                if($filter_data != null){
                    
                    if(isset($filter_data['filter_module']) && $filter_data['filter_module'] != ''){
                        $this->db->where('admin_action.module', $filter_data['filter_module']);
                    }
                 
                    $filter_from = (isset($filter_data['filter_from'])) ? $filter_data['filter_from'] : '';
                    $filter_to = (isset($filter_data['filter_to'])) ? $filter_data['filter_to'] : '';
                    
                    if($filter_from != '' && $filter_to != ''){
                        $this->db->where("DATE_FORMAT(ci_admin_action.date_created,'%Y-%m-%d') BETWEEN '".date('Y-m-d', strtotime($filter_from))."' AND '".date('Y-m-d', strtotime($filter_to))."' ");
                    }else{
                        if($filter_from != '' ){
                            $this->db->where("DATE_FORMAT(ci_admin_action.date_created,'%Y-%m-%d')", date('Y-m-d', strtotime($filter_from)));
                        }
                        if($filter_to != '' ){
                            $this->db->where("DATE_FORMAT(ci_admin_action.date_created,'%Y-%m-%d')", date('Y-m-d', strtotime($filter_to)));
                        }
                    }
                    
                }
                if (!is_null($perpage) && !is_null($offset))
		{
                    $this->db->limit($perpage,$offset);
                }
                 $this->db->order_by('admin_action.date_created','DESC');
		$q = $this->db->get('admin_action');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}
        
       

}

/* End of file m_admin_action.php */
/* Location: ./application/models/default/m_admin_action.php */