<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_admin_login extends MY_Model {

        function __construct()
        {
            parent::__construct();

            $this->set_table_name('admin_login');
            $this->set_primary_key('admin_login_id');
        }
        
        function find_missing_logout_date($id_admin = null){
		$data = array();
                $this->db->select(
                'admin_login.*, admin.username AS username',
                FALSE
                );
                $this->db->join('admin', 'admin.id_admin = admin_login.id_admin', 'left');
                if($id_admin != null){
                    $this->db->where('admin_login.id_admin', $id_admin);
                }
                $this->db->where('logout_date IS NULL');
		$q = $this->db->get('admin_login');
		if($q->num_rows() > 0){
                    foreach($q->result_array() as $row){
                            $data[] = $row;
                    }
		}
		$q->free_result();
		return $data;
	}
        
        function fetch_recent_logs($id_admin = null, $filter_data = null){
		$data = array();
                $this->db->select(
                'admin_login.*, admin.username AS username',
                FALSE
                );
                $this->db->join('admin', 'admin.id_admin = admin_login.id_admin', 'left');
                if($id_admin != null){
                    $this->db->where('admin_login.id_admin', $id_admin);
                }
                $where = 'admin_login.login_date =(SELECT MAX(b.login_date) FROM ci_admin_login b WHERE b.id_admin = ci_admin_login.id_admin )';
                $this->db->where($where);
                if($filter_data != null){
                    if(isset($filter_data['filter_username']) && $filter_data['filter_username'] != ''){
                        $this->db->where('admin.username', $filter_data['filter_username']);
                    }
                    
                    $filter_from = (isset($filter_data['filter_from'])) ? $filter_data['filter_from'] : '';
                    $filter_to = (isset($filter_data['filter_to'])) ? $filter_data['filter_to'] : '';
                    
                    if($filter_from != '' && $filter_to != ''){
                        $this->db->where("DATE_FORMAT(ci_admin_login.login_date,'%Y-%m-%d') BETWEEN '".date('Y-m-d', strtotime($filter_from))."' AND '".date('Y-m-d', strtotime($filter_to))."' ");
                    }else{
                        if($filter_from != '' ){
                            $this->db->where("DATE_FORMAT(ci_admin_login.login_date,'%Y-%m-%d')", date('Y-m-d', strtotime($filter_from)));
                        }
                        if($filter_to != '' ){
                            $this->db->where("DATE_FORMAT(ci_admin_login.login_date,'%Y-%m-%d')", date('Y-m-d', strtotime($filter_to)));
                        }
                    }
                    
                }
                $this->db->group_by('admin_login.id_admin'); 
		$q = $this->db->get('admin_login');
		if($q->num_rows() > 0){
                    $subdata = array();
                    $subids = array();
			foreach($q->result_array() as $row){
				$subdata[] = $row;
                                $subids[] = $row['admin_login_id'];
			}
                    $data['data'] = $subdata;
                    $data['ids'] = $subids;
		}
		$q->free_result();
		return $data;
	}
        
        
        function fetch_previous_logs($id_admin = NULL, $filter_data = NULL, $perpage = NULL, $offset = NULL){
		$data = array();
                $this->db->select(
                'admin_login.*, admin.username AS username',
                FALSE
                );
                $this->db->join('admin', 'admin.id_admin = admin_login.id_admin', 'left');
                if($id_admin != null){
                    $this->db->where('admin_login.id_admin', $id_admin);
                }
                if($filter_data != null){
                    if(isset($filter_data['filter_username']) && $filter_data['filter_username'] != ''){
                        $this->db->where('admin.username', $filter_data['filter_username']);
                    }
                    
                    $filter_from = (isset($filter_data['filter_from'])) ? $filter_data['filter_from'] : '';
                    $filter_to = (isset($filter_data['filter_to'])) ? $filter_data['filter_to'] : '';
                    
                    if($filter_from != '' && $filter_to != ''){
                        $this->db->where("DATE_FORMAT(ci_admin_login.login_date,'%Y-%m-%d') BETWEEN '".date('Y-m-d', strtotime($filter_from))."' AND '".date('Y-m-d', strtotime($filter_to))."' ");
                    }else{
                        if($filter_from != '' ){
                            $this->db->where("DATE_FORMAT(ci_admin_login.login_date,'%Y-%m-%d')", date('Y-m-d', strtotime($filter_from)));
                        }
                        if($filter_to != '' ){
                            $this->db->where("DATE_FORMAT(ci_admin_login.login_date,'%Y-%m-%d')", date('Y-m-d', strtotime($filter_to)));
                        }
                    }
                    
                }
                if (!is_null($perpage) && !is_null($offset))
		{
                    $this->db->limit($perpage,$offset);
                }
                 $this->db->order_by('admin_login.login_date','DESC');
		$q = $this->db->get('admin_login');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}
        
        function save_missing_logout_date($admin_login_id, $logout_date){
                $this->db->where('admin_login_id', $admin_login_id);
                if($this->db->update('ci_admin_login', array('logout_date' => $logout_date))){
                        return TRUE;
                }else{
                        return FALSE;
                }
	}
	
	function update_logged_in($admin_login_id){
                $this->db->where('admin_login_id', $admin_login_id);
                if($this->db->update('ci_admin_login', array('logout_date' => '0000-00-00 00:00:00'))){
                        return TRUE;
                }else{
                        return FALSE;
                }
	}
}

/* End of file m_admin_login.php */
/* Location: ./application/models/default/m_admin_login.php */