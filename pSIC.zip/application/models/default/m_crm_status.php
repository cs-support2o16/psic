<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_crm_status extends MY_Model {

    function __construct() {
        parent::__construct();

        $this->set_table_name('crm_status');
        $this->set_primary_key('status_id');
    }
    
    function get($id) {
        $data = array();
        $this->db->limit(1);
        $this->db->where('status_id', $id);
        $q = $this->db->get('crm_status');
        if ($q->num_rows() > 0) {
            $data = $q->row_array();
        }
        $q->free_result();
        return $data;
    }

    function do_save($params) {
        
        if (!isset($params['status_id'])) {
            $params['date_posted'] = date('Y-m-d H:i:s');
        }            
        $params['date_updated'] = date('Y-m-d H:i:s');
        
        return parent::do_save($params);
    }
    
    function fetch_all($limit = null, $offset = null, $alias = FALSE) {
        
        $this->db->order_by('code', 'asc');
        return parent::fetch_all($limit, $offset, $alias);
    }
    
    function find_deleted_items($deleted_pages) {
        $data = array();

        $this->db->where_in('status_id', $deleted_pages);
        $q = $this->db->get('crm_status');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $data[$row['status_id']] = $row['code'];
            }
        }
        $q->free_result();
        return $data;
    }

}

/* End of file m_crm_status.php */
/* Location: ./application/models/default/m_crm_status.php */