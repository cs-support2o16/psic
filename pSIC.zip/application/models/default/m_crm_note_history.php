<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_crm_note_history extends MY_Model {

    function __construct() {
        parent::__construct();

        $this->set_table_name('crm_note_history');
        $this->set_primary_key('note_history_id');
    }

    function do_save($params) {
        if (!isset($params['crm_note_history'])) {
            $params['date_posted'] = date('Y-m-d H:i:s');
        }
        return parent::do_save($params);
    }
    
    function find_by_note($note_id, $perpage = null, $offset = null) {
        $data = array();
        $this->db->select(
                'crm_note_history.*, admin.username AS username', FALSE
        );
        $this->db->join('admin', 'admin.id_admin = crm_note_history.posted_by', 'left');
        if($perpage != null){
        $this->db->limit($perpage, $offset);
        }
        $this->db->where('crm_note_history.note_id', $note_id);
        $this->db->order_by('crm_note_history.date_posted', 'desc');
        $q = $this->db->get('crm_note_history');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $data[] = $row;
            }
        }
        $q->free_result();
        return $data;
    }

}

/* End of file m_crm_note_history.php */
/* Location: ./application/models/default/m_crm_note_history.php */