<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_crm_note extends MY_Model {

    function __construct() {
        parent::__construct();

        $this->set_table_name('crm_note');
        $this->set_primary_key('note_id');
    }

    function do_save($params) {
        
        if (!isset($params['note_id'])) {
            $params['date_posted'] = date('Y-m-d H:i:s');
        }            
        $params['date_updated'] = date('Y-m-d H:i:s');
        
        return parent::do_save($params);
    }

}

/* End of file m_crm_note.php */
/* Location: ./application/models/default/m_crm_note.php */