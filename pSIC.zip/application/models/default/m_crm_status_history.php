<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_crm_status_history extends MY_Model {

    function __construct() {
        parent::__construct();

        $this->set_table_name('crm_status_history');
        $this->set_primary_key('status_history_id');
    }

    function do_save($params) {
        if (!isset($params['crm_status_history'])) {
            $params['date_posted'] = date('Y-m-d H:i:s');
        }
        return parent::do_save($params);
    }

    function find_by_lead($id_mri, $perpage = null, $offset = null) {
        $data = array();
        $this->db->select(
                'crm_status_history.*, mri.fname AS fname, mri.lname AS lname, crm_status.code AS status, admin.username AS username', FALSE
        );
        $this->db->join('crm_status', 'crm_status.status_id = crm_status_history.status_id', 'left');
        $this->db->join('admin', 'admin.id_admin = crm_status_history.posted_by', 'left');
        $this->db->join('mri', 'mri.id_mri = crm_status_history.id_mri', 'left');
        if($perpage != null){
        $this->db->limit($perpage, $offset);
        }
        $this->db->where('crm_status_history.id_mri', $id_mri);
        $this->db->order_by('crm_status_history.date_posted', 'desc');
        $q = $this->db->get('crm_status_history');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $data[] = $row;
            }
        }
        $q->free_result();
        return $data;
    }
    
    function find_all($perpage = null, $offset = null) {
        $data = array();
        $this->db->select(
                'crm_status_history.*, mri.fname AS fname, mri.lname AS lname, crm_status.code AS status, admin.username AS username', FALSE
        );
        $this->db->join('crm_status', 'crm_status.status_id = crm_status_history.status_id', 'left');
        $this->db->join('admin', 'admin.id_admin = crm_status_history.posted_by', 'left');
        $this->db->join('mri', 'mri.id_mri = crm_status_history.id_mri', 'left');
        if($perpage != null){
        $this->db->limit($perpage, $offset);
        }
        $this->db->order_by('crm_status_history.date_posted', 'desc');
        $q = $this->db->get('crm_status_history');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $data[] = $row;
            }
        }
        $q->free_result();
        return $data;
    }
}

/* End of file m_crm_status_history.php */
/* Location: ./application/models/default/m_crm_status_history.php */