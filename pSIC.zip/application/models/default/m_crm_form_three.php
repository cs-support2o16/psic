<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_crm_form_three extends MY_Model {

    function __construct() {
        parent::__construct();

        $this->set_table_name('crm_form_three');
        $this->set_primary_key('crm_form_three_id');
    }

    function do_save($params) {
        
        if (!isset($params['crm_form_three_id'])) {
            $params['date_posted'] = date('Y-m-d H:i:s');
        }     
        return parent::do_save($params);
    }
    

}

/* End of file m_crm_status.php */
/* Location: ./application/models/default/m_crm_status.php */