<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Model for interacting with the "blog_comment" table.
 *
 */
class M_blog_comment extends MY_Model {

    private $_table_name = 'blog_comment';
    private $_primary_key = 'blog_comment_id';

    public function __construct() {
        parent::__construct();

        // Set the values for MY_Model::_table and MY_Model::_primary .
        $this->set_table_name($this->_table_name);
        $this->set_primary_key($this->_primary_key);
    }
    
    function fetch_by_blog($blog_id) {
        
        $this->db->where('blog_id', $blog_id);
        $this->db->order_by('date_posted DESC');
        return parent::fetch_all();
    }
    

    /**
     * Override so we can set date_posted.
     */
    function do_save($params) {

        if (!isset($params['blog_comment_id'])) {
            $params['date_posted'] = date('Y-m-d H:i:s');
        } 
        return parent::do_save($params);
    }

}

/* End of file m_event_category.php */
/* Location: ./application/models/default/m_event_category.php */
