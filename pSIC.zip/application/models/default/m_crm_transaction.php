<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_crm_transaction extends MY_Model {

    function __construct() {
        parent::__construct();

        $this->set_table_name('crm_transaction');
        $this->set_primary_key('crm_transaction_id');
    }
    
    function find_recent() {
        $data = array();
        $this->db->select(
                'crm_transaction.*, admin.username AS username, user.username AS cc_username', FALSE
        );
        $this->db->join('admin', 'admin.id_admin = crm_transaction.id_admin', 'left');
        $this->db->join('user', 'user.user_id = crm_transaction.id_admin', 'left');
        $this->db->order_by('date_created', 'desc');
        $this->db->limit('3', '0');
        $q = $this->db->get('crm_transaction');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $data[] = $row;
            }
        }
        $q->free_result();
        return $data;
    }
    
    function find_all($order_by = null, $perpage = null, $offset = null) {
        $data = array();
        $this->db->select(
                "crm_transaction.*, admin.username AS username, user.username AS cc_username, DATE_FORMAT(ci_crm_transaction.date_created,'%m-%d-%Y') as date, DATE_FORMAT(ci_crm_transaction.date_created,'%H:%i %p') as time", FALSE
        );
        $this->db->join('admin', 'admin.id_admin = crm_transaction.id_admin', 'left');
        $this->db->join('user', 'user.user_id = crm_transaction.id_admin', 'left');
        $order_by = ($order_by == '') ? 'date_created' : $order_by;
        $order_direction = ($this->session->userdata('crm_ob_type') != '') ? $this->session->userdata('crm_ob_type') : 'DESC';
        $this->db->order_by($order_by, $order_direction);
        if(!$this->session->userdata('super_admin')){
	 $this->db->where_not_in('crm_transaction.id_admin', 3);
        }
        if($perpage != null){
            $this->db->limit($perpage, $offset);
        }

        $q = $this->db->get('crm_transaction');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $data[] = $row;
            }
        }
        $q->free_result();
        return $data;
    }

    function do_save($params) {
        
        if (!isset($params['crm_transaction_id'])) {
            $params['date_created'] = date('Y-m-d H:i:s');
        }     
        return parent::do_save($params);
    }
    

}

/* End of file m_crm_status.php */
/* Location: ./application/models/default/m_crm_status.php */