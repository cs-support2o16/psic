<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_inventory_category extends MY_Model {

    function __construct() {
        parent::__construct();

        $this->set_table_name('inventory_category');
        $this->set_primary_key('inventory_category_id');
    }

    function get($id) {
        $data = array();
        $this->db->limit(1);
        $this->db->where('inventory_category_id', $id);
        $q = $this->db->get('inventory_category');
        if ($q->num_rows() > 0) {
            $data = $q->row_array();
        }
        $q->free_result();
        return $data;
    }

    function do_save($params) {

        if (!isset($params['inventory_category_id'])) {
            $params['date_posted'] = date('Y-m-d H:i:s');
        }
        return parent::do_save($params);
    }

    function get_count() {
        return $this->db->count_all('faq');
    }

    function get_all($perpage, $offset) {
        $data = array();
        $this->db->limit($perpage, $offset);
        $q = $this->db->get('inventory_category');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $row['date_posted'] = date('M d, Y g:i A', strtotime($row['date_posted']));
                $data[] = $row;
            }
        }
        $q->free_result();
        return $data;
    }

        function fetch_all($limit = null, $offset = null)
	    {
	        $this->db->order_by('title', 'ASC');
	
	        return parent::fetch_all($limit, $offset);
	    }
}

/* End of file m_inventory_category.php */
/* Location: ./application/models/default/m_inventory_category.php */