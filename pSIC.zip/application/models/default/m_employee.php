<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_employee extends MY_Model {

        function __construct()
        {
            parent::__construct();
            
            $this->set_table_name('employee');
            $this->set_primary_key('employee_id');
        }

        /**
         * Get a employee data by their employee_id;
         *
         * @param int $id
         * @return mixed
         */
        function get_by_id($id)
        {
            return parent::get($id);
        }

	function do_save($post){
            $data = array(
                'email' => $post['email'],
                'firstname' => $post['firstname'],
				'middlename' => $post['middlename'],
                'lastname' => $post['lastname'],
                'department' => $post['department'],
                'position' => $post['position'],
                'status' => 0
            );

            if($this->db->insert('employee', $data)){
                    return TRUE;
            }else{
                    return FALSE;
            }
	}
        
        function get_all($perpage, $offset){
		$data = array();
                $this->db->order_by('lastname', 'ASC');
		$this->db->limit($perpage,$offset);
                //$this->db->where('employee_id !=', '1');
		$q = $this->db->get('employee');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}
        
        function fetch_all(){
		$data = array();
                $this->db->order_by('lastname', 'ASC');
                $this->db->where('employee_id !=', '1');
		$q = $this->db->get('employee');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}

	function get($employee_id){         
		$data = array();
		$this->db->limit(1);
		$this->db->where('employee_id', $employee_id);
		$q = $this->db->get('employee');
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		$q->free_result();
		return $data;
	}
        
        function get_count(){
		return $this->db->count_all('employee');
	}
	
        function updateCategory($data, $id){
                $this->db->where('employee_id', $id);
                if($this->db->update('employee', $data)){
                        return TRUE;
                }else{
                        return FALSE;
                }
	}
        
	function updateAdmin($post, $id){
		$data = array(
                    'firstname' => $post['firstname'],
                    'lastname' => $post['lastname'],
                    'middlename' => $post['middlename'],
                    'department' => $post['department'],
                    'position' => $post['position']
            );
		$this->db->where('employee_id', $id);
		if($this->db->update('employee', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function do_insert($post){
		$data = array(
                    'firstname' => $post['firstname'],
                    'lastname' => $post['lastname'],
                    'middlename' => $post['middlename'],
                    'department' => $post['department'],
                    'status' => 1,
                    'position' => $post['position']
            );

		if($this->db->insert('employee', $data)){
			return TRUE;
		}else{
			return FALSE;
		}

	}
        
        function updatePhysician($physician_id, $id){
		$data = array(
                    'physician_id' => $physician_id,
            );
		$this->db->where('employee_id', $id);
		if($this->db->update('employee', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
        
        function do_update($post, $id){
		$data = array(
                    'firstname' => $post['firstname'],
                    'lastname' => $post['lastname'],
                    'middlename' => $post['middlename'],
                    'department' => $post['department'],
                    'position' => $post['position']
            );
		$this->db->where('employee_id', $id);
		if($this->db->update('employee', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
        
        function getemployeeByCategory($category){
		$data = array();
		$q = $this->db->get_where('employee', array('category' => $category, 'employee_id !=' => '1'));
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}
	

	function import_record($data)
	{	
		#SEARH FIRST IF DUPLICATE
		$this->db->where('firstname',$data['fname']);
		$this->db->where('lastname',$data['lname']);
		$this->db->where('middlename',$data['middlename']);
		$q = $this->db->get('ci_employee');

		foreach($q->result() as $r => $v)
		{
			$update_id = $v->employee_id;
		}

		if($this->db->affected_rows()<=0)
		{			
			/**

			#######INSERT NEW RECORD

			**/
			$data_primary = array(
					"firstname" => $data['fname'],
					"lastname" => $data['lname'],
					"middlename" => $data['middlename'],
					"department" => $data['department'],
					"position" => $data['position']
			);	
			$this->db->insert("ci_employee",$data_primary);
			$last_id = $this->db->insert_id();

		}else{
			/**
			#######UPDATE EXISTING RECORD
			**/
			$data_primary = array(
					"firstname" => $data['fname'],
					"lastname" => $data['lname'],
					"middlename" => $data['middlename'],
					"department" => $data['department'],
					"position" => $data['position']
			);	
			$this->db->where('firstname',$data['fname']);
			$this->db->where('lastname',$data['lname']);
			$this->db->update("ci_employee",$data_primary);

		}		

	}

	function getAdminByEmail($email){
		$data = array();
		$q = $this->db->get_where('employee', array('email' => $email));
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		$q->free_result();
		return $data;
	}


        function fetch_all_gso($limit = null, $offset = null)
	    {
	       $this->db->where('department','City General Services Office');	     
               $this->db->order_by('lastname', 'DESC');

	        return parent::fetch_all($limit, $offset);
	    }

        function fetch_all_emp($limit = null, $offset = null)
	    {	     
               $this->db->order_by('lastname', 'DESC');

	        return parent::fetch_all($limit, $offset);
	    }

        function updateStatus($data, $id){
                $this->db->where('employee_id', $id);
                if($this->db->update('employee', $data)){
                        return TRUE;
                }else{
                        return FALSE;
                }
	}

}

/* End of file m_employee.php */
/* Location: ./application/models/default/m_employee.php */