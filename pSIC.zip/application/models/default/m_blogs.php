<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class M_blogs extends MY_Model 
{
    private $db2;
    
    function list_record()
    {
        $result = "";

        $this->db2 = $this->load->database('second',TRUE);

        #ADD THE ID OF THE WELCOME PAGE
        #$this->db2->where('ID !=','2');

        $this->db2->where('post_status','publish');
        $this->db2->limit(3);
        $this->db2->order_by("post_date","DESC");
        $q = $this->db2->get('posts');

        $result['list_record'] = $q->result();

        $this->return_connection();

        return $result;
    }

    function return_connection()
    {
        $this->load->database('default',TRUE);
    }
}

/* End of file M_blogs.php */
/* Location: ./application/models/default/M_blogs.php */