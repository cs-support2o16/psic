<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_mri extends CI_Model {

    function insert($post) {
    	if(isset($post['capture_date'])){
        	$capture_date = $post['capture_date'];
        }else{
        	$capture_date = date('Y-m-d H:i:s');
        }
        $data = array(
            'fname' => $post['fname'],
            'lname' => $post['lname'],
            'email' => $post['email'],
            'date_sent' => date('Y-m-d H:i:s'),
            'date_updated' => date('Y-m-d H:i:s'),
            'zip' => $post['zip'],
            'number' => $post['number'],
            'capture_date' => $capture_date,
        );
        if(isset($post['source'])){
        $data['source'] = $post['source'];
        }
        
        if ($this->db->insert('mri', $data)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
    
    function insert_contact($post) {
        $data = array(
            'fname' => $post['fname'],
            'lname' => $post['lname'],
            'number' => $post['number'],
            'email' => $post['email'],
            'source' => $post['source'],
            'date_sent' => date('Y-m-d H:i:s'),
            'date_updated' => date('Y-m-d H:i:s'),
            'capture_date' => date('Y-m-d H:i:s')
           
        );
        if ($this->db->insert('mri', $data)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    function check_duplicate($params) {
        $data = array();
        $this->db->limit(1);
        $this->db->select(
                'mri.*, crm_status.code AS status, crm_status.description AS description, '
                . 'crm_note.note AS note, crm_note.attachment AS note_attachment', FALSE
        );
        $this->db->join('crm_status', 'crm_status.status_id = mri.status_id', 'left');
        $this->db->join('crm_note', 'crm_note.note_id = mri.note_id', 'left');
        
        
        $this->db->where("(lname = '". $params['lname']."' OR fname = '". $params['fname']. "')");
        $this->db->where('zip', $params['zip']);
        //$this->db->where('email', $params['email']);
        //$this->db->where('number', $params['number']);
        $q = $this->db->get('mri');
        if ($q->num_rows() > 0) {
            $data = $q->row_array();
        }
        $q->free_result();
        return $data;
    }

}

/* End of file m_mri.php */
/* Location: ./application/models/default/m_mri.php */