<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_crm_reminder extends MY_Model {

    function __construct() {
        parent::__construct();

        $this->set_table_name('crm_reminder');
        $this->set_primary_key('crm_reminder_id');
    }

    function get_events($time){

            $current_month = date("n", $time);
            $current_year = date("Y", $time);
            $total_days_of_current_month = date("t", $time);

            $events = array();

            $query = $this->db->query("
            SELECT DATE_FORMAT(date,'%d') AS day, DATE_FORMAT(date,'%c') AS month, DATE_FORMAT(date,'%Y') AS year,
            note as eventContent, title as eventTitle, crm_reminder_id as id,date, posted_by
            FROM ci_crm_reminder AS ev
            WHERE date BETWEEN  '$current_year/$current_month/01'
                                            AND '$current_year/$current_month/$total_days_of_current_month'");

            foreach ($query->result() as $row_event)
            {
                    $events[intval($row_event->day)][] = $row_event;
            }
            $query->free_result();
            return $events;
    }
    
    function find_events_per_day($date) {
        $data = array();
        $this->db->where('date', $date);
        $this->db->order_by('crm_reminder.crm_reminder_id', 'desc');
        $q = $this->db->get('crm_reminder');
        if ($q->num_rows() > 0) {
            foreach ($q->result_array() as $row) {
                $data[] = $row;
            }
        }
        $q->free_result();
        return $data;
    }


    function do_save($params) {
        
        if (!isset($params['crm_reminder_id'])) {
            $params['date_posted'] = date('Y-m-d H:i:s');
        }     
        return parent::do_save($params);
    }

}

/* End of file m_crm_status.php */
/* Location: ./application/models/default/m_crm_status.php */