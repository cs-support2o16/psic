<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Model for interacting with the "inventory" table.
 *
 */
class M_inventory extends MY_Model {

    private $_table_name = 'inventory';
    private $_primary_key = 'inventory_id';

    public function __construct() {
        parent::__construct();

        // Set the values for MY_Model::_table and MY_Model::_primary .
        $this->set_table_name($this->_table_name);
        $this->set_primary_key($this->_primary_key);
    }

    function find_by_type($value, $type, $limit = null, $offset = null) {

        $this->db->select(
                'inventory.*, inventory_category.title AS inventory_category', FALSE
        );
        $this->db->join('inventory_category', 'inventory.inventory_category_id = inventory_category.inventory_category_id', 'left');

        if ($type == 'title' || $type == 'author' || $type =='url') {
            $this->db->WHERE("ci_inventory.".$type." LIKE '" . $value . "'");
            if ($type == 'title') {
                $this->db->limit('1');
            }
        } else if ($type == 'category') {
            $this->db->WHERE("ci_inventory_category.title LIKE '" . $value . "'");
        } else if ($type == 'tag') {
            //$this->db->WHERE("( ci_inventory.tag LIKE '" . $value . "' OR ci_inventory.tag LIKE '" . $value . "%' )");
            $this->db->WHERE("ci_inventory.tag LIKE '%" . $value . "%'");
        } else if ($type == 'date') {
            $this->db->where("DATE_FORMAT(ci_inventory.date_posted,'%Y-%m')", $value);
        }
        $this->db->order_by('date_posted DESC');
        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }
        return parent::fetch_all();

    }

    /**
     * Return the latest inventory posted.
     * 
     * @param int $limit How many records to retrieve.
     * @return obj
     */
    function fetch_latest_inventory($limit = null, $offset = null) {

        $this->db->select(
                'inventory.*, inventory_category.title AS inventory_category', FALSE
        );
        $this->db->join('inventory_category', 'inventory.inventory_category_id = inventory_category.inventory_category_id', 'left');
        #$this->db->where('inventory.published', '1');
        $this->db->order_by('date_posted DESC');
        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }
        return parent::fetch_all();
    }

    /**
     * Return the latest inventory posted.
     * 
     * @param int $limit How many records to retrieve.
     * @return obj
     */
    function fetch_archive($limit = null, $offset = null) {

        $this->db->select(
                "DATE_FORMAT(ci_inventory.date_posted,'%Y/%m') as archive_url, DATE_FORMAT(ci_inventory.date_posted,'%M %Y') as archive_date", FALSE
        );
        $this->db->join('inventory_category', 'inventory.inventory_category_id = inventory_category.inventory_category_id', 'left');
        #$this->db->where('inventory.published', '1');
        $this->db->order_by('inventory.date_posted DESC');
        $this->db->group_by("YEAR(ci_inventory.date_posted), MONTH(ci_inventory.date_posted)");
        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }
        return parent::fetch_all();
    }

    /**
     * Return the latest inventory posted.
     * 
     * @param int $limit How many records to retrieve.
     * @return obj
     */
    function fetch_latest_inventory_list() {
        $this->db->select(
                'inventory.*, inventory_category.title AS inventory_category', FALSE
        );
        $this->db->join('inventory_category', 'inventory.inventory_category_id = inventory_category.inventory_category_id', 'left');

        $this->db->order_by('date_posted DESC');
        return parent::fetch_all();
    }

    /**
     * Override so we can set date_posted.
     */
    function do_save($params) {

        if (!isset($params['inventory_id'])) {
            #$params['published'] = '1';
            $params['date_posted'] = date('Y-m-d H:i:s');
            $params['added_by'] = $this->session->userdata('user_id');
        } else {
            $params['date_updated'] = date('Y-m-d H:i:s');
            $params['updated_by'] = $this->session->userdata('user_id');
        }
        return parent::do_save($params);
    }

    /**
     * Fetch record by title.
     *
     * @param string $title inventory title.
     *     
     * @return mixed FALSE if no match found.
     */
    function get_by_title($title) {
        $this->db->where('title', $title);

        $inventory = $this->db->get($this->_table_name);

        if ($inventory->num_rows() > 0) {
            return $inventory->row();
        } else {
            return FALSE;
        }
    }

    function get_by_id($inventory_id) {
        $data = array();
        $this->db->select(
                'inventory.*, inventory_category.title AS inventory_category, CONCAT(ci_user.firstname, " ", user.lastname, " - ", user.department, " - ", user.position) AS added_by', FALSE
        );
        $this->db->join('inventory_category', 'inventory.inventory_category_id = inventory_category.inventory_category_id', 'left');
        $this->db->join('user', 'inventory.added_by = user.user_id', 'left');
        $this->db->where('inventory_id', $inventory_id);

        $inventory = $this->db->get($this->_table_name);

        if ($inventory->num_rows() > 0) {
            $data = $inventory->row_array();
        }
        $inventory->free_result();
        return $data;
    }

    function get_updated_by($inventory_id) {
        $data = array();
        $this->db->select(
                'inventory.*, inventory_category.title AS inventory_category, CONCAT(ci_user.firstname, " ", user.lastname, " - ", user.department, " - ", user.position) AS updated_by', FALSE
        );
        $this->db->join('inventory_category', 'inventory.inventory_category_id = inventory_category.inventory_category_id', 'left');
        $this->db->join('user', 'inventory.updated_by = user.user_id', 'left');
        $this->db->where('inventory_id', $inventory_id);

        $inventory = $this->db->get($this->_table_name);

        if ($inventory->num_rows() > 0) {
            $data = $inventory->row_array();
        }
        $inventory->free_result();
        return $data;
    }

    function remove_image($id) {
        $this->db->where('inventory_id', $id);
        if ($this->db->update('inventory', array('image' => '', 'date_updated' => date('Y-m-d H:i:s')))) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    function update_status($id, $type, $value) {
        $this->db->where('inventory_id', $id);
        if ($this->db->update('inventory', array($type => $value, 'date_updated' => date('Y-m-d H:i:s')))) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    function fetch_related_posts($value, $limit = 2, $offset = null) {

        $this->db->select(
                'inventory.*, inventory_category.title AS inventory_category', FALSE
        );
        $this->db->join('inventory_category', 'inventory.inventory_category_id = inventory_category.inventory_category_id', 'left');

        #$this->db->where('inventory.published', '1');
        $this->db->not_like('ci_inventory.title', $value);

        $this->db->order_by('date_posted DESC');
        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }
        return parent::fetch_all();

    }
    function checkpn($pn) {
        $data = array();
            $q = $this->db->get_where('inventory', array('p_number' => $pn), 1);
    
        if ($q->num_rows() > 0) {
            $data = $q->row_array();
        }
        $q->free_result();
        return $data;
    }

}

/* End of file m_event_category.php */
/* Location: ./application/models/default/m_event_category.php */
