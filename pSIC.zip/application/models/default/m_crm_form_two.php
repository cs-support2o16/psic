<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_crm_form_two extends MY_Model {

    function __construct() {
        parent::__construct();

        $this->set_table_name('crm_form_two');
        $this->set_primary_key('crm_form_two_id');
    }

    function do_save($params) {
        
        if (!isset($params['crm_form_two_id'])) {
            $params['date_posted'] = date('Y-m-d H:i:s');
        }else{
            $params['date_updated'] = date('Y-m-d H:i:s');
        }   
        return parent::do_save($params);
    }
    
    function find_by_mri($id) {
        $data = array();
        $this->db->limit(1);
        $this->db->where('id_mri', $id);
        $q = $this->db->get('crm_form_two');
        if ($q->num_rows() > 0) {
            $data = $q->row_array();
        }
        $q->free_result();
        return $data;
    }
    

}

/* End of file m_crm_status.php */
/* Location: ./application/models/default/m_crm_status.php */