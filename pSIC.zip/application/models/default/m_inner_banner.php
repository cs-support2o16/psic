<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_inner_banner extends CI_Model {

	function get_count(){
		return $this->db->count_all('inner_banner');
	}
	
	function get($id){
		$data = array();
		$this->db->where('page_id', $id);
		$this->db->limit(1);
		$q = $this->db->get('inner_banner');
		if($q->num_rows() > 0){
			$data = $q->row_array();
		}
		return $data;
	}
	
	function get_all($perpage, $offset){
		$data = array();
		$this->db->limit($perpage,$offset);
		$this->db->order_by('date_posted','DESC');
		$q = $this->db->get('inner_banner');
		if($q->num_rows() > 0){
			foreach($q->result_array() as $row){
				$row['date_posted'] = date('M d, Y; g:i A',strtotime($row['date_posted']));
				$data[] = $row;
			}
		}
		$q->free_result();
		return $data;
	}

	function insert($data){
		$data = array(
			'title'       => $data['title'],
			'file_name'   => $data['file_name'],			
			'date_posted' => date('Y-m-d H:i:s'),
			'url_page_id' => $data['url_page_id']			
		);

		if($this->db->insert('inner_banner', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function update($post){      
		#echo "<pre>"; print_r($post); echo "</pre>";      
		$data = array(
			'title' => $post['title'],
			'file_name' => $post['file_name'],
			'url_page_id' => $post['page_location']
		);
		$this->db->where('page_id', $post['id_download']);
		if($this->db->update('inner_banner', $data)){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function delete($id){ 
		$this->db->where('page_id', $id);
		if($this->db->delete('inner_banner')){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	function get_downloads($id_page){
		$downloads = array();
		$pages = $this->M_download_page_loc->getByPage($id_page);
		foreach($pages as $row){
			$downloads[] = $this->M_download->get($row['id_download']);
		}
		return $downloads;
	}

	function get_page($id)
	{
		$this->db->where('id_page',$id);
		$get_sql = $this->db->get('page');
		foreach($get_sql->result() as $key => $value)
		{
			$record['get_page'] = $value->page_title;
		}	

		return $record;
	}
	
	function getListPage()
	{
		$get_sql = $this->db->get('page');
		$record['getListPage'] = $get_sql->result();

		return $record;
	}

	function check_banner($value)
	{
		$this->db->where('url_key',$value);
		$this->db->from('ci_page');
		$get_sql = $this->db->get();

		foreach($get_sql->result() as $key => $value)
		{
			$id_page = $value->id_page;
		}		
		
		$id_page = (!isset($id_page))? "264" : $id_page;
		
		$this->db->where('url_page_id',$id_page);		
		$get_sql = $this->db->get('inner_banner');

		$record['check_banner'] = $get_sql->result();

		return $record;

	}
}

/* End of file m_download.php */
/* Location: ./application/models/admin/m_download.php */