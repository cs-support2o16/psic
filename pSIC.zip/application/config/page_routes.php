<?php
// Joint Replacement Is NOT The Only Option
$route["joint-replacement-not-the-only-option"] = "default/page/view";
 
// The Truth About Hip Replacement
$route["conditions/hip/truth-about-hip-replacement"] = "default/page/view";
 
// The Truth About Knee Replacement
$route["conditions/knee/truth-about-knee-replacement"] = "default/page/view";
 
// The Truth About Shoulder Replacement
$route["conditions/shoulder/truth-about-shoulder-replacement"] = "default/page/view";
 
// Advanced Regenerative Orthopedics in Naples, Florida
$route["areas-served/florida/naples"] = "default/page/view";
 
// Advanced Regenerative Orthopedics in Clearwater, Florida
$route["areas-served/florida/clearwater"] = "default/page/view";
 
// Advanced Regenerative Orthopedics in Palm Bay, Florida
$route["areas-served/florida/palm-bay"] = "default/page/view";
 
// Advanced Regenerative Orthopedics in Lakeland, Florida
$route["areas-served/florida/lakeland"] = "default/page/view";
 
// Advanced Regenerative Orthopedics in Jacksonville, Florida
$route["areas-served/florida/jacksonville"] = "default/page/view";
 
// Advanced Regenerative Orthopedics in West Palm Beach, Florida
$route["areas-served/florida/west-palm-beach"] = "default/page/view";
 
// Advanced Regenerative Orthopedics in St. Petersburg, Florida
$route["areas-served/florida/st-petersburg"] = "default/page/view";
 
// Advanced Regenerative Orthopedics in Orlando, Florida
$route["areas-served/florida/orlando"] = "default/page/view";
 
// Advanced Regenerative Orthopedics in Tampa, Florida
$route["areas-served/florida/tampa"] = "default/page/view";
 
// Florida Orthopedic Clinic and Specialists
$route["areas-served/florida"] = "default/page/view";
 
// Areas We Serve
$route["areas-served"] = "default/page/view";
 
// 5 Meniscus Exercises to Keep Your Joints Healthy
$route["conditions/knee/meniscus-exercises"] = "default/page/view";
 
// 5 ACL Exercises to Keep Your Joints Healthy
$route["conditions/knee/acl-exercises"] = "default/page/view";
 
// 5 Rotator Cuff Exercises to Keep Your Joints Healthy
$route["conditions/shoulder/rotator-cuff-exercies"] = "default/page/view";
 
// 5 Shoulder Exercises to Keep Your Joints Healthy
$route["conditions/shoulder/shoulder-exercises"] = "default/page/view";
 
// 5 Knee Exercises to Keep Your Joints Healthy
$route["conditions/knee/knee-exercises-for-healthy-joints"] = "default/page/view";
 
// 5 Hip Exercises to Keep Your Joints Healthy
$route["conditions/hip/hip-exercises-for-healthy-joints"] = "default/page/view";
 
// Page Test
$route["page-test"] = "default/page/view";
 
// test
$route["our-program/test"] = "default/page/view";
 
// Step 1: Free MRI Review
$route["contact-form"] = "default/mri";
 $route["contact-form/send"] = "default/mri/send";

// MailChimp Test Page
$route["mc-test"] = "default/page/view";
 
// Blog
$route["aro-blog"] = "default/blog";
$route["aro-blog/(:any)"] = "default/blog/view/$1";
$route["aro-blog/(:any)/(:num)"] = "default/blog/view/$1/$2";

// Bone Spurs
$route["conditions/shoulder/shoulder-bone-spurs"] = "default/page/view";
 
// Shoulder Labral Tear
$route["conditions/shoulder/shoulder-labral-tear"] = "default/page/view";
 
// Rotator Cuff Tear
$route["conditions/shoulder/rotator-cuff-tear"] = "default/page/view";
 
// Shoulder Pain
$route["conditions/shoulder/shoulder-pain"] = "default/page/view";
 
// Hip Bone Spurs
$route["conditions/hip/hip-bone-spurs"] = "default/page/view";
 
// Hip Osteoarthritis
$route["conditions/hip/hip-osteoarthritis"] = "default/page/view";
 
// Hip Labral Tear
$route["conditions/hip/labral-tear"] = "default/page/view";
 
// Hip Pain Causes and Treatments
$route["conditions/hip/hip-pain"] = "default/page/view";
 
// Knee Bone Spur Information
$route["conditions/knee/bone-spurs"] = "default/page/view";
 
// Bone on Bone Knee Pain
$route["conditions/knee/bone-on-bone"] = "default/page/view";
 
// Knee Osteoarthritis
$route["conditions/knee/osteoarthritis"] = "default/page/view";
 
// Torn Meniscus
$route["conditions/knee/torn-meniscus"] = "default/page/view";
 
// Torn ACL
$route["conditions/knee/torn-acl"] = "default/page/view";
 
// Knee Pain and Injuries
$route["conditions/knee/pain"] = "default/page/view";
 
// Build and Hide 10
$route["build-and-hide10"] = "default/page/view";
 
// Build and Hide 9
$route["build-and-hide9"] = "default/page/view";
 
// Build and Hide 8
$route["build-and-hide8"] = "default/page/view";
 
// Build and Hide 7
$route["build-and-hide7"] = "default/page/view";
 
// Build and Hide 6
$route["build-and-hide6"] = "default/page/view";
 
// Build and Hide 5
$route["build-and-hide5"] = "default/page/view";
 
// Build and Hide 4
$route["build-and-hide4"] = "default/page/view";
 
// Build and Hide 3
$route["build-and-hide3"] = "default/page/view";
 
// Build and Hide 2
$route["build-and-hide2"] = "default/page/view";
 
// Build and Hide 1
$route["build-and-hide1"] = "default/page/view";
 
// Tien Lee, M.D.
$route["our-specialists/dr-tien-lee"] = "default/page/view";
 
// Anthony Esposito, D.O.
$route["our-specialists/dr-anthony-esposito"] = "default/page/view";
 
// Leslie Miller, M.D.
$route["our-specialists/dr-leslie-miller"] = "default/page/view";
 
// Thank You
$route["testimonial-thank-you-page"] = "default/page/view";
 
// Share Your Story
$route["share-your-story"] = "default/testimonials/add";
 
// Testimonials
$route["patient-testimonials"] = "default/testimonials/index";
 $route["patient-testimonials/view/([a-z0-9]+)"] = "default/testimonials/view/$1";
 $route["patient-testimonials/index/([0-9]+)"] = "default/testimonials/index/$1";
$route["patient-testimonials/index"] = "default/testimonials/index";
 $route["patient-testimonials/list_testimonials"] = "default/testimonials/list_testimonials";
 $route["patient-testimonials/list_testimonials/([a-z0-9]+)"] = "default/testimonials/list_testimonials/$1";
 $route["patient-testimonials/list_testimonials/([a-z0-9]+)/([a-z0-9]+)"] = "default/testimonials/list_testimonials/$1/$2";
 
// Test
$route["test"] = "default/page/view";
 
// Privacy Policy
$route["privacy-policy"] = "default/page/view";
 
// Sitemap
$route["sitemap"] = "default/page/view";
 
// Free MRI Review
$route["mri-thank-you-page"] = "default/page/view";
 
// Step 3: Pre-Op Health Questionnaire
$route["becoming-a-patient/pre-op-health-questionnaire"] = "default/page/view";
 
// Step 2: Qualifications Checklist
$route["becoming-a-patient/qualifications-checklist"] = "default/page/view";
 
// Step 1: No-Cost MRI Review
$route["becoming-a-patient/no-cost-mri-review"] = "default/mri";
 $route["becoming-a-patient/no-cost-mri-review/send"] = "default/mri/send";

// Becoming a Patient
$route["becoming-a-patient"] = "default/page/view";
 
// Pain Specialist
$route["our-specialists/pain-specialist"] = "default/page/view";
 
// Dr. Steven Mirabello
$route["our-specialists/dr-steven-mirabello"] = "default/page/view";
 
// Dr. Robert Dean
$route["our-specialists/dr-robert-dean"] = "default/page/view";
 
// Meet Our Team
$route["our-specialists/meet-our-team"] = "default/page/view";
 
// Our Specialists
$route["our-specialists"] = "default/page/view";
 
// Ankle
$route["our-procedures/ankle"] = "default/page/view";
 
// Elbow
$route["our-procedures/elbow"] = "default/page/view";
 
// Carpal Tunnel
$route["our-procedures/carpal-tunnel"] = "default/page/view";
 
// Labral Repair
$route["our-procedures/labral-repair"] = "default/page/view";
 
// Hip Arthroscopy
$route["our-procedures/hip-arthroscopy"] = "default/page/view";
 
// Rotator Cuff Surgery
$route["our-procedures/rotator-cuff-repair"] = "default/page/view";
 
// SLAP Lesion Repair
$route["our-procedures/slap-lesion-repair"] = "default/page/view";
 
// Bankart Lesion Repair
$route["our-procedures/bankart-lesion-repair"] = "default/page/view";
 
// Shoulder Arthroscopy
$route["our-procedures/shoulder-arthroscopy"] = "default/page/view";
 
// ACL Reconstruction
$route["our-procedures/acl-reconstruction"] = "default/page/view";
 
// Meniscus Repair
$route["our-procedures/meniscus-repair"] = "default/page/view";
 
// Chondroplasty
$route["our-procedures/chondroplasty"] = "default/page/view";
 
// Arthroscopic Knee Surgery
$route["our-procedures/knee-arthroscopy"] = "default/page/view";
 
// Regenerative Medicine
$route["our-procedures/regenerative-medicine"] = "default/page/view";
 
// Do You Need Denervation?
$route["our-procedures/denervation"] = "default/page/view";
 
// Arthroscopy
$route["our-procedures/arthroscopy"] = "default/page/view";
 
// Our Procedures
$route["our-procedures"] = "default/page/view";
 
// Other
$route["conditions/other"] = "default/page/view";
 
// Shoulder Conditions
$route["conditions/shoulder"] = "default/page/view";
 
// Hip Conditions We Treat
$route["conditions/hip"] = "default/page/view";
 
// Knee Conditions We Can Treat
$route["conditions/knee"] = "default/page/view";
 
// Conditions We Treat
$route["conditions"] = "default/page/view";
 
// Post-Op Requirements
$route["our-program/post-op-requirements"] = "default/page/view";
 
// Travel and Financing Options
$route["our-program/travel-and-financing"] = "default/page/view";
 
// Do You Need Denervation?
$route["our-program/denervation"] = "default/page/view";
 
// Regenerative Medicine
$route["our-program/regenerative-medicine"] = "default/page/view";
 
// Arthroscopy
$route["our-program/arthroscopy"] = "default/page/view";
 
// Our 3-Day Process
$route["our-program/our-3-day-process"] = "default/page/view";
 
// Our Mission
$route["our-program/our-mission"] = "default/page/view";
 
// Contact Us
$route["contact-us"] = "default/contact_us";
 $route["contact-us/send"] = "default/contact_us/send";

// Our Program
$route["our-program"] = "default/page/view";
 
// Contact Us
$route["contact-us-thank-you-page"] = "default/page/view";
 
// Home Page
$route["home"] = "default/page";
 
