<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Add upload paths to this file, per controller.
 */

$config['upload_path'] = array('testimonials' => 'testimonials', 'callouts' => 'callouts', 'videocast' => 'videocast', 'user' => 'user');

/* End of file config.php */
/* Location: ./application/config/upload_path.php */