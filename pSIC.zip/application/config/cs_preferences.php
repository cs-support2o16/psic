<?php
/**
 * Set config/preferences here for various models.
 *
 */
/**
 * Testimonials.
 */
$config['testimonial_auto_publish'] = TRUE;
$config['seminars_show_ended'] = FALSE;
$config['seminars_show_full'] = TRUE;

/**
 * reCAPTCHA
 */
$config['recaptcha'] = array(
    'public' => '6LezRMQSAAAAAIWTNBWCgrhVtEZx6ALo5Boqkqju',
    'private' => '6LezRMQSAAAAAA5Dv90fr_WRhD0CUdzD8bVkyQFW',
    'RECAPTCHA_API_SERVER' => 'http://www.google.com/recaptcha/api',
    'RECAPTCHA_API_SECURE_SERVER' => 'https://www.google.com/recaptcha/api',
    'RECAPTCHA_VERIFY_SERVER' => 'www.google.com',
    'RECAPTCHA_SIGNUP_URL' => 'https://www.google.com/recaptcha/admin/create',
    'theme' => 'white'
);
$config['new_recaptcha'] = array(
    'site_key' => '6LdM7xwTAAAAADwm4rT1vS3AC1C9x5gSz5PJhgRl',
    'secret_key' => '6LdM7xwTAAAAALGLAXzEGQqo9Va1dTdLH5dZWcyB',
    'recaptcha_server' => 'https://www.google.com/recaptcha/api'
);

$config['mail_chimp'] = array(
    'api_key' => '42d463d0207e041fb2e57e9fe1fefa8e-us13',
    'list_id' => 'dcb494737d'
);

$config['five9'] = array(
    'wsdl' => 'https://api.five9.com/wsadmin/v2/AdminWebService?wsdl',
    'username' => 'jamaica@creatingskies.com',
    'password' => 'jamaica@creatingskies.com',
    'listName' => 'ARO_web_post_1'
);
?>