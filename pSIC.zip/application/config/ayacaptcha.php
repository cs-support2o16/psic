<?php
$config['validation_ayacaptcha'] = array(
    array(
      'field' => 'recaptcha',
      'label' => 'recaptcha',
      'rules' => 'required|callback_checkAYAHRecaptcha'
    )
  );