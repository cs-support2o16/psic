<?php
/**
 * Global email settings.
 */
$config['email_settings'] = array(
    'protocol' => 'smtp',
    'smtp_host' => 'ssl://smtp.googlemail.com',
    'smtp_port' => 465,
    'smtp_user' => 'mdnetuser@gmail.com',
    'smtp_pass' => 'test2011',
);
