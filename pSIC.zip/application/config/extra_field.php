<?php

$config['validate_extra_field'] = array(
    'field' => 'how_heard_other',
    'label' => 'How did you hear about us',
    'rules' => 'trim|required|xss_clean'
);
