<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['SITE_NAME'] = 'www.mdnetdemo.com';
$config['CLOSING']  = 'MDnetSolutions';