<?php

#define('__CAPTCHA_AYAH__', 1);		//set captcha type to ayah
#define('__RECAPTCHA__', 2);			//set captcha type to recaptcha

#$config['captcha-type'] = __CAPTCHA_AYAH__;